from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

router = Router()

# ── Keyboards ──────────────────────────────────────────────────────────────────

def _kb_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏆 Рекордлар",     callback_data="hof_records")],
        [InlineKeyboardButton(text="😂 Антирекордлар", callback_data="hof_antirecords")],
        [InlineKeyboardButton(text="⬅️ Орқага",        callback_data="hof_back")],
    ])


def _kb_records() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏟 Жамоалар",    callback_data="hof_r_clubs")],
        [InlineKeyboardButton(text="👔 Мураббийлар", callback_data="hof_r_coaches")],
        [InlineKeyboardButton(text="⚽ Футболчилар", callback_data="hof_r_players")],
        [InlineKeyboardButton(text="⬅️ Орқага",      callback_data="hof_main")],
    ])


def _kb_antirecords() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏟 Жамоалар",    callback_data="hof_a_clubs")],
        [InlineKeyboardButton(text="👔 Мураббийлар", callback_data="hof_a_coaches")],
        [InlineKeyboardButton(text="⚽ Футболчилар", callback_data="hof_a_players")],
        [InlineKeyboardButton(text="⬅️ Орқага",      callback_data="hof_main")],
    ])


def _kb_back_records() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="hof_records")],
    ])


def _kb_back_antirecords() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="hof_antirecords")],
    ])


# ── Placeholder texts ──────────────────────────────────────────────────────────

_PENDING = "\n\n<i>Маълумотлар йиғилмоқда.\nБиринчи мавсум якунлангач автоматик ҳисобланади.</i>"

_RECORDS_CLUBS = (
    "🏟 <b>Жамоалар — Рекордлар</b>\n\n"
    "👑 Энг кўп чемпион\n"
    "🥈 Энг кўп финал\n"
    "🥉 Энг кўп ярим финал\n"
    "🏅 Энг кўп чорак финал\n"
    "🎟 Энг кўп 1/8 финал\n"
    "🔥 Энг кўп плей-офф\n"
    "🏟 Энг кўп ғалаба\n"
    "⚽ Энг кўп гол\n"
    "📈 Энг яхши мавсум\n"
    "📊 Энг кўп очко\n"
    "🚀 Энг узун ғалабалар серияси\n"
    "🛡 Энг кам гол ўтказган мавсум\n"
    "💯 Бир мавсумдаги энг кўп очко\n"
    "🔥 Энг йирик ғалаба\n"
    "⚽ Энг сергол ўйин"
    + _PENDING
)

_RECORDS_COACHES = (
    "👔 <b>Мураббийлар — Рекордлар</b>\n\n"
    "🎯 Энг кўп аниқ ҳисоб\n"
    "🏆 Энг кўп Golden Predictor\n"
    "👑 Энг кўп чемпионлик\n"
    "🥈 Энг кўп финал\n"
    "🎖 Энг кўп иштирок\n"
    "🚀 Энг узун мағлубиятсиз серия\n"
    "🎯 Бир Match Day даги энг кўп аниқ ҳисоб"
    + _PENDING
)

_RECORDS_PLAYERS = (
    "⚽ <b>Футболчилар — Рекордлар</b>\n\n"
    "👑 Энг кўп гол\n"
    "🥇 Энг кўп Golden Boot\n"
    "⭐ Энг кўп Dream Team\n"
    "🔥 Энг сермаҳсул мавсум\n"
    "🏆 Энг яхши футболчи\n"
    "⚽ Бир Match Day даги энг кўп гол"
    + _PENDING
)

_ANTI_CLUBS = (
    "🏟 <b>Жамоалар — Антирекордлар</b>\n\n"
    "😢 Энг кўп лига босқичидан чиқа олмаган\n"
    "💔 Энг кўп мағлубият\n"
    "🥄 Энг кўп охирги ўрин\n"
    "❌ Энг кўп финалда мағлуб бўлган\n"
    "📉 Энг ёмон мавсум\n"
    "🚫 Энг узун ғалабасиз серия\n"
    "💔 Энг йирик мағлубият\n"
    "🚫 Энг узун мағлубиятлар серияси"
    + _PENDING
)

_ANTI_COACHES = (
    "👔 <b>Мураббийлар — Антирекордлар</b>\n\n"
    "😭 Энг кўп аниқ ҳисоб тополмаган\n"
    "💔 Энг кўп финал ютқазган\n"
    "🚪 Энг кўп лига босқичидан чиқа олмаган\n"
    "📉 Энг ёмон мавсум"
    + _PENDING
)

_ANTI_PLAYERS = (
    "⚽ <b>Футболчилар — Антирекордлар</b>\n\n"
    "😅 Энг кўп голсиз мавсум\n"
    "💤 Энг узун голсиз серия\n"
    "🥲 Энг кўп иккинчи ўринда қолган тўпурар"
    + _PENDING
)


# ── Handlers ───────────────────────────────────────────────────────────────────

@router.message(Command("halloffame"))
async def cmd_halloffame(message: Message, *, user_id: int | None = None) -> None:
    await message.answer(
        "🏛 <b>Hall of Fame</b>\n\nҚуйидаги бўлимни танланг:",
        reply_markup=_kb_main(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "hof_main")
async def cb_hof_main(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        "🏛 <b>Hall of Fame</b>\n\nҚуйидаги бўлимни танланг:",
        reply_markup=_kb_main(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_back")
async def cb_hof_back(callback: CallbackQuery) -> None:
    await callback.message.delete()
    await callback.answer()


# ── Records section ────────────────────────────────────────────────────────────

@router.callback_query(F.data == "hof_records")
async def cb_hof_records(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        "🏆 <b>Рекордлар</b>\n\nКатегорияни танланг:",
        reply_markup=_kb_records(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_r_clubs")
async def cb_hof_r_clubs(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        _RECORDS_CLUBS,
        reply_markup=_kb_back_records(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_r_coaches")
async def cb_hof_r_coaches(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        _RECORDS_COACHES,
        reply_markup=_kb_back_records(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_r_players")
async def cb_hof_r_players(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        _RECORDS_PLAYERS,
        reply_markup=_kb_back_records(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Anti-records section ───────────────────────────────────────────────────────

@router.callback_query(F.data == "hof_antirecords")
async def cb_hof_antirecords(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        "😂 <b>Антирекордлар</b>\n\nКатегорияни танланг:",
        reply_markup=_kb_antirecords(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_a_clubs")
async def cb_hof_a_clubs(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        _ANTI_CLUBS,
        reply_markup=_kb_back_antirecords(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_a_coaches")
async def cb_hof_a_coaches(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        _ANTI_COACHES,
        reply_markup=_kb_back_antirecords(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "hof_a_players")
async def cb_hof_a_players(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        _ANTI_PLAYERS,
        reply_markup=_kb_back_antirecords(),
        parse_mode="HTML",
    )
    await callback.answer()
