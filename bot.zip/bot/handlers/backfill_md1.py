"""
/backfill_md1 — one-time admin utility to manually persist Match Day 1
duel results that were calculated before save_duel_results() existed.

Flow:
  1. Admin runs /backfill_md1
  2. Bot displays all 18 round-1 draw fixtures (numbered)
  3. Admin pastes 18 lines in format  X-Y  (home_goals-away_goals),
     each line matching the fixture at the same position
  4. Bot validates, stores via save_duel_results(1, records), confirms

Guard: if get_duel_results(1) already has data the command refuses to
overwrite unless the admin explicitly runs /backfill_md1 force.
"""

import re

from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

from bot.data.db import get_duel_results, save_duel_results
from bot.data.draw_db import get_round_fixtures

router  = Router()
MD       = 1
_SCORE_RE = re.compile(r"^(\d{1,3})-(\d{1,3})$")


class BackfillMD1SG(StatesGroup):
    waiting_scores = State()




def _fixtures_text(fixtures: list[dict]) -> str:
    lines = []
    for i, fx in enumerate(fixtures, 1):
        lines.append(f"{i:02d}. {fx['home']} vs {fx['away']}")
    return "\n".join(lines)


# ── /backfill_md1 ─────────────────────────────────────────────────────────────

@router.message(Command("backfill_md1"))
async def cmd_backfill_md1(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    text  = (message.text or "").strip()
    force = text.lower().endswith("force")

    # Guard: already exists
    if get_duel_results(MD) and not force:
        await message.answer(
            f"⚠️ {MD}-тур натижалари аллақачон архивда мавжуд.\n\n"
            "Қайта ёзиш учун:\n"
            "<code>/backfill_md1 force</code>",
        )
        return

    fixtures = get_round_fixtures(MD)
    if not fixtures:
        await message.answer(
            "❌ Draw.json'да 1-тур учун учрашувлар топилмади.\n"
            "Аввал /draw командасини ишлатинг."
        )
        return

    await state.set_state(BackfillMD1SG.waiting_scores)
    await state.update_data(fixtures=fixtures)

    await message.answer(
        f"📋 <b>{MD}-тур учрашувлари ({len(fixtures)} та)</b>\n\n"
        f"<code>{_fixtures_text(fixtures)}</code>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"Юқоридаги тартибда <b>{len(fixtures)} та</b> натижани киритинг.\n"
        "Ҳар бир қатор: <code>уй_гол-меҳмон_гол</code>\n\n"
        "Масалан:\n"
        "<code>3-1\n0-0\n2-4\n...</code>\n\n"
        "<i>Бекор қилиш учун /cancel</i>",
    )


@router.message(BackfillMD1SG.waiting_scores)
async def msg_backfill_scores(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    data     = await state.get_data()
    fixtures = data["fixtures"]
    n        = len(fixtures)

    raw_lines = [ln.strip() for ln in text.splitlines() if ln.strip()]

    if len(raw_lines) != n:
        await message.answer(
            f"❌ {n} та натижа кутилган, {len(raw_lines)} та олинди.\n\n"
            f"Илтимос, аниқ <b>{n}</b> қатор юборинг."
        )
        return

    records: list[dict] = []
    errors:  list[str]  = []

    for idx, line in enumerate(raw_lines, 1):
        m = _SCORE_RE.match(line)
        if not m:
            errors.append(f"Қатор {idx}: «{line}» — нотўғри формат (X-Y кутилган)")
            continue
        records.append({
            "home":       fixtures[idx - 1]["home"],
            "away":       fixtures[idx - 1]["away"],
            "goals_home": int(m.group(1)),
            "goals_away": int(m.group(2)),
        })

    if errors:
        await message.answer(
            "❌ Хатолар:\n\n" + "\n".join(errors) + "\n\nҚайтадан юборинг."
        )
        return

    save_duel_results(MD, records)
    await state.clear()

    # Build confirmation summary
    lines = []
    for r in records:
        gh, ga = r["goals_home"], r["goals_away"]
        icon   = "🤝" if gh == ga else "🏆"
        lines.append(f"{icon} {r['home']} {gh}–{ga} {r['away']}")

    await message.answer(
        f"✅ <b>{MD}-тур натижалари архивга сақланди</b>\n\n"
        + "\n".join(lines)
        + "\n\n/tourresults орқали текшириб кўринг."
    )
