import os

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.teams_db import (
    get_all_player_names_lower,
    get_available_teams,
    get_coach_team,
    get_team_players,
    is_registered,
    load_teams,
    register_coach,
    save_players,
)

router = Router()

_GROUP_ID = os.environ.get("GROUP_ID", "").strip()


async def _announce_join(bot, coach_name: str, team_name: str) -> None:
    """Broadcast official join announcement to group + all registered coaches."""
    ann = (
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "📢 <b>VFL РАСМИЙ ХАБАРИ</b>\n\n"
        f"✅ <b>{coach_name}</b> <b>{team_name}</b> жамоасига тайинланди.\n\n"
        f"🏟 <b>{team_name}</b> энди ўз мураббийига эга.\n\n"
        "🔥 Янги мавсум учун тайёргарлик бошланди!\n\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )
    if _GROUP_ID:
        try:
            await bot.send_message(int(_GROUP_ID), ann, parse_mode="HTML")
        except Exception:
            pass
    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), ann, parse_mode="HTML")
        except Exception:
            pass
    try:
        from bot.data.announcements_db import save_announcement
        from bot.data.season_db import get_current_season
        save_announcement(
            f"✅ {coach_name} {team_name} жамоасига тайинланди.",
            get_current_season(),
        )
    except Exception:
        pass

CALLBACK_PREFIX = "reg_team:"
PLAYERS_REQUIRED = 3


class RegisterForm(StatesGroup):
    waiting_for_team = State()
    waiting_for_coach_name = State()
    waiting_for_players = State()


def _build_team_keyboard(teams: list[str]) -> InlineKeyboardMarkup:
    rows = []
    for team in sorted(teams):
        rows.append([InlineKeyboardButton(text=team, callback_data=f"{CALLBACK_PREFIX}{team}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ── /register ─────────────────────────────────────────────────────────────────

@router.message(Command("register"))
async def cmd_register(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    user_id = message.from_user.id

    if is_registered(user_id):
        # Coach registered but squad not saved yet (e.g. bot restarted mid-flow)
        coach_info = get_coach_team(user_id)
        if coach_info and not coach_info["players"]:
            team_name = coach_info["team"]
            await state.update_data(team=team_name, players_collected=[])
            await state.set_state(RegisterForm.waiting_for_players)
            await message.answer(
                f"⚽ <b>Жамоа Таркибини Тузиш — {team_name}</b>\n\n"
                f"Мавсум учун <b>{PLAYERS_REQUIRED} та ўйинчи</b> рўйхатдан ўтказишингиз шарт.\n"
                "Ўйинчилар белгилангандан кейин ўзгартириб бўлмайди.\n\n"
                "1-ўйинчи исмини киритинг:",
                parse_mode="HTML",
            )
            return
        await message.answer("⚠️ Сиз VFL Чемпионлар Лигасида аллақачон рўйхатдан ўтгансиз.")
        return

    available = get_available_teams()
    if not available:
        await message.answer("⚠️ Барча жамоалар банд. Рўйхатга олиш ёпилди.")
        return

    await state.set_state(RegisterForm.waiting_for_team)
    await message.answer(
        "🏟️ <b>VFL Чемпионлар Лигаси — Рўйхатга Олиш</b>\n\n"
        f"<b>{len(available)}</b> та жамоа ҳали бўш.\n"
        "Жамоангизни танланг:",
        reply_markup=_build_team_keyboard(available),
        parse_mode="HTML",
    )


# ── жамоа танлаш (inline callback) ───────────────────────────────────────────

@router.callback_query(RegisterForm.waiting_for_team, F.data.startswith(CALLBACK_PREFIX))
async def process_team_selection(callback: CallbackQuery, state: FSMContext) -> None:
    team_name = callback.data[len(CALLBACK_PREFIX):]

    available = get_available_teams()
    if team_name not in available:
        await callback.answer("⚠️ Бу жамоа банд бўлиб қолди. Бошқасини танланг.", show_alert=True)
        await callback.message.edit_reply_markup(reply_markup=_build_team_keyboard(available))
        return

    await state.update_data(team=team_name)
    await state.set_state(RegisterForm.waiting_for_coach_name)

    await callback.message.edit_text(
        f"✅ Сиз танладингиз: <b>{team_name}</b>\n\n"
        "Мураббий исмингизни киритинг:",
        parse_mode="HTML",
    )
    await callback.answer()


# ── мураббий исмини киритиш ───────────────────────────────────────────────────

@router.message(RegisterForm.waiting_for_coach_name)
async def process_coach_name(message: Message, state: FSMContext) -> None:
    coach_name = (message.text or "").strip()

    if not coach_name:
        await message.answer("⚠️ Мураббий исми бўш бўлиши мумкин эмас. Исмингизни киритинг:")
        return

    if len(coach_name) > 50:
        await message.answer("⚠️ Исм жуда узун (максимал 50 белги). Қайтадан уринг:")
        return

    data = await state.get_data()
    team_name = data.get("team")

    if not team_name:
        await state.clear()
        await message.answer("⚠️ Хато юз берди. Илтимос, /register ни қайтадан ишлатинг.")
        return

    try:
        license_no = register_coach(message.from_user.id, coach_name, team_name)
    except ValueError as e:
        await state.clear()
        await message.answer(f"⚠️ Рўйхатга олиш муваффақиятсиз: {e}\n/register ни қайтадан ишлатинг.")
        return

    await message.answer(
        "🎉 <b>Рўйхатга Олиш Муваффақиятли!</b>\n\n"
        f"👤 Мураббий: <b>{coach_name}</b>\n"
        f"🏟️ Жамоа: <b>{team_name}</b>\n"
        f"🪪 Лицензия: <code>{license_no}</code>",
        parse_mode="HTML",
    )

    await _announce_join(message.bot, coach_name, team_name)

    existing_players = get_team_players(team_name)
    if existing_players:
        await state.clear()
        await message.answer(
            "Жамоа таркибингиз аллақачон аниқланган. /predict орқали тахминларингизни беринг. ⚽"
        )
        return

    await state.update_data(
        coach=coach_name,
        license=license_no,
        players_collected=[],
    )
    await state.set_state(RegisterForm.waiting_for_players)
    await message.answer(
        f"⚽ <b>Жамоа Таркиби</b>\n\n"
        f"Мавсум учун <b>{PLAYERS_REQUIRED} та ўйинчи</b> рўйхатдан ўтказишингиз шарт.\n"
        "Ўйинчилар белгилангандан кейин ўзгартириб бўлмайди.\n\n"
        "1-ўйинчи исмини киритинг:",
        parse_mode="HTML",
    )


# ── ўйинчи исмларини йиғиш ────────────────────────────────────────────────────

@router.message(RegisterForm.waiting_for_players)
async def process_player_name(message: Message, state: FSMContext) -> None:
    player_name = (message.text or "").strip()

    if not player_name:
        await message.answer("⚠️ Ўйинчи исми бўш бўлиши мумкин эмас. Исм киритинг:")
        return

    if len(player_name) > 60:
        await message.answer("⚠️ Исм жуда узун (максимал 60 белги). Қайтадан уринг:")
        return

    data = await state.get_data()
    team_name = data.get("team")
    players_collected: list[str] = data.get("players_collected", [])

    player_name_lower = player_name.lower()

    # Жамоа ичида такрорий исм текшируви (катта-кичик ҳарфдан қатъий назар)
    if player_name_lower in [p.lower() for p in players_collected]:
        await message.answer(
            f"⚠️ <b>{player_name}</b> аллақачон жамоа таркибида. Бошқа исм киритинг:",
            parse_mode="HTML",
        )
        return

    # Лига бўйича глобал такрорий исм текшируви
    global_names = get_all_player_names_lower(exclude_team=team_name)
    if player_name_lower in global_names:
        await message.answer(
            f"⚠️ <b>{player_name}</b> бошқа жамоада аллақачон рўйхатдан ўтган.\n"
            "VFL Чемпионлар Лигасида ўйинчи исмлари ягона бўлиши керак.\n"
            "Бошқа исм киритинг:",
            parse_mode="HTML",
        )
        return

    players_collected.append(player_name)
    await state.update_data(players_collected=players_collected)

    collected = len(players_collected)

    if collected < PLAYERS_REQUIRED:
        await message.answer(
            f"✅ <b>{player_name}</b> қўшилди.\n\n"
            f"{collected + 1}-ўйинчи исмини киритинг:",
            parse_mode="HTML",
        )
        return

    # Барча 3 та ўйинчи йиғилди — сақлаш
    try:
        save_players(team_name, players_collected)
    except ValueError as e:
        await state.clear()
        await message.answer(f"⚠️ Ўйинчиларни сақлаш мумкин эмас: {e}")
        return

    await state.clear()

    squad_lines = "\n".join(
        f"  {i + 1}. {p}" for i, p in enumerate(players_collected)
    )
    await message.answer(
        f"🏟️ <b>Жамоа Таркиби Рўйхатдан Ўтди!</b>\n\n"
        f"<b>{team_name}</b>\n{squad_lines}\n\n"
        "Жамоа таркиби мавсум учун белгиланди. Омад! ⚽\n"
        "/predict орқали биринчи тахминингизни беринг.",
        parse_mode="HTML",
    )
