from bot.data.admin_ids import is_admin as _is_admin
"""
/deletematchday — Admin: delete a specific Match Day's data (current season only).

Deletes from db.json:
  • duel_results for that MD
  • results for fixtures of that MD  (md{N}_m1 … md{N}_m5)
  • predictions for fixtures of that MD

Does NOT delete:
  • HOF, rankings, standings, season archive
  • Other MDs' data

Scope: current active season only.
Past seasons have only summary archives — per-MD raw data is gone.
"""


from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

router = Router()
TOTAL_MATCHES = 5




# ── FSM ──────────────────────────────────────────────────────────────────────

class DeleteMDForm(StatesGroup):
    waiting_md_select      = State()
    waiting_text_confirm   = State()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _available_mds() -> list[int]:
    """Return MD numbers that have duel_results data in db.json."""
    import bot.data.db as _db
    data = _db._load()
    dr   = data.get("duel_results", {})
    nums = []
    for key in dr:
        try:
            nums.append(int(key))
        except ValueError:
            pass
    return sorted(nums)


def _md_kb(mds: list[int]) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []
    for md in mds:
        row.append(InlineKeyboardButton(
            text=f"MD {md}",
            callback_data=f"dmd:pick:{md}",
        ))
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="❌ Бекор қилиш", callback_data="dmd:cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _execute_delete_md(md: int) -> str:
    import bot.data.db as _db

    data = _db._load()
    done: list[str] = []

    # ── Duel results ──────────────────────────────────────────────────────────
    dr = data.get("duel_results", {})
    if str(md) in dr:
        del dr[str(md)]
        data["duel_results"] = dr
        done.append(f"🏟 MD {md} — дуэл натижалари ўчирилди")

    # ── Results (md{N}_m1 … md{N}_m5) ────────────────────────────────────────
    results = data.get("results", {})
    removed_results = 0
    for i in range(1, TOTAL_MATCHES + 1):
        key = f"md{md}_m{i}"
        if key in results:
            del results[key]
            removed_results += 1
    if removed_results:
        data["results"] = results
        done.append(f"📊 MD {md} — {removed_results} та матч натижаси ўчирилди")

    # ── Predictions for this MD ───────────────────────────────────────────────
    predictions = data.get("predictions", {})
    match_ids   = {f"md{md}_m{i}" for i in range(1, TOTAL_MATCHES + 1)}
    pred_count  = 0
    for tid, preds in predictions.items():
        before = len(preds)
        for mid in match_ids:
            preds.pop(mid, None)
        pred_count += before - len(preds)
    if pred_count:
        data["predictions"] = predictions
        done.append(f"🎯 MD {md} — {pred_count} та тахмин ўчирилди")

    # ── Playoff results for this MD's stage (optional) ────────────────────────
    from bot.handlers.closematchday import PLAYOFF_STAGE_MAP
    if md in PLAYOFF_STAGE_MAP:
        stage, leg = PLAYOFF_STAGE_MAP[md]
        playoff_res = data.get("playoff_results", {})
        if stage in playoff_res:
            del playoff_res[stage]
            data["playoff_results"] = playoff_res
            done.append(f"🏆 {stage} плей-офф натижаси ўчирилди")

    _db._save(data)

    if not done:
        return "⚠️ Ўчириладиган маълумот топилмади."
    return "\n".join(f"✅ {d}" for d in done)


# ── /deletematchday command ───────────────────────────────────────────────────

@router.message(Command("deletematchday"))
async def cmd_deletematchday(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    from bot.data.season_db import get_current_season
    season = get_current_season()
    mds    = _available_mds()

    if not mds:
        await message.answer(
            f"⚠️ {season}-мавсум учун ўчирилиши мумкин Match Day маълумоти мавжуд эмас."
        )
        return

    await state.set_state(DeleteMDForm.waiting_md_select)
    await message.answer(
        f"🗑 <b>Match Day ўчириш</b>\n\n"
        f"📅 Жорий мавсум: <b>{season}-мавсум</b>\n\n"
        "Ўчирмоқчи бўлган Match Day'ни танланг:",
        reply_markup=_md_kb(mds),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("dmd:pick:"))
async def cb_md_pick(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    md = int(callback.data.split(":")[-1])
    await state.update_data(md=md)
    await state.set_state(DeleteMDForm.waiting_text_confirm)

    from bot.data.season_db import get_current_season
    season = get_current_season()

    await callback.message.edit_text(
        f"⚠️ <b>ДИҚҚАТ!</b>\n\n"
        f"Сиз <b>Match Day #{md}</b> ({season}-мавсум) ни ўчирмоқчисиз.\n\n"
        "Қуйидагилар ўчирилади:\n\n"
        "• Матч дуэл натижалари\n"
        "• Барча матч натижалари\n"
        "• Барча тахминлар\n"
        "• Match Day ҳисобланган маълумотлари\n\n"
        "<b>Бу амални бекор қилиб бўлмайди.</b>\n\n"
        "Тасдиқлаш учун аниқ ёзинг:\n\n"
        f"<code>DELETE MD {md}</code>",
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "dmd:cancel")
async def cb_md_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("❌ Амалиёт бекор қилинди.")
    await callback.answer()


@router.message(DeleteMDForm.waiting_text_confirm)
async def process_md_text_confirm(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    data = await state.get_data()
    md   = data.get("md")
    text = (message.text or "").strip()
    expected = f"DELETE MD {md}"

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди.")
        return

    if text != expected:
        await message.answer(
            f"⚠️ Нотўғри матн. Аниқ қуйидагини ёзинг:\n\n"
            f"<code>{expected}</code>",
            parse_mode="HTML",
        )
        return

    await state.clear()
    summary = _execute_delete_md(md)
    await message.answer(
        f"🗑 <b>Match Day #{md} ўчирилди</b>\n\n{summary}",
        parse_mode="HTML",
    )
