from bot.data.admin_ids import is_admin as _is_admin
"""
/setdate  — interactive stage picker + date entry (admin only, FSM).
/dates    — show all stored dates.
/resetdates — wipe all dates (with confirmation).
"""


from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.dates_db import (
    STAGE_LABELS,
    STAGE_ORDER,
    VALID_STAGES,
    get_all_dates,
    get_date,
    reset_dates,
    set_date,
)

router = Router()





# ── FSM ────────────────────────────────────────────────────────────────────────

class SetDateSG(StatesGroup):
    waiting_date = State()


# ── Callback data constants ────────────────────────────────────────────────────

_CB_STAGE_PFX = "setdate:stage:"
_CB_CLOSE     = "setdate:close"


# ── Keyboard builders ──────────────────────────────────────────────────────────

def _stage_picker_kb() -> InlineKeyboardMarkup:
    rows = []
    # League rounds — two per row
    round_keys = [str(r) for r in range(1, 9)]
    for i in range(0, len(round_keys), 2):
        pair = round_keys[i:i + 2]
        rows.append([
            InlineKeyboardButton(
                text=STAGE_LABELS[k],
                callback_data=f"{_CB_STAGE_PFX}{k}",
            )
            for k in pair
        ])
    # Playoff / knockout stages — one per row
    for key in ("playoff", "round16", "quarterfinal", "semifinal", "final"):
        rows.append([InlineKeyboardButton(
            text=STAGE_LABELS[key],
            callback_data=f"{_CB_STAGE_PFX}{key}",
        )])
    # Close button
    rows.append([InlineKeyboardButton(text="✅ Тайёр", callback_data=_CB_CLOSE)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ── /setdate ───────────────────────────────────────────────────────────────────

@router.message(Command("setdate"))
async def cmd_setdate(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    # Legacy inline usage: /setdate <stage> <date> — keep working
    parts = (message.text or "").split(maxsplit=2)
    if len(parts) == 3:
        stage    = parts[1].lower()
        date_str = parts[2].strip()
        if stage not in VALID_STAGES:
            valid_list = " · ".join(STAGE_ORDER)
            await message.answer(
                f"❌ Нотўғри босқич: <code>{stage}</code>\n\n"
                f"Мумкин: {valid_list}",
            )
            return
        existing = get_date(stage)
        if existing:
            label = STAGE_LABELS[stage]
            await message.answer(
                f"⚠️ Ушбу босқич учун сана аллақачон белгиланган.\n\n"
                f"📅 Жорий сана:\n{existing}\n\n"
                "Санани ўзгартириш учун /editdate командасидан фойдаланинг.",
            )
            return
        set_date(stage, date_str)
        label = STAGE_LABELS[stage]
        await message.answer(
            f"✅ <b>Тур санаси сақланди</b>\n\n"
            f"{label}\n\n"
            f"📅 {date_str}",
        )
        return

    # Interactive mode — show stage picker
    await state.clear()
    await message.answer(
        "📅 <b>Тур санасини белгилаш</b>\n\n"
        "Қайси босқич учун сана киритмоқчисиз?",
        reply_markup=_stage_picker_kb(),
    )


# ── Stage selected callback ────────────────────────────────────────────────────

@router.callback_query(F.data.startswith(_CB_STAGE_PFX))
async def cb_stage_selected(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    stage = callback.data[len(_CB_STAGE_PFX):]
    if stage not in VALID_STAGES:
        await callback.answer("⚠️ Нотўғри босқич.", show_alert=True)
        return

    label    = STAGE_LABELS[stage]
    existing = get_date(stage)

    if existing:
        await callback.message.edit_text(
            f"⚠️ Ушбу босқич учун сана аллақачон белгиланган.\n\n"
            f"📅 Жорий сана:\n{existing}\n\n"
            "Санани ўзгартириш учун /editdate командасидан фойдаланинг.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="⬅️ Орқага", callback_data="setdate:back"),
            ]]),
        )
        await callback.answer()
        return

    await state.set_state(SetDateSG.waiting_date)
    await state.update_data(stage=stage, label=label)

    await callback.message.edit_text(
        f"{label}\n\n"
        "Санани киритинг:\n\n"
        "Масалан:\n"
        "<code>15.09.2026</code>\n\n"
        "ёки\n\n"
        "<code>17-19.09.2026</code>",
    )
    await callback.answer()


# ── Back to picker ─────────────────────────────────────────────────────────────

@router.callback_query(F.data == "setdate:back")
async def cb_setdate_back(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "📅 <b>Тур санасини белгилаш</b>\n\n"
        "Қайси босқич учун сана киритмоқчисиз?",
        reply_markup=_stage_picker_kb(),
    )
    await callback.answer()


# ── Close (✅ Тайёр) ───────────────────────────────────────────────────────────

@router.callback_query(F.data == _CB_CLOSE)
async def cb_setdate_close(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("✅ Ўзгаришлар сақланди.")
    await callback.answer()


# ── Date text input ────────────────────────────────────────────────────────────

@router.message(SetDateSG.waiting_date)
async def msg_date_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    date_str = (message.text or "").strip()
    if date_str.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return
    if not date_str:
        await message.answer("❌ Сана бўш бўлиши мумкин эмас. Илтимос, қайта киритинг.")
        return

    data  = await state.get_data()
    stage: str = data["stage"]
    label: str = data["label"]

    set_date(stage, date_str)
    await state.clear()

    await message.answer(
        f"✅ <b>Тур санаси сақланди</b>\n\n"
        f"{label}\n\n"
        f"📅 {date_str}",
    )


# ── /dates ─────────────────────────────────────────────────────────────────────

@router.message(Command("dates"))
async def cmd_dates(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    all_dates = get_all_dates()

    lines = ["📅 <b>Мавсум саналари</b>\n"]

    lines.append("⚽ <b>Лига босқичи</b>")
    for stage in [str(r) for r in range(1, 9)]:
        label = STAGE_LABELS[stage]
        date  = all_dates.get(stage)
        lines.append(f"  {label} — {date if date else '—'}")

    lines.append("")

    lines.append("🔥 <b>Плей-офф</b>")
    for stage in ("playoff", "round16", "quarterfinal", "semifinal", "final"):
        label = STAGE_LABELS[stage]
        date  = all_dates.get(stage)
        lines.append(f"  {label} — {date if date else '—'}")

    await message.answer("\n".join(lines))


# ── /resetdates ────────────────────────────────────────────────────────────────

_RD_CONFIRM = "resetdates:confirm"
_RD_CANCEL  = "resetdates:cancel"


@router.message(Command("resetdates"))
async def cmd_resetdates(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    await message.answer(
        "⚠️ <b>Барча саналарни ўчириш</b>\n\n"
        "Барча мавсум санaлари батамом ўчирилади.\n"
        "Тасдиқлайсизми?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Ҳа",  callback_data=_RD_CONFIRM),
            InlineKeyboardButton(text="❌ Йўқ", callback_data=_RD_CANCEL),
        ]]),
    )


@router.callback_query(F.data == _RD_CONFIRM)
async def cb_resetdates_confirm(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⚠️ Рухсат йўқ.", show_alert=True)
        return
    reset_dates()
    await callback.message.edit_text("🗑 Барча саналар ўчирилди.")
    await callback.answer()


@router.callback_query(F.data == _RD_CANCEL)
async def cb_resetdates_cancel(callback: CallbackQuery) -> None:
    await callback.message.edit_text("❌ Ўчириш бекор қилинди.")
    await callback.answer()
