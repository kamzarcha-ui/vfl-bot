"""
Automatic deadline notifications.

Runs as a background asyncio task started from main.py.
Checks every 60 seconds and fires two notifications per deadline:

  1. One-hour warning  — when 0 < seconds_left <= 3600
  2. Deadline expired  — when seconds_left <= 0

Both are sent as private DMs to every registered participant exactly
once, keyed by the deadline ISO string so flags survive bot restarts
and reset automatically when a new deadline is set.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone

from aiogram import Bot

from bot.data.deadline_db import get_deadline
from bot.data.matchday_db import get_matchday, is_matchday_closed
from bot.data.notifications_db import is_sent, mark_sent
from bot.data.teams_db import load_teams
from bot.data.db import get_predictions

logger = logging.getLogger(__name__)

MSK                 = timezone(timedelta(hours=3))
CHECK_INTERVAL      = 60        # seconds
PREDICTIONS_COUNT   = 5


# ── Participant analysis ──────────────────────────────────────────────────────

def _participant_status(match_day: int) -> tuple[list[dict], list[dict]]:
    """
    Return (submitted, not_submitted).
    Each entry: {"team": str, "coach": str}
    "submitted" = all 5 fixture predictions present.

    Uses load_teams() (all 36 league teams) as the denominator so that
    not_submitted = total_teams - submitted, not just registered_via_bot - submitted.
    """
    teams_data  = load_teams()
    fixture_ids = [f"md{match_day}_m{i + 1}" for i in range(PREDICTIONS_COUNT)]

    submitted:     list[dict] = []
    not_submitted: list[dict] = []

    for team, info in teams_data.items():
        coach   = info.get("coach", "—")
        tid_str = info.get("telegram_id")

        has_all = False
        if tid_str:
            try:
                preds   = get_predictions(int(tid_str))
                has_all = all(fid in preds for fid in fixture_ids)
            except (ValueError, TypeError):
                pass

        bucket = submitted if has_all else not_submitted
        bucket.append({"team": team, "coach": coach})

    return submitted, not_submitted


def _team_line(entry: dict) -> str:
    return f"🏟 {entry['team']}\n  👤 {entry['coach']}"


# ── Message builders ──────────────────────────────────────────────────────────

def _build_one_hour(submitted: list[dict], not_submitted: list[dict]) -> str:
    parts = [
        "⏳ <b>Match Day дедлайнига 1 соат қолди.</b>",
        "",
        "⚽ Тахминларингизни текшириб олинг:",
        "/predict",
        "",
        "━━━━━━━━━━━━━━━━━━━━",
        "",
        "📊 <b>Ҳозирги ҳолат</b>",
        "",
        f"✅ Тахмин киритганлар: {len(submitted)}",
        f"❌ Ҳали киритмаганлар: {len(not_submitted)}",
    ]

    if not_submitted:
        parts += [
            "",
            "━━━━━━━━━━━━━━━━━━━━",
            "",
            "❌ <b>Тахмин киритмаган жамоалар:</b>",
            "",
        ]
        for e in not_submitted:
            parts.append(f"• {_team_line(e)}")

    return "\n".join(parts)


def _build_expired(submitted: list[dict], not_submitted: list[dict]) -> str:
    total = len(submitted) + len(not_submitted)
    pct   = round(len(submitted) / total * 100) if total else 0

    parts = [
        "🔒 <b>Match Day дедлайни якунланди</b>",
        "",
        "📝 Тахмин қабул қилиш тўхтатилди.",
        "",
        "━━━━━━━━━━━━━━━━━━━━",
    ]

    if submitted:
        parts += [
            "",
            f"✅ <b>Тахмин топширган жамоалар ({len(submitted)})</b>",
            "",
        ]
        for e in submitted:
            parts.append(f"• {_team_line(e)}")

    parts += ["", "━━━━━━━━━━━━━━━━━━━━"]

    if not_submitted:
        parts += [
            "",
            f"❌ <b>Тахмин топширмаган жамоалар ({len(not_submitted)})</b>",
            "",
        ]
        for e in not_submitted:
            parts.append(f"• {_team_line(e)}")
        parts.append("")
        parts.append("━━━━━━━━━━━━━━━━━━━━")

    parts += [
        "",
        "📊 <b>Қамров:</b>",
        "",
        f"{len(submitted)} / {total} ({pct}%)",
        "",
        "━━━━━━━━━━━━━━━━━━━━",
        "",
        "🏟 Match Day натижалари кутилмоқда.",
    ]

    return "\n".join(parts)


# ── DM broadcast helper ───────────────────────────────────────────────────────

async def _broadcast(bot: Bot, text: str) -> int:
    """Send text as a private DM to every registered participant. Returns send count."""
    teams = load_teams()
    sent  = 0
    for info in teams.values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), text, parse_mode="HTML")
            sent += 1
        except Exception:
            pass
    return sent


# ── Background loop ───────────────────────────────────────────────────────────

async def notification_loop(bot: Bot) -> None:
    while True:
        try:
            await _check_and_notify(bot)
        except Exception:
            logger.exception("Notification check failed")
        await asyncio.sleep(CHECK_INTERVAL)


async def _check_and_notify(bot: Bot) -> None:
    dl = get_deadline()
    if not dl:
        return

    if is_matchday_closed():
        return

    md = get_matchday()
    if not md:
        return
    match_day = md["match_day"]

    iso         = dl["deadline_iso"]
    deadline_dt = datetime.strptime(iso, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=MSK)
    now         = datetime.now(MSK)
    secs_left   = (deadline_dt - now).total_seconds()

    key_one_hour = f"{iso}_one_hour"
    key_expired  = f"{iso}_expired"

    if 0 < secs_left <= 3600 and not is_sent(key_one_hour):
        submitted, not_submitted = _participant_status(match_day)
        text = _build_one_hour(submitted, not_submitted)
        n = await _broadcast(bot, text)
        mark_sent(key_one_hour)
        logger.info("Sent 1-hour deadline warning for MD%s to %d participants", match_day, n)

    elif secs_left <= 0 and not is_sent(key_expired):
        submitted, not_submitted = _participant_status(match_day)
        text = _build_expired(submitted, not_submitted)
        n = await _broadcast(bot, text)
        mark_sent(key_expired)
        logger.info("Sent deadline-expired notification for MD%s to %d participants", match_day, n)
