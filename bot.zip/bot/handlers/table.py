from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.db import get_standings

router = Router()

MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}


@router.message(Command("table"))
async def cmd_table(message: Message) -> None:
    standings = get_standings()

    if not standings:
        await message.answer("📊 Жадвал маълумоти ҳали мавжуд эмас.")
        return

    lines = ["🏆 <b>VFL Чемпионлар Лигаси — Ўйин жадвали</b>\n"]
    lines.append("<pre>")
    lines.append(f"{'#':<3} {'Жамоа':<16} {'О':>2} {'Г':>2} {'Д':>2} {'М':>2} {'ГФ':>4} {'Очко':>5}")
    lines.append("─" * 40)

    for row in standings:
        medal = MEDALS.get(row["pos"], "  ")
        lines.append(
            f"{medal}{row['pos']:<2} {row['team']:<16} "
            f"{row['p']:>2} {row['w']:>2} {row['d']:>2} {row['l']:>2} "
            f"{row['gd']:>4} {row['pts']:>5}"
        )

    lines.append("</pre>")
    await message.answer("\n".join(lines), parse_mode="HTML")
