from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()

_SHOW = 15


@router.message(Command("sensations"))
async def cmd_sensations(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.sensations_db import load_sensations

    sensations = load_sensations()   # newest first

    if not sensations:
        await message.answer(
            "🔥 <b>Сенсациялар</b>\n\n"
            "Ҳозирча сенсациялар мавжуд эмас.\n\n"
            "Кутилмаган натижалар, улкан ғалабалар ва сюрпризлар "
            "матч кунлари якунида автоматик аниқланади.",
            parse_mode="HTML",
        )
        return

    items = sensations[:_SHOW]
    lines = [f"🔥 <b>VFL СЕНСАЦИЯЛАР</b>  <i>(сўнгги {len(items)} та)</i>"]

    for item in items:
        icon     = item.get("icon", "🔥")
        headline = item.get("headline", "")
        body     = item.get("body", "")
        date     = item.get("date", "")
        md       = item.get("match_day", "")

        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"{icon} <b>{headline}</b>")
        if date or md:
            meta = f"MD#{md}  {date}".strip() if md else date
            lines.append(f"<i>{meta}</i>")
        if body:
            lines.append(body)

    if len(sensations) > _SHOW:
        lines.append(f"\n<i>…яна {len(sensations) - _SHOW} та сенсация мавжуд</i>")

    text = "\n".join(lines)
    await message.answer(text[:4096], parse_mode="HTML")
