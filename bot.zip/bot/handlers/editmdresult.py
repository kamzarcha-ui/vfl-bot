from bot.data.admin_ids import is_admin as _is_admin
"""
/editmdresult — edit an individual match result for the current Match Day (admin only).

Scoring stats are NOT recalculated — only the stored score string is updated.
"""

import re

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.db import get_result, update_result_score
from bot.data.matchday_db import get_matchday, matchday_exists

router = Router()

SCORE_RE  = re.compile(r"^\d{1,2}-\d{1,2}$")




def _fixture_id(match_day: int, idx: int) -> str:
    return f"md{match_day}_m{idx + 1}"


class EditMdResultForm(StatesGroup):
    waiting_new_score = State()


_CB_MATCH_PFX = "emdr:match:"
_CB_CLOSE     = "emdr:close"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _results_exist(match_day: int) -> bool:
    """True if at least the first fixture has a saved result."""
    return get_result(_fixture_id(match_day, 0)) is not None


def _result_list_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"✏️ {i}-ўйин", callback_data=f"{_CB_MATCH_PFX}{i - 1}")]
        for i in range(1, 6)
    ]
    rows.append([InlineKeyboardButton(text="✅ Тайёр", callback_data=_CB_CLOSE)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _format_result_list(md: dict) -> str:
    n      = md["match_day"]
    lines  = ["🏆 <b>Match Day натижаларини ўзгартириш</b>\n"]
    for i, fx in enumerate(md["fixtures"], 1):
        mid    = _fixture_id(n, i - 1)
        result = get_result(mid)
        score  = result["score"] if result else "—"
        lines.append(f"{i}. {fx['home']} vs {fx['away']} → {score}")
    return "\n".join(lines)


# ── /editmdresult ──────────────────────────────────────────────────────────────

@router.message(Command("editmdresult"))
async def cmd_editmdresult(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        await message.answer("⛔ Сизда админ ҳуқуқи мавжуд эмас.")
        return

    from bot.data.matchday_db import is_matchday_closed
    if is_matchday_closed():
        await message.answer(
            "⚠️ Match Day якунланган.\n\nНатижаларни ўзгартириш мумкин эмас."
        )
        return

    if not matchday_exists():
        await message.answer(
            "⚠️ Ҳозирча Match Day натижалари киритилмаган.\n\n"
            "Аввал /setmdresult орқали натижаларни киритинг."
        )
        return

    md = get_matchday()
    if not _results_exist(md["match_day"]):
        await message.answer(
            "⚠️ Ҳозирча Match Day натижалари киритилмаган.\n\n"
            "Аввал /setmdresult орқали натижаларни киритинг."
        )
        return

    await state.clear()
    await message.answer(
        _format_result_list(md),
        reply_markup=_result_list_kb(),
    )


# ── Match button callback ──────────────────────────────────────────────────────

@router.callback_query(F.data.startswith(_CB_MATCH_PFX))
async def cb_select_result_match(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    try:
        idx = int(callback.data[len(_CB_MATCH_PFX):])
    except ValueError:
        await callback.answer("⚠️ Хато.", show_alert=True)
        return

    md = get_matchday()
    if not md or idx < 0 or idx >= len(md["fixtures"]):
        await callback.answer("⚠️ Match Day мавжуд эмас.", show_alert=True)
        return

    fx     = md["fixtures"][idx]
    mid    = _fixture_id(md["match_day"], idx)
    result = get_result(mid)
    old_score = result["score"] if result else "—"

    await state.set_state(EditMdResultForm.waiting_new_score)
    await state.update_data(idx=idx, mid=mid, old_score=old_score, md_n=md["match_day"])

    await callback.message.edit_text(
        f"⚽ <b>{idx + 1}-ўйин</b>\n\n"
        f"{fx['home']} vs {fx['away']}\n\n"
        f"Жорий натижа: <b>{old_score}</b>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "Янги натижани киритинг:\n\n"
        "Масалан: <code>3-1</code>",
    )
    await callback.answer()


# ── ✅ Тайёр ──────────────────────────────────────────────────────────────────

@router.callback_query(F.data == _CB_CLOSE)
async def cb_emdr_close(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("✅ Ўзгаришлар сақланди.")
    await callback.answer()


# ── New score text input ───────────────────────────────────────────────────────

@router.message(EditMdResultForm.waiting_new_score, ~F.text.startswith("/"))
async def msg_new_score(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()

    if not SCORE_RE.match(text):
        await message.answer(
            "⚠️ Нотўғри формат.\n\n"
            "Масалан: <code>3-1</code>",
        )
        return

    data      = await state.get_data()
    mid: str  = data["mid"]
    old_score: str = data["old_score"]
    idx: int  = data["idx"]
    md_n: int = data["md_n"]

    update_result_score(mid, text)
    await state.clear()

    await message.answer(
        f"✅ <b>Натижа янгиланди</b>\n\n"
        f"Эски натижа:\n{old_score}\n\n"
        f"Янги натижа:\n{text}",
    )

    # Return to updated list
    md = get_matchday()
    if md:
        await message.answer(
            _format_result_list(md),
            reply_markup=_result_list_kb(),
        )
