import re
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.db import (
    get_fixtures_by_ids,
    get_matchup_for_coach,
    get_opponent_scorelines,
    get_predictions,
    save_prediction,
)
from bot.data.draw_db import get_round_fixtures
from bot.data.teams_db import load_teams
from bot.data.deadline_db import deadline_display, is_deadline_passed
from bot.data.matchday_db import get_matchday, is_matchday_closed
from bot.data.matchday_state_db import is_matchday_active
from bot.data.teams_db import get_coach_team

router = Router()

SCORE_RE               = re.compile(r"^\d{1,2}-\d{1,2}$")
PLAYER_PREFIX          = "pred_player:"
PRED_EDIT_MATCH_PREFIX = "pred:edit:"   # + str(idx),  e.g. "pred:edit:2"
PRED_CANCEL_CB         = "pred:cancel"
MAX_PLAYER_MATCHES     = 2
PREDICTIONS_PER_ROUND  = 5


class PredictForm(StatesGroup):
    waiting_for_score     = State()   # new prediction full flow — score step
    waiting_for_player    = State()   # new prediction full flow — player step
    editing_single_score  = State()   # single-match edit — score step
    editing_single_player = State()   # single-match edit — player step


# ── keyboards ────────────────────────────────────────────────────────────────

def _player_keyboard(players: list[str], counts: dict[str, int]) -> InlineKeyboardMarkup:
    rows = []
    for p in players:
        used = counts.get(p, 0)
        if used < MAX_PLAYER_MATCHES:
            label = f"{p}  ({used}/{MAX_PLAYER_MATCHES})"
            rows.append([InlineKeyboardButton(text=label, callback_data=f"{PLAYER_PREFIX}{p}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _edit_buttons(fixtures: list) -> InlineKeyboardMarkup:
    """5 per-match edit buttons + cancel."""
    rows = [
        [InlineKeyboardButton(
            text=f"✏️ {i + 1}-матч",
            callback_data=f"{PRED_EDIT_MATCH_PREFIX}{i}",
        )]
        for i in range(len(fixtures))
    ]
    rows.append([InlineKeyboardButton(text="✅ Тайёр", callback_data=PRED_CANCEL_CB)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ── draw-based opponent lookup (Match Day mode) ───────────────────────────────

def _get_draw_matchup(user_id: int, match_day: int, md_fixture_ids: list[str]) -> dict | None:
    """
    Build a matchup dict from draw.json pairings for duplicate-score checking.
    Returns {"coach_a": str, "coach_b": str, "fixture_ids": [...]} or None.
    """
    coach_info = get_coach_team(user_id)
    if not coach_info:
        return None
    my_team = coach_info["team"]

    opponent_team: str | None = None
    for fx in get_round_fixtures(match_day):
        if fx["home"] == my_team:
            opponent_team = fx["away"]
            break
        elif fx["away"] == my_team:
            opponent_team = fx["home"]
            break

    if not opponent_team:
        return None

    teams = load_teams()
    opponent_tid = teams.get(opponent_team, {}).get("telegram_id")
    if not opponent_tid:
        return None

    return {
        "coach_a": str(user_id),
        "coach_b": str(opponent_tid),
        "fixture_ids": md_fixture_ids,
    }


# ── helpers ───────────────────────────────────────────────────────────────────

def _counts_from_saved(predictions: dict, fixtures: list, players: list[str]) -> dict[str, int]:
    counts: dict[str, int] = {p: 0 for p in players}
    for match in fixtures:
        pred = predictions.get(match["id"])
        if pred:
            player = pred.get("player", "")
            if player in counts:
                counts[player] += 1
    return counts


def _build_summary(fixtures: list, existing: dict) -> str:
    lines = []
    for i, m in enumerate(fixtures):
        pred = existing.get(m["id"])
        if pred:
            lines.append(
                f"{i + 1}. {m['home']} vs {m['away']}\n"
                f"   📊 {pred['score']}\n"
                f"   👤 {pred['player']}"
            )
        else:
            lines.append(f"{i + 1}. {m['home']} vs {m['away']}\n   —")
    return "\n\n".join(lines)


async def _load_fixtures_for_user(
    user_id: int,
    reply_target: Message,
) -> "tuple[list, dict | None, int] | None":
    """
    Resolve fixtures for the current match day.
    Returns (fixtures, matchup_or_None, round_no) or None if unavailable.
    """
    if is_matchday_active():
        md = get_matchday()
        if not md:
            await reply_target.answer("⚠️ Match Day мавжуд эмас. Ўйинлар қўйилишини кутинг.")
            return None
        n = md["match_day"]
        fixtures = [
            {
                "id":   f"md{n}_m{i + 1}",
                "home": fx["home"],
                "away": fx["away"],
                "date": "",
            }
            for i, fx in enumerate(md["fixtures"])
        ]
        # Resolve opponent from draw.json (round == match_day number).
        # fixture_ids are set to md{n}_m* so get_opponent_scorelines
        # filters the opponent's predictions by the correct keys.
        md_fixture_ids = [f["id"] for f in fixtures]
        matchup = _get_draw_matchup(user_id, n, md_fixture_ids)
        return fixtures, matchup, n

    # Legacy matchup mode
    from bot.data.db import get_fixtures as _get_fixtures
    all_fx = _get_fixtures()
    if not all_fx:
        await reply_target.answer("⏳ Илтимос, администратор турни бошлашини кутинг.")
        return None
    current_round = max(f["round"] for f in all_fx)
    matchup = get_matchup_for_coach(user_id, current_round)
    if not matchup:
        await reply_target.answer("⏳ Илтимос, администратор турни бошлашини кутинг.")
        return None
    fixture_ids: list[str] = matchup.get("fixture_ids", [])
    if len(fixture_ids) != PREDICTIONS_PER_ROUND:
        await reply_target.answer(
            f"⚠️ Ушбу дуэлда айнан {PREDICTIONS_PER_ROUND} та матч бўлиши керак. "
            "Администратор билан боғланинг."
        )
        return None
    fixtures = get_fixtures_by_ids(fixture_ids)
    if len(fixtures) != PREDICTIONS_PER_ROUND:
        await reply_target.answer("⚠️ Дуэл матчларининг баъзилари топилмади. Администратор билан боғланинг.")
        return None
    return fixtures, matchup, current_round


async def _launch_flow(
    user_id:       int,
    reply_target:  Message,
    state:         FSMContext,
    fixtures:      list,
    matchup:       dict | None,
    current_round: int,
    players:       list[str],
    team:          str,
) -> None:
    """Set FSM state and start the full 5-match score-collection flow."""
    existing      = get_predictions(user_id)
    player_counts = _counts_from_saved(existing, fixtures, players)
    await state.set_data({
        "fixtures":      fixtures,
        "round":         current_round,
        "matchup":       matchup,
        "index":         0,
        "score":         None,
        "player_counts": player_counts,
        "players":       players,
        "team":          team,
    })
    await state.set_state(PredictForm.waiting_for_score)
    await _ask_score(reply_target, fixtures, 0, existing)


def _store_edit_context(
    fixtures: list,
    matchup:  dict | None,
    round_no: int,
    players:  list[str],
    team:     str,
) -> dict:
    """Build the dict of edit-context keys stored in FSM state."""
    return {
        "_edit_fixtures": fixtures,
        "_edit_matchup":  matchup,
        "_edit_round":    round_no,
        "_edit_players":  players,
        "_edit_team":     team,
    }


# ── /predict ──────────────────────────────────────────────────────────────────

@router.message(Command("predict"))
async def cmd_predict(message: Message, state: FSMContext, user_id: int | None = None) -> None:
    user_id = user_id or message.from_user.id

    # ── Registration & player checks ──────────────────────────────────────────
    coach_info = get_coach_team(user_id)
    if not coach_info:
        await message.answer(
            "⚠️ Тахмин киритишдан олдин рўйхатдан ўтишингиз керак.\n"
            "/register орқали лигага қўшилинг."
        )
        return

    players = coach_info["players"]
    if not players:
        await message.answer(
            "⚠️ Жамоа таркибингизда ўйинчилар йўқ. Аввал /register ни якунланг."
        )
        return

    # ── Closed matchday check ─────────────────────────────────────────────────
    if is_matchday_closed():
        await message.answer(
            "🔒 <b>Тур якунланган.</b>\n\n"
            "Тахмин қабул қилиш ёпилди. Кейинги турни кутинг.",
            parse_mode="HTML",
        )
        return

    # ── Resolve fixtures ──────────────────────────────────────────────────────
    result = await _load_fixtures_for_user(user_id, message)
    if result is None:
        return
    fixtures, matchup, current_round = result

    # ── Existing prediction check ─────────────────────────────────────────────
    existing      = get_predictions(user_id)
    has_all       = all(m["id"] in existing for m in fixtures)
    deadline_over = is_deadline_passed()

    if has_all:
        summary_body = _build_summary(fixtures, existing)

        if deadline_over:
            await message.answer(
                "🔒 <b>Тахмин қабул қилиш муддати тугаган.</b>\n\n"
                "📝 <b>Сизнинг сўнгги тахминларингиз</b>\n\n"
                + summary_body,
                parse_mode="HTML",
            )
        else:
            await state.set_data(_store_edit_context(
                fixtures, matchup, current_round, players, coach_info["team"]
            ))
            await message.answer(
                "📝 <b>Сизнинг тахминларингиз</b>\n\n" + summary_body,
                reply_markup=_edit_buttons(fixtures),
                parse_mode="HTML",
            )
        return

    # ── No predictions yet ────────────────────────────────────────────────────
    if deadline_over:
        dl = deadline_display()
        date_line = f"{dl[0]} • {dl[1]}" if dl else "—"
        await message.answer(
            "🔒 <b>Тахмин қабул қилиш муддати тугаган.</b>\n\n"
            f"⏰ Муддат:\n{date_line} (Москва вақти)",
            parse_mode="HTML",
        )
        return

    await _launch_flow(
        user_id, message, state,
        fixtures, matchup, current_round,
        players, coach_info["team"],
    )


# ── per-match edit callback ───────────────────────────────────────────────────

@router.callback_query(F.data.startswith(PRED_EDIT_MATCH_PREFIX))
async def cb_pred_edit_match(callback: CallbackQuery, state: FSMContext) -> None:
    user_id = callback.from_user.id

    # Matchday may have closed since the summary was shown
    if is_matchday_closed():
        await callback.message.edit_text(
            "🔒 <b>Тур якунланган.</b>\n\n"
            "Тахмин қабул қилиш ёпилди. Кейинги турни кутинг.",
            parse_mode="HTML",
        )
        await callback.answer()
        return

    # Deadline may have passed since the summary was shown
    if is_deadline_passed():
        existing = get_predictions(user_id)
        data     = await state.get_data()
        fixtures = data.get("_edit_fixtures") or []
        summary_body = _build_summary(fixtures, existing) if fixtures else ""
        await callback.message.edit_text(
            "🔒 <b>Тахмин қабул қилиш муддати тугаган.</b>\n\n"
            "📝 <b>Сизнинг сўнгги тахминларингиз</b>\n\n"
            + summary_body,
            parse_mode="HTML",
        )
        await state.clear()
        await callback.answer()
        return

    try:
        idx = int(callback.data[len(PRED_EDIT_MATCH_PREFIX):])
    except ValueError:
        await callback.answer("⚠️ Хато.", show_alert=True)
        return

    data     = await state.get_data()
    fixtures = data.get("_edit_fixtures")
    matchup  = data.get("_edit_matchup")
    round_no = data.get("_edit_round")
    players  = data.get("_edit_players")
    team     = data.get("_edit_team")

    # Fallback re-derive (bot restarted between summary and tap)
    if not fixtures or not players:
        coach_info = get_coach_team(user_id)
        if not coach_info:
            await callback.answer("⚠️ Хато юз берди.", show_alert=True)
            return
        result = await _load_fixtures_for_user(user_id, callback.message)
        if result is None:
            await callback.answer()
            return
        fixtures, matchup, round_no = result
        players = coach_info["players"]
        team    = coach_info["team"]

    if idx < 0 or idx >= len(fixtures):
        await callback.answer("⚠️ Нотўғри матч рақами.", show_alert=True)
        return

    match    = fixtures[idx]
    existing = get_predictions(user_id)
    pred     = existing.get(match["id"])

    # Counts adjusted: un-assign current player for this match so they're free to re-pick
    counts = _counts_from_saved(existing, fixtures, players)
    if pred and pred.get("player") in counts:
        counts[pred["player"]] = max(0, counts[pred["player"]] - 1)

    curr_score  = pred["score"]  if pred else "—"
    curr_player = pred["player"] if pred else "—"

    await state.set_data({
        **_store_edit_context(fixtures, matchup, round_no, players, team),
        "_edit_match_idx":    idx,
        "_edit_score":        None,
        "_edit_player_counts": counts,
    })
    await state.set_state(PredictForm.editing_single_score)

    await callback.message.answer(
        f"⚽ <b>{match['home']} vs {match['away']}</b>\n\n"
        f"📊 Жорий тахмин: <code>{curr_score}</code>\n"
        f"👤 Жорий ўйинчи:\n{curr_player}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Янги ҳисобни киритинг (масалан: <code>2-0</code>):\n"
        "<i>Бекор қилиш учун /cancel юборинг.</i>",
        parse_mode="HTML",
    )
    await callback.answer()


# ── single-match edit: score step ─────────────────────────────────────────────

@router.message(PredictForm.editing_single_score)
async def process_single_score(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()

    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Таҳрир бекор қилинди.")
        return

    if not SCORE_RE.match(text):
        await message.answer(
            "⚠️ Нотўғри формат. Масалан: <code>2-1</code> ёки <code>0-0</code>.",
            parse_mode="HTML",
        )
        return

    data          = await state.get_data()
    idx: int      = data["_edit_match_idx"]
    fixtures: list = data["_edit_fixtures"]
    players: list  = data["_edit_players"]
    matchup        = data.get("_edit_matchup")
    counts: dict   = data["_edit_player_counts"]

    user_id = message.from_user.id
    match   = fixtures[idx]

    # Opponent scoreline check: same fixture AND same score (matchup mode only)
    opponent_scores = get_opponent_scorelines(matchup, user_id) if matchup else {}
    if text == opponent_scores.get(match["id"]):
        await message.answer(
            "⚠️ Бу ҳисоб рақибингиз томонидан танланган.\n\n"
            "Илтимос бошқа ҳисоб киритинг.",
            parse_mode="HTML",
        )
        return

    available = [p for p in players if counts.get(p, 0) < MAX_PLAYER_MATCHES]
    if not available:
        await message.answer(
            "⚠️ Барча ўйинчиларингиз бу турда 2 матч лимитига эришди.\n"
            "Таҳрир амалга ошириб бўлмайди."
        )
        await state.clear()
        return

    await state.update_data(_edit_score=text)
    await state.set_state(PredictForm.editing_single_player)

    await message.answer(
        f"👤 <b>Янги ўйинчини танланг</b>\n"
        f"{match['home']} 🆚 {match['away']}  |  Ҳисоб: <code>{text}</code>\n\n"
        "Ҳар бир ўйинчи бир турда <b>2 та матч</b>дан ошмайди.",
        reply_markup=_player_keyboard(players, counts),
        parse_mode="HTML",
    )


# ── single-match edit: player step ────────────────────────────────────────────

@router.callback_query(PredictForm.editing_single_player, F.data.startswith(PLAYER_PREFIX))
async def process_single_player(callback: CallbackQuery, state: FSMContext) -> None:
    player_name = callback.data[len(PLAYER_PREFIX):]
    data        = await state.get_data()

    idx: int       = data["_edit_match_idx"]
    fixtures: list = data["_edit_fixtures"]
    matchup        = data.get("_edit_matchup")
    round_no: int  = data["_edit_round"]
    players: list  = data["_edit_players"]
    team: str      = data["_edit_team"]
    score: str     = data["_edit_score"]
    counts: dict   = data["_edit_player_counts"]

    if player_name not in players:
        await callback.answer("⚠️ Нотўғри ўйинчи.", show_alert=True)
        return

    if counts.get(player_name, 0) >= MAX_PLAYER_MATCHES:
        await callback.answer(
            f"⚠️ {player_name} аллақачон {MAX_PLAYER_MATCHES} та матчга белгиланган.",
            show_alert=True,
        )
        return

    user_id = callback.from_user.id
    match   = fixtures[idx]
    save_prediction(user_id, match["id"], score, player_name)

    # Confirm the single-match update
    await callback.message.edit_text(
        f"✅ <b>{idx + 1}-матч янгиланди</b>\n\n"
        f"📊 Янги ҳисоб: <code>{score}</code>\n"
        f"👤 Янги ўйинчи:\n{player_name}",
        parse_mode="HTML",
    )
    await callback.answer()

    # Return to full summary with per-match edit buttons
    existing     = get_predictions(user_id)
    summary_body = _build_summary(fixtures, existing)

    await state.set_data(_store_edit_context(fixtures, matchup, round_no, players, team))
    await state.set_state(None)   # back to default state, keep edit context

    await callback.message.answer(
        "📝 <b>Сизнинг тахминларингиз</b>\n\n" + summary_body,
        reply_markup=_edit_buttons(fixtures),
        parse_mode="HTML",
    )


# ── cancel ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == PRED_CANCEL_CB)
async def cb_pred_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("✅ Ўзгаришлар сақланди.")
    await callback.answer()


# ── full flow: 1-қадам ҳисоб сўраш ──────────────────────────────────────────

async def _ask_score(
    message:  Message,
    fixtures: list,
    idx:      int,
    existing: dict,
) -> None:
    match     = fixtures[idx]
    prev      = existing.get(match["id"])
    prev_text = (
        f"\nЖорий тахмин: <code>{prev['score']}</code>  👤 {prev['player']}"
        if prev else ""
    )
    await message.answer(
        f"⚽ <b>Матч {idx + 1} / {PREDICTIONS_PER_ROUND}</b>\n"
        f"{match['home']} 🆚 {match['away']}\n"
        f"🕐 {match['date']}{prev_text}\n\n"
        "Ҳисоб тахминингизни киритинг (масалан <code>2-1</code>):\n"
        "<i>Бекор қилиш учун /cancel юборинг.</i>",
        parse_mode="HTML",
    )


@router.message(PredictForm.waiting_for_score)
async def process_score(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()

    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Тахмин сессияси бекор қилинди.")
        return

    if not SCORE_RE.match(text):
        await message.answer(
            "⚠️ Нотўғри формат. Масалан: <code>2-1</code> ёки <code>0-0</code>.",
            parse_mode="HTML",
        )
        return

    data           = await state.get_data()
    fixtures: list = data["fixtures"]
    idx: int       = data["index"]
    players: list  = data["players"]
    player_counts  = data["player_counts"]
    matchup        = data.get("matchup")

    user_id = message.from_user.id
    match   = fixtures[idx]

    # Opponent scoreline check: same fixture AND same score (matchup mode only)
    opponent_scores = get_opponent_scorelines(matchup, user_id) if matchup else {}
    if text == opponent_scores.get(match["id"]):
        await message.answer(
            "⚠️ Бу ҳисоб рақибингиз томонидан танланган.\n\n"
            "Илтимос бошқа ҳисоб киритинг.",
            parse_mode="HTML",
        )
        return

    # Free up the slot occupied by the previous prediction for this match (if re-entering)
    existing = get_predictions(user_id)
    prev     = existing.get(match["id"])
    if prev and prev.get("player") in player_counts:
        player_counts[prev["player"]] = max(0, player_counts[prev["player"]] - 1)

    available = [p for p in players if player_counts.get(p, 0) < MAX_PLAYER_MATCHES]
    if not available:
        await message.answer(
            "⚠️ Барча ўйинчиларингиз бу турда 2 матч лимитига эришди.\n"
            "Кўпроқ тахмин беролмайсиз."
        )
        await state.clear()
        return

    await state.update_data(score=text, player_counts=player_counts)
    await state.set_state(PredictForm.waiting_for_player)

    await message.answer(
        f"👤 <b>Матч учун ўйинчи белгиланг</b>\n"
        f"{match['home']} 🆚 {match['away']}  |  Ҳисоб: <code>{text}</code>\n\n"
        "Ҳар бир ўйинчи бир турда <b>2 та матч</b>дан ошмайди.",
        reply_markup=_player_keyboard(players, player_counts),
        parse_mode="HTML",
    )


# ── full flow: 2-қадам ўйинчи танлаш ────────────────────────────────────────

@router.callback_query(PredictForm.waiting_for_player, F.data.startswith(PLAYER_PREFIX))
async def process_player(callback: CallbackQuery, state: FSMContext) -> None:
    player_name = callback.data[len(PLAYER_PREFIX):]
    data        = await state.get_data()

    fixtures:      list         = data["fixtures"]
    idx:           int          = data["index"]
    score:         str          = data["score"]
    players:       list[str]    = data["players"]
    player_counts: dict[str,int] = data["player_counts"]
    round_no:      int          = data["round"]

    if player_name not in players:
        await callback.answer("⚠️ Нотўғри ўйинчи.", show_alert=True)
        return

    if player_counts.get(player_name, 0) >= MAX_PLAYER_MATCHES:
        await callback.answer(
            f"⚠️ {player_name} аллақачон {MAX_PLAYER_MATCHES} та матчга белгиланган.",
            show_alert=True,
        )
        return

    user_id = callback.from_user.id
    match   = fixtures[idx]
    save_prediction(user_id, match["id"], score, player_name)

    player_counts[player_name] = player_counts.get(player_name, 0) + 1
    next_idx = idx + 1

    await state.update_data(index=next_idx, score=None, player_counts=player_counts)

    await callback.message.edit_text(
        f"✅ <b>Матч {idx + 1}:</b> {match['home']} 🆚 {match['away']}\n"
        f"Ҳисоб: <code>{score}</code>  |  Ўйинчи: <b>{player_name}</b>",
        parse_mode="HTML",
    )
    await callback.answer()

    if next_idx >= PREDICTIONS_PER_ROUND:
        await state.clear()
        existing = get_predictions(user_id)
        summary  = [f"🏆 <b>{round_no}-тур Тахминлари Сақланди!</b>\n"]
        for i, m in enumerate(fixtures):
            pred = existing.get(m["id"])
            if pred:
                summary.append(
                    f"{i + 1}. {m['home']} vs {m['away']}: "
                    f"<code>{pred['score']}</code>  👤 {pred['player']}"
                )
            else:
                summary.append(f"{i + 1}. {m['home']} vs {m['away']}: —")
        await callback.message.answer("\n".join(summary), parse_mode="HTML")
        return

    await state.set_state(PredictForm.waiting_for_score)
    existing = get_predictions(user_id)
    await _ask_score(callback.message, fixtures, next_idx, existing)
