import os

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.deadline_db import set_deadline
from bot.data.matchday_db import (
    get_matchday,
    matchday_exists,
    parse_fixture_line,
    reset_matchday,
    save_matchday,
)
from bot.data.teams_db import load_teams
from bot.data.admin_ids import is_admin as _is_admin

router = Router()

_GROUP_ID  = os.environ.get("GROUP_ID", "").strip()
TOTAL_MATCHES = 5




# ── FSM States ─────────────────────────────────────────────────────────────────

class SetFixturesForm(StatesGroup):
    waiting_for_match    = State()
    waiting_for_date     = State()
    waiting_for_time     = State()


# ── /setfixtures ───────────────────────────────────────────────────────────────

@router.message(Command("setfixtures"))
async def cmd_setfixtures(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    if matchday_exists():
        await message.answer(
            "⚠️ Match Day аллақачон яратилган.\n\n"
            "Янги Match Day яратиш учун аввал /resetfixtures командасини ишлатинг."
        )
        return

    await state.set_data({"fixtures": [], "index": 1})
    await state.set_state(SetFixturesForm.waiting_for_match)
    await message.answer(
        "⚽ <b>Match Day яратиш</b>\n\n"
        f"<b>1-матч</b> номини киритинг:\n"
        "<i>Формат: Жамоа А vs Жамоа Б</i>\n\n"
        "<i>Бекор қилиш: /cancel</i>",
        parse_mode="HTML",
    )


@router.message(SetFixturesForm.waiting_for_match)
async def process_match(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    if text.lower() == "cancel":
        await state.clear()
        await message.answer("❌ Match Day яратиш бекор қилинди.")
        return

    data = await state.get_data()
    fixtures: list[dict] = data["fixtures"]
    index: int = data["index"]

    parsed = parse_fixture_line(text)
    if not parsed:
        await message.answer(
            "⚠️ Нотўғри формат.\n\n"
            "<i>Намуна: Inter vs Arsenal</i>",
            parse_mode="HTML",
        )
        return

    home, away = parsed

    # Duplicate check (case-insensitive)
    existing_pairs = {(f["home"].lower(), f["away"].lower()) for f in fixtures}
    if (home.lower(), away.lower()) in existing_pairs or \
       (away.lower(), home.lower()) in existing_pairs:
        await message.answer("⚠️ Бу матч аллақачон киритилган. Бошқа матч киритинг.")
        return

    fixtures.append({"home": home, "away": away})

    if index < TOTAL_MATCHES:
        next_index = index + 1
        await state.update_data(fixtures=fixtures, index=next_index)
        await message.answer(
            f"✅ {index}-матч сақланди: <b>{home} vs {away}</b>\n\n"
            f"<b>{next_index}-матч</b> номини киритинг:\n"
            "<i>Формат: Жамоа А vs Жамоа Б</i>",
            parse_mode="HTML",
        )
    else:
        # All 5 matches collected — ask for deadline date
        await state.update_data(fixtures=fixtures)
        await state.set_state(SetFixturesForm.waiting_for_date)
        await message.answer(
            f"✅ {index}-матч сақланди: <b>{home} vs {away}</b>\n\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "📅 <b>Дедлайн санасини киритинг:</b>\n"
            "<i>Формат: КК.ОО.ЙЙЙЙ</i>\n"
            "<i>Намуна: 17.09.2026</i>",
            parse_mode="HTML",
        )


@router.message(SetFixturesForm.waiting_for_date)
async def process_date(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    if text.lower() == "cancel":
        await state.clear()
        await message.answer("❌ Match Day яратиш бекор қилинди.")
        return

    # Validate date format
    from datetime import datetime as _dt
    try:
        _dt.strptime(text, "%d.%m.%Y")
    except ValueError:
        await message.answer(
            "⚠️ Нотўғри формат.\n\n"
            "<i>Намуна: 17.09.2026</i>",
            parse_mode="HTML",
        )
        return

    await state.update_data(deadline_date=text)
    await state.set_state(SetFixturesForm.waiting_for_time)
    await message.answer(
        f"✅ Сана: <b>{text}</b>\n\n"
        "🕗 <b>Дедлайн вақтини киритинг:</b>\n"
        "<i>Формат: ЧЧ:ДД  (Москва вақти)</i>\n"
        "<i>Намуна: 20:00</i>",
        parse_mode="HTML",
    )


@router.message(SetFixturesForm.waiting_for_time)
async def process_time(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    if text.lower() == "cancel":
        await state.clear()
        await message.answer("❌ Match Day яратиш бекор қилинди.")
        return

    from datetime import datetime as _dt
    try:
        _dt.strptime(text, "%H:%M")
    except ValueError:
        await message.answer(
            "⚠️ Нотўғри формат.\n\n"
            "<i>Намуна: 20:00</i>",
            parse_mode="HTML",
        )
        return

    data = await state.get_data()
    fixtures: list[dict] = data["fixtures"]
    deadline_date: str   = data["deadline_date"]
    deadline_time: str   = text

    # Save Match Day
    saved = save_matchday(fixtures, deadline_date, deadline_time)

    # Automatically update deadline system
    set_deadline(deadline_date, deadline_time)

    await state.clear()

    match_day = saved["match_day"]
    lines = [
        f"✅ <b>Match Day #{match_day} яратилди!</b>\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
        f"⏰ Дедлайн: <b>{deadline_date} • {deadline_time}</b> (Москва вақти)\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
    ]
    for i, fx in enumerate(fixtures, 1):
        lines.append(f"{i}. <b>{fx['home']}</b> vs <b>{fx['away']}</b>")

    await message.answer("\n".join(lines), parse_mode="HTML")

    # ── Generate Match Day Preview ─────────────────────────────────────────────
    from bot.data.commentary_db import store_commentary
    from bot.data.season_db import get_current_season

    _season = get_current_season()
    try:
        if match_day in {9, 11, 13, 15, 17}:
            from bot.data.playoff_engine import generate_playoff_studio
            _preview_text, _preview_item = generate_playoff_studio(match_day, _season)
        else:
            from bot.data.preview_engine import generate_preview
            _preview_text, _preview_item = generate_preview(match_day, fixtures, _season)
        store_commentary(_preview_item)
    except Exception:
        _preview_text = None

    # ── Group announcement ─────────────────────────────────────────────────────
    if _GROUP_ID:
        try:
            await message.bot.send_message(
                int(_GROUP_ID),
                f"📢 <b>{match_day}-тур учун Match Day ўйинлари эълон қилинди.</b>\n\n"
                "⚽ Тахминларни киритиш мумкин:\n\n"
                "/predict",
                parse_mode="HTML",
            )
        except Exception:
            pass
        if _preview_text:
            try:
                await message.bot.send_message(int(_GROUP_ID), _preview_text, parse_mode="HTML")
            except Exception:
                pass

    # ── Private DM to every registered participant ─────────────────────────────
    _dm_text = (
        "📢 <b>Янги Match Day бошланди</b>\n\n"
        f"🏟 Тур: <b>{match_day}</b>\n\n"
        "⚽ Ўйинлар эълон қилинди.\n\n"
        "📝 Тахмин киритиш:\n\n"
        "/predict\n\n"
        "━━━━━━━━━━━━━━"
    )
    teams = load_teams()
    for info in teams.values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await message.bot.send_message(int(tid), _dm_text, parse_mode="HTML")
        except Exception:
            pass
        if _preview_text:
            try:
                await message.bot.send_message(int(tid), _preview_text, parse_mode="HTML")
            except Exception:
                pass


# ── /resetfixtures ─────────────────────────────────────────────────────────────

_RF_CONFIRM = "resetfixtures:confirm"
_RF_CANCEL  = "resetfixtures:cancel"


@router.message(Command("resetfixtures"))
async def cmd_resetfixtures(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    if not matchday_exists():
        await message.answer("⚠️ Яратилган Match Day мавжуд эмас.")
        return

    md = get_matchday()
    md_num = md.get("match_day", "?") if md else "?"
    await message.answer(
        f"⚠️ <b>Match Day #{md_num}ни ўчириш</b>\n\n"
        "Match Dayни ўчиришни тасдиқлайсизми?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Ҳа",  callback_data=_RF_CONFIRM),
            InlineKeyboardButton(text="❌ Йўқ", callback_data=_RF_CANCEL),
        ]]),
        parse_mode="HTML",
    )


@router.callback_query(F.data == _RF_CONFIRM)
async def cb_resetfixtures_confirm(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⚠️ Рухсат йўқ.", show_alert=True)
        return
    reset_matchday()
    await callback.message.edit_text("🗑 Match Day ўчирилди.")
    await callback.answer()


@router.callback_query(F.data == _RF_CANCEL)
async def cb_resetfixtures_cancel(callback: CallbackQuery) -> None:
    await callback.message.edit_text("❌ Ўчириш бекор қилинди.")
    await callback.answer()
