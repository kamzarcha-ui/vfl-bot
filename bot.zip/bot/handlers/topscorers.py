from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.teams_db import load_teams
from bot.data.club_abbr import abbr

router = Router()

_W_NAME = 22
_W_CLUB = 3
_W_GOAL = 3

_HDR  = f"{'#':>2}  {'ЎЙИНЧИ':<{_W_NAME}}  {'КЛБ':<{_W_CLUB}}  {'ГОЛ':>{_W_GOAL}}"
_DASH = "─" * (2 + 2 + _W_NAME + 2 + _W_CLUB + 2 + _W_GOAL)


def _row(pos: int, name: str, club: str, goals: int) -> str:
    return (
        f"{pos:>2}. {name[:_W_NAME]:<{_W_NAME}}  "
        f"{abbr(club):<{_W_CLUB}}  {goals:>{_W_GOAL}}"
    )


@router.message(Command("topscorers"))
async def cmd_topscorers(message: Message, *, user_id: int | None = None) -> None:
    teams = load_teams()

    scorers: list[tuple[str, str, int]] = []
    for team_name, info in teams.items():
        for player in info.get("players", []):
            if not isinstance(player, dict):
                continue
            goals = player.get("goals", 0)
            if goals >= 1:
                scorers.append((player.get("name", "?"), team_name, goals))

    header = (
        "⚽ <b>VFL CHAMPIONS LEAGUE</b>\n\n"
        "🏆 <b>ТЎПУРАРЛАР РЕЙТИНГИ</b>"
    )

    if not scorers:
        await message.answer(
            f"{header}\n\n"
            "Ҳозирча гол урган ўйинчилар мавжуд эмас.",
            parse_mode="HTML",
        )
        return

    scorers.sort(key=lambda s: (-s[2], s[0]))

    table_lines = [_HDR, _DASH] + [_row(i + 1, *s) for i, s in enumerate(scorers)]

    await message.answer(
        f"{header}\n\n<pre>" + "\n".join(table_lines) + "</pre>",
        parse_mode="HTML",
    )
