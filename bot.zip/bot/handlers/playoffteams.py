from bot.data.admin_ids import is_admin as _is_admin
"""
/playoffteams — show the post-MD8 team classification.
"""


from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.league_stage_db import get_classification

router = Router()

_CB_BACK = "pft:back"


def _build_text() -> str:
    clf = get_classification()
    if not clf:
        return (
            "📋 <b>Плей-офф жамоалари</b>\n\n"
            "⏳ 8-тур ҳали якунланмаган.\n"
            "Таснифлаш автоматик равишда 8-турдан сўнг сақланади."
        )

    lines: list[str] = ["📋 <b>Плей-офф таснифи</b>\n"]

    r16 = clf.get("r16_direct", [])
    if r16:
        lines.append("✅ <b>ТЎҒРИДАН-ТЎҒРИ 1/8 ФИНАЛ (1–8-ўринлар)</b>\n")
        for i, team in enumerate(r16, 1):
            lines.append(f"  {i}. {team}")
        lines.append("")

    pz = clf.get("playoff_zone", [])
    if pz:
        lines.append("🎯 <b>ПЛЕЙ-ОФФ БОСҚИЧИ (9–24-ўринлар)</b>\n")
        for i, team in enumerate(pz, 9):
            lines.append(f"  {i}. {team}")
        lines.append("")

    elim = clf.get("eliminated", [])
    if elim:
        lines.append("⚠️ <b>МУСОБАҚАНИ ТАРК ЭТИШ ЗОНАСИ (25–36-ўринлар)</b>\n")
        for i, team in enumerate(elim, 25):
            lines.append(f"  {i}. {team}")

    ts = clf.get("timestamp", "")
    if ts:
        lines.append(f"\n🕐 <code>{ts}</code>")

    return "\n".join(lines)


@router.message(Command("playoffteams"))
async def cmd_playoffteams(message: Message) -> None:
    await message.answer(_build_text(), parse_mode="HTML")
