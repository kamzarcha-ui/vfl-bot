from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.db import get_fixtures

router = Router()


@router.message(Command("tour"))
async def cmd_tour(message: Message) -> None:
    fixtures = get_fixtures()

    if not fixtures:
        await message.answer("📅 Матчлар жадвали ҳали мавжуд эмас.")
        return

    current_round = max(f["round"] for f in fixtures)
    round_fixtures = [f for f in fixtures if f["round"] == current_round]

    lines = [f"📅 <b>{current_round}-тур матчлари</b>\n"]
    for i, match in enumerate(round_fixtures, 1):
        lines.append(
            f"<b>Матч {i}:</b> {match['home']} 🆚 {match['away']}\n"
            f"🕐 {match['date']}\n"
        )

    lines.append("Тахминларингизни бериш учун /predict ни ишлатинг!")
    await message.answer("\n".join(lines), parse_mode="HTML")
