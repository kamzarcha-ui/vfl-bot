from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.teams_db import load_coaches, load_teams
from bot.data.club_abbr import abbr

router = Router()

_W_NAME  = 20
_W_CLUB  = 3
_W_GOAL  = 3
_W_EXACT = 4

_HDR = (
    f"{'#':>2}  {'МУРАББИЙ':<{_W_NAME}}  "
    f"{'КЛБ':<{_W_CLUB}}  {'ГОЛ':>{_W_GOAL}}  {'АНИҚ':>{_W_EXACT}}"
)
_DASH = "─" * (2 + 2 + _W_NAME + 2 + _W_CLUB + 2 + _W_GOAL + 2 + _W_EXACT)


def _coach_team(coach_name: str, coaches: dict, teams: dict) -> str:
    for team_name, info in teams.items():
        if info.get("coach") == coach_name:
            return team_name
    return coaches.get(coach_name, {}).get("team", "—")


def _row(pos: int, name: str, team: str, goals: int, exact: int) -> str:
    return (
        f"{pos:>2}. {name[:_W_NAME]:<{_W_NAME}}  "
        f"{abbr(team):<{_W_CLUB}}  {goals:>{_W_GOAL}}  {exact:>{_W_EXACT}}"
    )


@router.message(Command("goldenpredictor"))
async def cmd_goldenpredictor(message: Message, *, user_id: int | None = None) -> None:
    coaches = load_coaches()
    teams   = load_teams()

    leaders: list[tuple[str, str, int, int]] = []
    for name, info in coaches.items():
        goals = info.get("matchday_goals", 0)
        exact = info.get("exact_predictions", 0)
        if goals >= 1 or exact >= 1:
            team = _coach_team(name, coaches, teams)
            leaders.append((name, team, goals, exact))

    header = (
        "🎯 <b>VFL CHAMPIONS LEAGUE</b>\n\n"
        "🏆 <b>МУРАББИЙЛАР РЕЙТИНГИ</b>"
    )

    if not leaders:
        await message.answer(
            f"{header}\n\n"
            "Ҳозирча мураббийлар статистикаси мавжуд эмас.",
            parse_mode="HTML",
        )
        return

    leaders.sort(key=lambda x: (-x[2], -x[3], x[0]))

    table_lines = [_HDR, _DASH] + [_row(i + 1, *r) for i, r in enumerate(leaders)]

    await message.answer(
        f"{header}\n\n<pre>" + "\n".join(table_lines) + "</pre>",
        parse_mode="HTML",
    )
