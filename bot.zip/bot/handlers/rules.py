from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("rules"))
async def cmd_rules(message: Message) -> None:
    await message.answer(
        "📖 <b>VFL Champions League Қисқа Қоидалар</b>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "🎯 <b>Тахминлар</b>\n\n"
        "• Ҳар турда 5 та тахмин\n\n"
        "• Рақиб билан бир хил ҳисоб ёзиш мумкин эмас\n\n"
        "• Бир футболчи максимум 2 та тахмин учун танланиши мумкин\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "⚽ <b>Голлар тизими</b>\n\n"
        "🎯 Аниқ ҳисоб = 2 та гол\n\n"
        "🟡 Голлар фарқи тўғри = 1 та гол\n\n"
        "❌ Нотўғри тахмин = 0 гол\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "🏆 <b>Жамоа очколари</b>\n\n"
        "🥇 Ғалаба = 3 очко\n\n"
        "🤝 Дурранг = 1 очко\n\n"
        "❌ Мағлубият = 0 очко\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "👔 <b>Мураббийлар</b>\n\n"
        "• Аниқ ҳисоблар алоҳида ҳисобланади\n\n"
        "• Жамоа очколарига таъсир қилмайди\n\n"
        "• Golden Predictor рейтинги учун ишлатилади\n\n"
        "━━━━━━━━━━━━━━━━━━━━",
        parse_mode="HTML",
    )
