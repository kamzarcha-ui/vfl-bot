from bot.data.admin_ids import is_admin as _is_admin
"""
/editfixtures — edit match names in the current Match Day (admin only).

Flow:
  1. /editfixtures → show fixture list + ✏️ buttons
  2. Admin taps a match → shows current fixture, prompts for new
  3. Admin types new fixture → saved, confirmation shown, return to list

Guards:
  - Non-admin: ⛔ message
  - No Match Day: ⚠️ message
  - Any predictions submitted: hard block (no edit allowed)
"""


from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.db import get_predictions
from bot.data.matchday_db import (
    get_matchday,
    matchday_exists,
    parse_fixture_line,
    update_fixture,
)
from bot.data.teams_db import load_coaches

router = Router()





class EditFixturesForm(StatesGroup):
    waiting_new_fixture = State()


_CB_MATCH_PFX = "ef:match:"
_CB_CLOSE     = "ef:close"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _has_predictions(n: int) -> bool:
    """Return True if any coach has submitted predictions for Match Day n."""
    prefix_ids = {f"md{n}_m{i}" for i in range(1, 6)}
    for info in load_coaches().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            preds = get_predictions(int(tid))
        except (ValueError, TypeError):
            continue
        if any(mid in preds for mid in prefix_ids):
            return True
    return False


def _fixture_list_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"✏️ {i}-ўйин", callback_data=f"{_CB_MATCH_PFX}{i - 1}")]
        for i in range(1, 6)
    ]
    rows.append([InlineKeyboardButton(text="✅ Тайёр", callback_data=_CB_CLOSE)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _format_fixture_list(md: dict) -> str:
    lines = ["⚽ <b>Match Day ўйинларини ўзгартириш</b>\n"]
    for i, fx in enumerate(md["fixtures"], 1):
        lines.append(f"{i}. {fx['home']} vs {fx['away']}")
    lines.append("\nҚайси ўйинни ўзгартирмоқчисиз?")
    return "\n".join(lines)


# ── /editfixtures ──────────────────────────────────────────────────────────────

@router.message(Command("editfixtures"))
async def cmd_editfixtures(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        await message.answer("⛔ Сизда админ ҳуқуқи мавжуд эмас.")
        return

    if not matchday_exists():
        await message.answer(
            "⚠️ Ҳозирча Match Day ўйинлари киритилмаган.\n\n"
            "Аввал /setfixtures командаси орқали ўйинларни киритинг."
        )
        return

    md = get_matchday()
    if _has_predictions(md["match_day"]):
        await message.answer(
            "⚠️ Иштирокчилар аллақачон тахмин киритган.\n\n"
            "Match Day ўйинларини ўзгартириш мумкин эмас."
        )
        return

    await state.clear()
    await message.answer(
        _format_fixture_list(md),
        reply_markup=_fixture_list_kb(),
    )


# ── Match button callback ──────────────────────────────────────────────────────

@router.callback_query(F.data.startswith(_CB_MATCH_PFX))
async def cb_select_match(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    try:
        idx = int(callback.data[len(_CB_MATCH_PFX):])
    except ValueError:
        await callback.answer("⚠️ Хато.", show_alert=True)
        return

    md = get_matchday()
    if not md:
        await callback.answer("⚠️ Match Day мавжуд эмас.", show_alert=True)
        return

    if _has_predictions(md["match_day"]):
        await callback.message.edit_text(
            "⚠️ Иштирокчилар аллақачон тахмин киритган.\n\n"
            "Match Day ўйинларини ўзгартириш мумкин эмас."
        )
        await callback.answer()
        return

    if idx < 0 or idx >= len(md["fixtures"]):
        await callback.answer("⚠️ Нотўғри рақам.", show_alert=True)
        return

    fx = md["fixtures"][idx]
    current = f"{fx['home']} vs {fx['away']}"

    await state.set_state(EditFixturesForm.waiting_new_fixture)
    await state.update_data(idx=idx, current=current, md_n=md["match_day"])

    await callback.message.edit_text(
        f"⚽ <b>{idx + 1}-ўйин</b>\n\n"
        f"Жорий ўйин:\n{current}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "Янги ўйинни киритинг:\n\n"
        "Масалан:\n<code>Бавария vs Челси</code>",
    )
    await callback.answer()


# ── ✅ Тайёр (close) ──────────────────────────────────────────────────────────

@router.callback_query(F.data == _CB_CLOSE)
async def cb_ef_close(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("✅ Ўзгаришлар сақланди.")
    await callback.answer()


# ── New fixture text input ─────────────────────────────────────────────────────

@router.message(EditFixturesForm.waiting_new_fixture)
async def msg_new_fixture(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    parsed = parse_fixture_line(text)

    if not parsed:
        await message.answer(
            "⚠️ Нотўғри формат.\n\n"
            "Масалан: <code>Бавария vs Челси</code>",
        )
        return

    home, away = parsed
    data = await state.get_data()
    idx: int     = data["idx"]
    current: str = data["current"]
    md_n: int    = data["md_n"]

    # Re-check predictions before saving
    if _has_predictions(md_n):
        await state.clear()
        await message.answer(
            "⚠️ Иштирокчилар аллақачон тахмин киритган.\n\n"
            "Match Day ўйинларини ўзгартириш мумкин эмас."
        )
        return

    update_fixture(idx, home, away)
    new_match = f"{home} vs {away}"
    await state.clear()

    md = get_matchday()
    await message.answer(
        f"✅ <b>Ўйин янгиланди</b>\n\n"
        f"Эски:\n{current}\n\n"
        f"Янги:\n{new_match}",
        reply_markup=None,
    )

    # Return to the updated fixture list
    if md:
        await message.answer(
            _format_fixture_list(md),
            reply_markup=_fixture_list_kb(),
        )
