
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

from bot.data.matchday_db import get_matchday
from bot.data.matchday_state_db import is_matchday_active, set_matchday_active

router = Router()





# ── /startmatchday ─────────────────────────────────────────────────────────────

@router.message(Command("startmatchday"))
async def cmd_startmatchday(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    md = get_matchday()
    if not md:
        await message.answer(
            "⚠️ Аввал Match Day яратинг.\n\n"
            "Буйруқ: /setfixtures"
        )
        return

    if is_matchday_active():
        match_day = md.get("match_day", "?")
        await message.answer(
            f"⚠️ Match Day #{match_day} аллақачон очиқ.\n\n"
            "Тахмин қабул қилиш бошланган."
        )
        return

    set_matchday_active(True)
    match_day     = md.get("match_day", "?")
    deadline_date = md.get("deadline_date", "—")
    deadline_time = md.get("deadline_time", "—")
    fixtures      = md.get("fixtures", [])

    lines = [
        f"▶️ <b>Match Day #{match_day} очилди!</b>\n",
        "✅ Тахмин қабул қилиш бошланди.\n",
        f"⏰ Муддат: {deadline_date} • {deadline_time} (Москва вақти)\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
    ]
    for i, fx in enumerate(fixtures, 1):
        lines.append(f"{i}. <b>{fx['home']}</b> vs <b>{fx['away']}</b>")
    lines.append("\n🎯 Фойдаланувчилар /predict орқали тахмин бера олади.")

    await message.answer("\n".join(lines), parse_mode="HTML")


# ── /endmatchday ───────────────────────────────────────────────────────────────

@router.message(Command("endmatchday"))
async def cmd_endmatchday(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    if not is_matchday_active():
        await message.answer("⚠️ Match Day ҳозир очиқ эмас.")
        return

    set_matchday_active(False)

    md = get_matchday()
    match_day = md.get("match_day", "?") if md else "?"
    await message.answer(
        f"⏹ <b>Match Day #{match_day} ёпилди.</b>\n\n"
        "❌ Тахмин қабул қилиш тўхтатилди.",
        parse_mode="HTML",
    )
