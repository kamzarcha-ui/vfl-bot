"""
🔄 Release Team — Admin: detach a coach from their club.

Coach stays in VFL (license, ranking, HOF records, stats preserved).
Team becomes free for a new coach to register.

Flow:
  System Management → 🔄 Жамоани бўшатиш
  → Inline list of occupied teams
  → Select team → Confirm (inline ✅ / ❌)
  → Execute + broadcast announcement
"""

import os

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from bot.data.admin_ids import is_admin as _is_admin

router = Router()

_GROUP_ID = os.environ.get("GROUP_ID", "").strip()

_CONFIRM_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="✅ Ҳа, бўшатиш",  callback_data="adm:rt:confirm"),
    InlineKeyboardButton(text="❌ Бекор қилиш",  callback_data="adm:rt:cancel"),
]])

_BACK_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:system"),
]])




def _occupied_teams() -> list[tuple[str, str, str]]:
    """Return [(team_name, coach_name, license)] for all occupied teams."""
    from bot.data.teams_db import load_teams
    result = []
    for name, info in load_teams().items():
        coach = info.get("coach")
        lic   = info.get("license", "—")
        if coach or info.get("telegram_id"):
            result.append((name, coach or "—", lic))
    return sorted(result, key=lambda x: x[0])


async def _broadcast(bot, text: str) -> None:
    from bot.data.teams_db import load_teams
    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), text, parse_mode="HTML")
        except Exception:
            pass


# ── Show list of occupied teams ────────────────────────────────────────────────

@router.callback_query(F.data == "adm:sys:release")
async def cb_release_menu(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    occupied = _occupied_teams()
    if not occupied:
        await callback.message.edit_text(
            "🔄 <b>Жамоани бўшатиш</b>\n\n"
            "Ҳозирда бириктирилган жамоалар мавжуд эмас.",
            reply_markup=_BACK_KB,
            parse_mode="HTML",
        )
        await callback.answer()
        return

    # Persist team list in FSM (so pick handler doesn't need to re-query)
    await state.update_data(rt_teams=[t[0] for t in occupied])

    buttons: list[list[InlineKeyboardButton]] = []
    for i, (tname, coach, _lic) in enumerate(occupied[:30]):
        label = f"{tname}  ({coach})"
        buttons.append([InlineKeyboardButton(text=label, callback_data=f"adm:rt:pick:{i}")])
    buttons.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:system")])

    await callback.message.edit_text(
        "🔄 <b>Жамоани бўшатиш</b>\n\n"
        "Бўшатиладиган жамоани танланг:\n\n"
        "<i>Мураббий системада қолади — жамоа эркин бўлади.</i>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Team selected ─────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("adm:rt:pick:"))
async def cb_release_pick(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    try:
        idx = int(callback.data.split(":")[-1])
    except (ValueError, IndexError):
        await callback.answer("⚠️ Хато.", show_alert=True)
        return

    data      = await state.get_data()
    team_list = data.get("rt_teams", [])

    if idx >= len(team_list):
        await callback.answer("⚠️ Жамоа топилмади.", show_alert=True)
        return

    team_name = team_list[idx]
    from bot.data.teams_db import load_teams
    info  = load_teams().get(team_name, {})
    coach = info.get("coach", "—")
    lic   = info.get("license", "—")

    await state.update_data(rt_selected=team_name)

    await callback.message.edit_text(
        "🔄 <b>Жамоани бўшатиш — Тасдиқлаш</b>\n\n"
        f"🏟 <b>Жамоа:</b> {team_name}\n"
        f"👤 <b>Мураббий:</b> {coach}\n"
        f"🪪 <b>Лицензия:</b> {lic}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "✅ Сақланади: лицензия, рейтинг, HOF рекордлар, статистика\n"
        "❌ Ўчирилади: жамоа боғлиқлиги\n\n"
        "<b>Тасдиқлайсизми?</b>",
        reply_markup=_CONFIRM_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── Confirm ───────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:rt:confirm")
async def cb_release_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    data      = await state.get_data()
    team_name = data.get("rt_selected", "")
    await state.clear()

    if not team_name:
        await callback.message.edit_text("⚠️ Жамоа маълумоти топилмади.", reply_markup=_BACK_KB)
        await callback.answer()
        return

    coach_name = _execute_release(team_name)

    await callback.message.edit_text(
        f"✅ <b>{team_name}</b> жамоаси бўшатилди.\n\n"
        f"👤 <b>{coach_name}</b> системада қолади.\n"
        "🏟 Жамоа янги рўйхатдан ўтиш учун очиқ.",
        reply_markup=_BACK_KB,
        parse_mode="HTML",
    )
    await callback.answer()

    ann_text = (
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "📢 <b>VFL РАСМИЙ ХАБАРИ</b>\n\n"
        f"🔄 <b>{coach_name}</b> <b>{team_name}</b> жамоасини тарк этди.\n\n"
        f"🏟 <b>{team_name}</b> ҳозир бўш.\n\n"
        "Янги мураббий ушбу жамоани эгаллаши мумкин.\n\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )

    if _GROUP_ID:
        try:
            await callback.message.bot.send_message(int(_GROUP_ID), ann_text, parse_mode="HTML")
        except Exception:
            pass
    await _broadcast(callback.message.bot, ann_text)

    try:
        from bot.data.announcements_db import save_announcement
        from bot.data.season_db import get_current_season
        save_announcement(
            f"🔄 {coach_name} {team_name} жамоасини тарк этди. "
            f"🏟 {team_name} ҳозир бўш.",
            get_current_season(),
        )
    except Exception:
        pass


# ── Cancel ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:rt:cancel")
async def cb_release_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "❌ Жамоани бўшатиш бекор қилинди.",
        reply_markup=_BACK_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── Execution ─────────────────────────────────────────────────────────────────

def _execute_release(team_name: str) -> str:
    """
    Detach coach from team.

    teams.json:   clears coach, telegram_id, license, players on the team entry.
    coaches.json: clears telegram_id and team binding so /start profile shows no
                  team; license, ranking, HOF and all stats are preserved so the
                  coach can re-register later and reclaim their history.

    Returns the coach name for broadcast use.
    """
    from bot.data.teams_db import load_teams, save_teams, load_coaches, save_coaches

    teams = load_teams()
    info  = teams.get(team_name, {})
    coach_name = info.get("coach") or "—"

    # Clear all team-binding fields
    info["coach"]       = None
    info["telegram_id"] = None
    info["license"]     = None
    info["players"]     = []
    teams[team_name]    = info
    save_teams(teams)

    # Clear the binding from coaches.json so _get_registration() returns None
    # and /start no longer shows the old team name.  License and stats stay.
    coaches = load_coaches()
    if coach_name in coaches:
        coaches[coach_name].pop("telegram_id", None)
        coaches[coach_name].pop("team",        None)
        save_coaches(coaches)

    return coach_name
