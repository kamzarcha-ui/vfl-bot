from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

router = Router()

# ── Texts ──────────────────────────────────────────────────────────────────────

CENTER_TEXT = (
    "📚 <b>VFL Champions League</b>\n\n"
    "<b>Регламент маркази</b>\n\n"
    "Қуйидаги бўлимни танланг:"
)

SHORT_RULES_TEXT = (
    "📖 <b>VFL Champions League Қисқа Қоидалар</b>\n\n"
    "🎯 <b>Тахминлар</b>\n\n"
    "• Ҳар турда 5 та тахмин\n\n"
    "• Рақиб билан бир хил ҳисоб ёзиш мумкин эмас\n\n"
    "• Бир футболчи максимум 2 та тахмин учун танланиши мумкин\n\n"
    "━━━━━━━━━━━━\n\n"
    "⚽ <b>Голлар тизими</b>\n\n"
    "🎯 Аниқ ҳисоб = 2 гол\n\n"
    "🟡 Голлар фарқи = 1 гол\n\n"
    "❌ Нотўғри тахмин = 0 гол\n\n"
    "━━━━━━━━━━━━\n\n"
    "🏆 <b>Жамоа очколари</b>\n\n"
    "🥇 Ғалаба = 3 очко\n\n"
    "🤝 Дурранг = 1 очко\n\n"
    "❌ Мағлубият = 0 очко\n\n"
    "━━━━━━━━━━━━\n\n"
    "👔 <b>Мураббийлар</b>\n\n"
    "• Аниқ ҳисоблар алоҳида ҳисобланади\n\n"
    "• Жамоа очколарига таъсир қилмайди\n\n"
    "• Golden Predictor рейтинги учун ишлатилади"
)

FORMAT_TEXT = (
    "🏆 <b>VFL Чемпионлар Лигаси — Турнир Формати</b>\n\n"
    "📋 <b>Лига босқичи</b>\n"
    "• 36 жамоа иштирок этади.\n"
    "• 8 тур ўтказилади.\n"
    "• Ҳар жамоа 4 та уй ва 4 та меҳмон учрашувида қатнашади.\n"
    "• Ҳар рақиб билан фақат бир марта ўйнайди.\n\n"
    "📊 <b>Лига босқичи якунлари</b>\n"
    "• 1–8 ўринлар тўғридан-тўғри 1/8 финалга чиқади.\n"
    "• 9–24 ўринлар плей-офф босқичида иштирок этади.\n"
    "• 25–36 ўринлар мусобақани тарк этади.\n\n"
    "🔥 <b>Плей-офф</b>\n"
    "УЕФА Чемпионлар Лигаси тизимига ўхшаш тарзда ташкил қилинади.\n\n"
    "<b>Юқори сават:</b>  9 • 10 • 11 • 12 • 13 • 14 • 15 • 16-ўрин\n"
    "<b>Пастки сават:</b>  17 • 18 • 19 • 20 • 21 • 22 • 23 • 24-ўрин\n\n"
    "Жуфтликлар УЕФА Чемпионлар Лигаси плей-офф қуръаси принципи бўйича автоматик аниқланади.\n\n"
    "🏆 <b>1/8 финал</b>\n"
    "• Лига босқичининг 1–8 ўринлари\n"
    "• Плей-офф ғолиблари\n\n"
    "🏆 <b>Чорак финал</b>\n\n"
    "🏆 <b>Ярим финал</b>\n\n"
    "👑 <b>Финал</b>\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"
    "⚔️ <b>Икки ўйинлик босқичларда тенглик</b>\n\n"
    "1. Икки ўйин натижалари йиғиндиси (умумий ҳисоб)\n\n"
    "2. Меҳмонда урилган голлар сони\n\n"
    "3. Икки ўйин бўйича мураббийнинг аниқ ҳисоблари сони\n\n"
    "4. Икки ўйин бўйича футболчиларнинг голлари сони\n\n"
    "5. Пенальтилар серияси\n\n"
    "🥅 <b>Пенальтилар серияси</b>\n\n"
    "• Ғолиб тасодифий тарзда аниқланади.\n\n"
    "• Бот натижани қуйидаги кўринишда чиқаради:\n\n"
    "🏆 <i>Rangers пенальтилар сериясида ғалаба қозонди (4-3)</i>"
)

FULL_REG_TEXT = (
    "🏆 <b>VFL CHAMPIONS LEAGUE</b>\n\n"
    "<b>РАСМИЙ РЕГЛАМЕНТ</b>\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"

    "<b>1-БОБ. УМУМИЙ ҚОИДАЛАР</b>\n\n"
    "1.1. VFL Champions League — футбол натижаларини прогноз қилиш асосида ўтказиладиган виртуал мусобақа ҳисобланади.\n\n"
    "1.2. Турнир Telegram платформасида махсус бот орқали бошқарилади.\n\n"
    "1.3. Турнирнинг расмий номи — VFL Champions League.\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"

    "<b>2-БОБ. ИШТИРОКЧИЛАР</b>\n\n"
    "2.1. Турнирда 36 та жамоа иштирок этади.\n\n"
    "2.2. Ҳар бир жамоани битта мураббий бошқаради.\n\n"
    "2.3. Бир иштирокчи фақат битта жамоага эгалик қилиши мумкин.\n\n"
    "2.4. Рўйхатдан ўтиш фақат бир марта амалга оширилади.\n\n"
    "2.5. Рўйхатдан ўтиш вақтида иштирокчи:\n\n"
    "• жамоа танлайди;\n\n"
    "• ўзининг исм ва фамилиясини киритади;\n\n"
    "• лицензия рақамини олади;\n\n"
    "• 3 нафар футболчини рўйхатдан ўтказади.\n\n"
    "2.6. Ҳар бир иштирокчига доимий лицензия рақами берилади.\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"

    "<b>5-БОБ. ТАХМИН ТИЗИМИ</b>\n\n"
    "5.1. Ҳар бир тур учун Match Day сифатида 5 та реал футбол учрашуви белгиланади.\n\n"
    "5.2. Ҳар бир иштирокчи ушбу 5 та ўйин учун ҳисоб тахмини киритиши шарт.\n\n"
    "5.3. Ҳар бир тахмин учун жамоа таркибидаги футболчилардан бири танланади.\n\n"
    "5.4. Бир футболчи бир турда максимум 2 та тахмин учун танланиши мумкин.\n\n"
    "5.5. Ўзаро рақиблар бир хил ҳисоб тахминидан фойдалана олмайди. Агар биринчи иштирокчи муайян ҳисобни киритган бўлса, иккинчи иштирокчи ушбу ҳисобни танлай олмайди.\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"

    "<b>6-БОБ. ГОЛЛАР ТИЗИМИ</b>\n\n"
    "6.1. Аниқ ҳисоб топилганда танланган футболчига 2 та гол ёзилади.\n\n"
    "6.2. Фақат голлар фарқи тўғри топилганда танланган футболчига 1 та гол ёзилади.\n\n"
    "6.3. Нотўғри тахмин учун футболчига гол берилмайди.\n\n"
    "6.4. Барча голлар футболчиларнинг умумий статистикасига қўшиб борилади.\n\n"
    "6.5. Фақат аниқ ҳисоб топилганда мураббий ҳисобига 1 балл ёзилади.\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"

    "<b>7-БОБ. ЖАМОА ОЧКОЛАРИ</b>\n\n"
    "7.1. Жамоаларга очколар қуйидагича берилади:\n\n"
    "• ғалаба — 3 очко;\n\n"
    "• дурранг — 1 очко;\n\n"
    "• мағлубият — 0 очко.\n\n"
    "7.2. Очколар лига жадвалида акс эттирилади.\n\n"
    "━━━━━━━━━━━━━━━━━━━━\n\n"
    "🏆 <i>VFL Champions League расмий регламенти тугади.</i>"
)

# ── Keyboards ──────────────────────────────────────────────────────────────────

def _center_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📖 Қисқа қоидалар",  callback_data="reg_short")],
        [InlineKeyboardButton(text="📚 Тўлиқ регламент", callback_data="reg_full")],
        [InlineKeyboardButton(text="🏆 Турнир формати",  callback_data="reg_format")],
    ])


def _back_to_center() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="reg_center")],
    ])


# ── Handlers ───────────────────────────────────────────────────────────────────

@router.message(Command("regulation"))
async def cmd_regulation(message: Message, *, user_id: int | None = None) -> None:
    await message.answer(CENTER_TEXT, reply_markup=_center_keyboard(), parse_mode="HTML")


@router.callback_query(F.data == "reg_center")
async def cb_reg_center(callback: CallbackQuery) -> None:
    await callback.message.edit_text(CENTER_TEXT, reply_markup=_center_keyboard(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.in_({"reg_full", "reg_menu"}))
async def cb_reg_full(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        FULL_REG_TEXT,
        reply_markup=_back_to_center(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "reg_short")
async def cb_reg_short(callback: CallbackQuery) -> None:
    await callback.message.edit_text(SHORT_RULES_TEXT, reply_markup=_back_to_center(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "reg_format")
async def cb_reg_format(callback: CallbackQuery) -> None:
    await callback.message.edit_text(FORMAT_TEXT, reply_markup=_back_to_center(), parse_mode="HTML")
    await callback.answer()
