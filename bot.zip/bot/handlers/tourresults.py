"""
/tourresults — show tour/round results navigation menu.
"""

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.db import get_duel_results, get_playoff_results
from bot.data.league_stage_db import get_leg_result

router = Router()

_TOUR_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣"]
_TOTAL_TOURS  = 8

_PLAYOFF_STAGES = [
    ("tr:po:playoff", "🔥 Плей-офф"),
    ("tr:po:r16",     "🏆 1/8 финал"),
    ("tr:po:qf",      "🏆 1/4 финал"),
    ("tr:po:sf",      "🏆 1/2 финал"),
    ("tr:po:f",       "👑 Финал"),
]

_CB_BACK = "tr:back"

_STAGE_META = {
    "tr:po:playoff": ("playoff", "🔥 Плей-офф"),
    "tr:po:r16":     ("r16",     "🏆 1/8 финал"),
    "tr:po:qf":      ("qf",      "🏆 1/4 финал"),
    "tr:po:sf":      ("sf",      "🏆 1/2 финал"),
    "tr:po:f":       ("f",       "👑 Финал"),
}

# MD offsets for two-legged stages (leg1_md, leg2_md)
_STAGE_MD_MAP: dict[str, tuple[int, int]] = {
    "playoff": (9,  10),
    "r16":     (11, 12),
    "qf":      (13, 14),
    "sf":      (15, 16),
    "f":       (17, 17),
}


def _main_kb() -> InlineKeyboardMarkup:
    rows = []
    for i in range(_TOTAL_TOURS):
        rows.append([InlineKeyboardButton(
            text=f"{_TOUR_EMOJIS[i]} {i + 1}-тур",
            callback_data=f"tr:tour:{i + 1}",
        )])
    rows.append([InlineKeyboardButton(text="🏆 Плей-офф", callback_data="tr:po:menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _playoff_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=label, callback_data=cb)]
        for cb, label in _PLAYOFF_STAGES
    ]
    rows.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data=_CB_BACK)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Орқага", callback_data=_CB_BACK),
    ]])


def _back_to_playoff_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Орқага", callback_data="tr:po:menu"),
    ]])


def _duel_lines(records: list[dict]) -> list[str]:
    lines = []
    for d in records:
        gh = d["goals_home"]
        ga = d["goals_away"]
        icon = "🤝" if gh == ga else "🏆"
        lines.append(f"{icon} {d['home']} {gh}–{ga} {d['away']}")
    return lines


# ── /tourresults ──────────────────────────────────────────────────────────────

@router.message(Command("tourresults"))
async def cmd_tourresults(message: Message, *, user_id: int | None = None) -> None:
    await message.answer(
        "📊 <b>Тур натижалари</b>",
        reply_markup=_main_kb(),
    )


# ── Back to main menu ─────────────────────────────────────────────────────────

@router.callback_query(F.data == _CB_BACK)
async def cb_back(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        "📊 <b>Тур натижалари</b>",
        reply_markup=_main_kb(),
    )
    await callback.answer()


# ── Individual tour results ───────────────────────────────────────────────────

@router.callback_query(F.data.startswith("tr:tour:"))
async def cb_tour(callback: CallbackQuery) -> None:
    try:
        tour_n = int(callback.data.split(":")[-1])
    except ValueError:
        await callback.answer()
        return

    duels = get_duel_results(tour_n)
    lines = _duel_lines(duels)

    if lines:
        text = f"📊 <b>{tour_n}-тур натижалари</b>\n\n" + "\n".join(lines)
    else:
        text = (
            f"📊 <b>{tour_n}-тур натижалари</b>\n\n"
            "<i>⚠️ Ушбу тур натижалари архивда мавжуд эмас.</i>"
        )

    await callback.message.edit_text(text, reply_markup=_back_kb())
    await callback.answer()


# ── Playoff sub-menu ──────────────────────────────────────────────────────────

@router.callback_query(F.data == "tr:po:menu")
async def cb_playoff_menu(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        "🏆 <b>Плей-офф натижалари</b>",
        reply_markup=_playoff_kb(),
    )
    await callback.answer()


@router.callback_query(F.data.in_({"tr:po:playoff", "tr:po:r16", "tr:po:qf", "tr:po:sf", "tr:po:f"}))
async def cb_playoff_stage(callback: CallbackQuery) -> None:
    stage_key, label = _STAGE_META[callback.data]
    md_pair = _STAGE_MD_MAP.get(stage_key, (0, 0))

    back_kb = _back_to_playoff_kb()
    is_final = stage_key == "f"

    if is_final:
        records = get_duel_results(md_pair[0]) or get_playoff_results(stage_key)
        lines = _duel_lines(records)
        if lines:
            text = f"👑 <b>{label} натижалари</b>\n\n" + "\n".join(lines)
        else:
            text = (
                f"👑 <b>{label} натижалари</b>\n\n"
                "<i>⚠️ Ушбу босқич натижалари архивда мавжуд эмас.</i>"
            )
        await callback.message.edit_text(text, reply_markup=back_kb)
        await callback.answer()
        return

    # Two-legged stages: show leg 1 + leg 2
    leg1_md, leg2_md = md_pair
    leg1 = get_leg_result(stage_key, 1) or get_duel_results(leg1_md)
    leg2 = get_leg_result(stage_key, 2) or get_duel_results(leg2_md)

    text_parts = [f"{label} натижалари\n"]

    if leg1:
        text_parts.append("<b>1-ўйин:</b>")
        text_parts += _duel_lines(leg1)
        text_parts.append("")
    if leg2:
        text_parts.append("<b>2-ўйин:</b>")
        text_parts += _duel_lines(leg2)
    if not leg1 and not leg2:
        text_parts.append("<i>⚠️ Ушбу босқич натижалари архивда мавжуд эмас.</i>")

    await callback.message.edit_text("\n".join(text_parts), reply_markup=back_kb)
    await callback.answer()
