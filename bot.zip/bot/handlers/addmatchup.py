import os

from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

from bot.data.db import get_fixtures, get_matchups_for_round, save_matchup
from bot.data.teams_db import load_coaches

router = Router()


def _admin_id() -> str | None:
    return os.environ.get("ADMIN_ID", "").strip() or None




class AddMatchupForm(StatesGroup):
    waiting_for_round = State()
    waiting_for_home_coach = State()
    waiting_for_away_coach = State()
    waiting_for_fixtures = State()


def _get_coach_by_tid(tid_str: str) -> tuple[str | None, dict | None]:
    """Return (coach_name, coach_info) for the given Telegram ID string."""
    for name, info in load_coaches().items():
        if info.get("telegram_id") == tid_str:
            return name, info
    return None, None


def _coach_in_round(tid_str: str, round_no: int) -> bool:
    return any(
        tid_str in (m.get("coach_a", ""), m.get("coach_b", ""))
        for m in get_matchups_for_round(round_no)
    )


def _team_in_round(team_name: str, round_no: int) -> bool:
    return any(
        team_name in (m.get("home_team", ""), m.get("away_team", ""))
        for m in get_matchups_for_round(round_no)
    )


def _fixture_hint(round_no: int) -> str:
    fixtures = [f for f in get_fixtures() if f["round"] == round_no]
    if not fixtures:
        return f"<i>No fixtures found for Round {round_no} yet.</i>"
    lines = "\n".join(
        f"  <code>{f['id']}</code>  {f['home']} vs {f['away']}" for f in fixtures
    )
    return f"<b>Round {round_no} fixtures:</b>\n{lines}"


# ── /addmatchup ───────────────────────────────────────────────────────────────

@router.message(Command("addmatchup"))
async def cmd_addmatchup(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ This command is for admins only.")
        return

    await state.set_state(AddMatchupForm.waiting_for_round)
    await message.answer(
        "🗓️ <b>Add Matchup</b>\n\n"
        "Enter the <b>round number</b>:\n"
        "<i>Send /cancel to stop.</i>",
        parse_mode="HTML",
    )


@router.message(AddMatchupForm.waiting_for_round)
async def process_round(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()
    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Matchup setup cancelled.")
        return

    if not text.isdigit() or int(text) < 1:
        await message.answer("⚠️ Enter a valid round number (positive integer):")
        return

    round_no = int(text)
    await state.update_data(round=round_no)
    await state.set_state(AddMatchupForm.waiting_for_home_coach)
    await message.answer(
        f"✅ Round <b>{round_no}</b> selected.\n\n"
        f"{_fixture_hint(round_no)}\n\n"
        "Enter the Telegram ID of the <b>home</b> coach:",
        parse_mode="HTML",
    )


@router.message(AddMatchupForm.waiting_for_home_coach)
async def process_home_coach(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()
    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Matchup setup cancelled.")
        return

    data = await state.get_data()
    round_no: int = data["round"]

    coach_name, coach_info = _get_coach_by_tid(text)
    if not coach_info:
        await message.answer("⚠️ No registered coach found with that Telegram ID. Try again:")
        return

    if _coach_in_round(text, round_no):
        await message.answer(
            f"⚠️ <b>{coach_name}</b> is already assigned to a matchup in Round {round_no}.\n"
            "Enter a different Telegram ID:",
            parse_mode="HTML",
        )
        return

    home_team = coach_info.get("team", "—")
    await state.update_data(home_tid=text, home_name=coach_name, home_team=home_team)
    await state.set_state(AddMatchupForm.waiting_for_away_coach)
    await message.answer(
        f"🏠 Home coach: <b>{coach_name}</b> — {home_team}\n\n"
        "Enter the Telegram ID of the <b>away</b> coach:",
        parse_mode="HTML",
    )


@router.message(AddMatchupForm.waiting_for_away_coach)
async def process_away_coach(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()
    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Matchup setup cancelled.")
        return

    data = await state.get_data()
    round_no: int = data["round"]
    home_tid: str = data["home_tid"]
    home_team: str = data["home_team"]

    if text == home_tid:
        await message.answer("⚠️ The away coach must be different from the home coach. Try again:")
        return

    coach_name, coach_info = _get_coach_by_tid(text)
    if not coach_info:
        await message.answer("⚠️ No registered coach found with that Telegram ID. Try again:")
        return

    away_team = coach_info.get("team", "—")
    if away_team == home_team:
        await message.answer(
            f"⚠️ Both coaches manage <b>{home_team}</b>. Enter a different Telegram ID:",
            parse_mode="HTML",
        )
        return

    if _team_in_round(away_team, round_no):
        await message.answer(
            f"⚠️ <b>{away_team}</b> is already in a matchup for Round {round_no}.\n"
            "Each club may appear only once per round. Enter a different Telegram ID:",
            parse_mode="HTML",
        )
        return

    if _coach_in_round(text, round_no):
        await message.answer(
            f"⚠️ <b>{coach_name}</b> is already assigned to a matchup in Round {round_no}.\n"
            "Enter a different Telegram ID:",
            parse_mode="HTML",
        )
        return

    await state.update_data(away_tid=text, away_name=coach_name, away_team=away_team)
    await state.set_state(AddMatchupForm.waiting_for_fixtures)
    await message.answer(
        f"✈️ Away coach: <b>{coach_name}</b> — {away_team}\n\n"
        f"{_fixture_hint(round_no)}\n\n"
        "Enter exactly <b>5 fixture IDs</b>, separated by spaces\n"
        "(e.g. <code>r3_m1 r3_m2 r3_m3 r3_m4 r3_m5</code>):",
        parse_mode="HTML",
    )


@router.message(AddMatchupForm.waiting_for_fixtures)
async def process_fixtures(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()
    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Matchup setup cancelled.")
        return

    data = await state.get_data()
    round_no: int = data["round"]
    home_tid: str = data["home_tid"]
    home_name: str = data["home_name"]
    home_team: str = data["home_team"]
    away_tid: str = data["away_tid"]
    away_name: str = data["away_name"]
    away_team: str = data["away_team"]

    fixture_ids = text.split()

    if len(fixture_ids) != 5:
        await message.answer(
            f"⚠️ You entered {len(fixture_ids)} ID(s) — exactly 5 are required. Try again:"
        )
        return

    if len(set(fixture_ids)) != 5:
        await message.answer("⚠️ Duplicate fixture IDs detected. All 5 must be unique. Try again:")
        return

    all_fixture_ids = {f["id"] for f in get_fixtures()}
    missing = [fid for fid in fixture_ids if fid not in all_fixture_ids]
    if missing:
        missing_str = "  ".join(f"<code>{m}</code>" for m in missing)
        await message.answer(
            f"⚠️ Unknown fixture ID(s): {missing_str}\n"
            "Check the IDs and try again:",
            parse_mode="HTML",
        )
        return

    matchup = {
        "round": round_no,
        "coach_a": home_tid,
        "coach_b": away_tid,
        "home_team": home_team,
        "away_team": away_team,
        "fixture_ids": fixture_ids,
    }
    save_matchup(matchup)
    await state.clear()

    fixture_list = "  ".join(f"<code>{fid}</code>" for fid in fixture_ids)
    await message.answer(
        f"✅ <b>Matchup created for Round {round_no}!</b>\n\n"
        f"🏠 <b>{home_team}</b>  ({home_name})\n"
        f"✈️ <b>{away_team}</b>  ({away_name})\n\n"
        f"📋 Fixtures: {fixture_list}\n\n"
        f"Both coaches can now use /predict for Round {round_no}.",
        parse_mode="HTML",
    )
