from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.calendar_db import TOTAL_ROUNDS, get_current_stage
from bot.data.dates_db import get_date as get_stage_date
from bot.data.draw_db import (
    SEASON1_POTS,
    draw_exists,
    get_round_fixtures,
)
from bot.data.league_stage_db import (
    FIXED_BRACKET_ORDER,
    get_playoff_bracket,
    get_stage_bracket,
    get_stage_winners,
)
from bot.data.playoff_draw_db import get_playoff_draw
router = Router()

# ── Stage display labels ───────────────────────────────────────────────────────

STAGE_LABELS: dict[str, str] = {
    "playoff":    "🔥 Плей-офф",
    "round_of_16": "🏆 1/8 финал",
    "quarter":    "🏆 1/4 финал",
    "semi":       "🏆 1/2 финал",
    "final":      "👑 Финал",
}

PLAYOFF_STAGES = [
    ("🔥 Плей-офф",     "cal_ps:playoff"),
    ("🏆 1/8 финал",    "cal_ps:r16"),
    ("🏆 1/4 финал",    "cal_ps:quarter"),
    ("🏆 1/2 финал",    "cal_ps:semi"),
]

# MD numbers for each playoff stage leg
_STAGE_LEG_MD: dict[str, tuple[int, int]] = {
    "playoff": (9,  10),
    "r16":     (11, 12),
    "quarter": (13, 14),
    "semi":    (15, 16),
}

# Map cal_ps keys to league_stage_db stage keys
_CAL_TO_STAGE: dict[str, str] = {
    "playoff": "playoff",
    "r16":     "r16",
    "quarter": "qf",
    "semi":    "sf",
}


# ── Current stage string ───────────────────────────────────────────────────────

def _current_stage_text() -> str:
    stage = get_current_stage()
    if stage == "none":
        return "⏳ Мавсум ҳали бошланмаган"
    if stage.startswith("league:"):
        rno = stage.split(":")[1]
        return f"⚽ {rno}-Тур"
    return STAGE_LABELS.get(stage, f"⚽ {stage}")


# ── Keyboard builders ──────────────────────────────────────────────────────────

def _main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📦 Саватчалар",    callback_data="cal_draw")],
        [InlineKeyboardButton(text="📅 Лига босқичи", callback_data="cal_league")],
        [InlineKeyboardButton(text="🔥 Плей-офф",     callback_data="cal_playoff")],
        [InlineKeyboardButton(text="👑 Финал",         callback_data="cal_final")],
    ])


def _back_to_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="cal_main")],
    ])


def _league_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"⚽ {r}-Тур", callback_data=f"cal_round:{r}")]
        for r in range(1, TOTAL_ROUNDS + 1)
    ]
    rows.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data="cal_main")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _playoff_keyboard() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=cb)] for label, cb in PLAYOFF_STAGES]
    rows.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data="cal_main")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _back_to_league() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="cal_league")],
    ])


def _back_to_playoff() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="cal_playoff")],
    ])


# ── Main page text ─────────────────────────────────────────────────────────────

def _main_text() -> str:
    return (
        "🏆 <b>VFL Champions League</b>\n\n"
        "📅 <b>Мавсум тақвими</b>\n\n"
        "━━━━━━━━━━━━\n"
        f"🟢 <b>Жорий босқич:</b> {_current_stage_text()}\n"
        "━━━━━━━━━━━━"
    )


# ── /calendar entry point ──────────────────────────────────────────────────────

@router.message(Command("calendar"))
async def cmd_calendar(message: Message, *, user_id: int | None = None) -> None:
    await message.answer(_main_text(), reply_markup=_main_keyboard(), parse_mode="HTML")


# ── Main menu callback ─────────────────────────────────────────────────────────

@router.callback_query(F.data == "cal_main")
async def cb_cal_main(callback: CallbackQuery) -> None:
    await callback.message.edit_text(_main_text(), reply_markup=_main_keyboard(), parse_mode="HTML")
    await callback.answer()


# ── Home button → send a fresh /start-style message ───────────────────────────

@router.callback_query(F.data == "cal_home")
async def cb_cal_home(callback: CallbackQuery) -> None:
    from bot.handlers.start import cmd_start
    await callback.answer()
    await cmd_start(callback.message)


# ── Draw ───────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "cal_draw")
async def cb_cal_draw(callback: CallbackQuery) -> None:
    if not draw_exists():
        await callback.message.edit_text(
            "📦 <b>Саватчалар</b>\n\n"
            "⏳ Қуръа ҳали ўтказилмаган.",
            reply_markup=_back_to_main(),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    # Show draw summary with pot structure
    pot_icons = {"1": "🥇", "2": "🥈", "3": "🥉", "4": "🎖"}
    lines = ["📦 <b>Саватчалар</b>\n", "✅ <b>Қуръа якунланди!</b>\n"]
    for pot_no, clubs in SEASON1_POTS.items():
        icon = pot_icons[pot_no]
        # 3 clubs per line for compact display
        rows = [" • ".join(clubs[i:i+3]) for i in range(0, len(clubs), 3)]
        lines.append(f"{icon} <b>Пот {pot_no}</b>")
        lines.extend(rows)
        lines.append("")
    lines.append("✅ 36 жамоа  |  ✅ 144 учрашув  |  ✅ 8 тур")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=_back_to_main(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── League stage ───────────────────────────────────────────────────────────────

@router.callback_query(F.data == "cal_league")
async def cb_cal_league(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        "📅 <b>Лига босқичи</b>\n\nТурни танланг:",
        reply_markup=_league_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("cal_round:"))
async def cb_cal_round(callback: CallbackQuery) -> None:
    try:
        round_no = int(callback.data.split(":")[1])
    except (IndexError, ValueError):
        await callback.answer("⚠️ Хато.", show_alert=True)
        return

    date_str  = get_stage_date(str(round_no))
    date_line = f"📅 {date_str}" if date_str else "📅 Сана киритилмаган"
    fixtures  = get_round_fixtures(round_no)

    if not fixtures:
        await callback.message.edit_text(
            f"⚽ <b>{round_no}-ТУР</b>\n\n"
            f"{date_line}\n\n"
            "⏳ Учрашувлар ҳали шакллантирилмаган.",
            reply_markup=_back_to_league(),
            parse_mode="HTML",
        )
        await callback.answer()
        return

    # Sort fixtures by their index for consistent display
    sorted_fx = sorted(fixtures, key=lambda f: f.get("id", ""))
    lines = [f"⚽ <b>{round_no}-ТУР</b>\n", date_line, ""]
    for i, f in enumerate(sorted_fx, 1):
        lines.append(f"{i}. <b>{f['home']}</b>  —  {f['away']}")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=_back_to_league(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Playoff bracket (direct view) ─────────────────────────────────────────────

def _playoff_bracket_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="1️⃣ 1-ўйин", callback_data="cal_leg:playoff:1"),
            InlineKeyboardButton(text="2️⃣ 2-ўйин", callback_data="cal_leg:playoff:2"),
        ],
        [InlineKeyboardButton(text="🏆 1/8 финал",  callback_data="cal_ps:r16")],
        [InlineKeyboardButton(text="🏆 1/4 финал",  callback_data="cal_ps:quarter")],
        [InlineKeyboardButton(text="🏆 1/2 финал",  callback_data="cal_ps:semi")],
        [InlineKeyboardButton(text="👑 Финал",       callback_data="cal_final")],
        [InlineKeyboardButton(text="⬅️ Орқага",     callback_data="cal_main")],
    ])


@router.callback_query(F.data == "cal_playoff")
async def cb_cal_playoff(callback: CallbackQuery) -> None:
    bracket = get_playoff_bracket()

    if bracket:
        lines = ["🔥 <b>Плей-офф</b>\n", "✅ <b>Жуфтликлар аниқланди</b>\n"]
        for i, p in enumerate(bracket, 1):
            lines.append(f"A{i}: <b>{p['team1']}</b>  🆚  <b>{p['team2']}</b>")
    else:
        lines = ["🔥 <b>Плей-офф</b>\n"]
        for i, (p1, p2) in enumerate(FIXED_BRACKET_ORDER, 1):
            lines.append(f"A{i}: {p1}-ўрин  🆚  {p2}-ўрин")

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=_playoff_bracket_keyboard(),
        parse_mode="HTML",
    )
    await callback.answer()


def _legs_keyboard(key: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="1️⃣ 1-ўйин", callback_data=f"cal_leg:{key}:1")],
        [InlineKeyboardButton(text="2️⃣ 2-ўйин", callback_data=f"cal_leg:{key}:2")],
        [InlineKeyboardButton(text="⬅️ Орқага", callback_data="cal_playoff")],
    ])


@router.callback_query(F.data.startswith("cal_ps:"))
async def cb_cal_playoff_stage(callback: CallbackQuery) -> None:
    key = callback.data[len("cal_ps:"):]

    label_map = {
        "playoff": "🔥 Плей-офф",
        "r16":     "🏆 1/8 финал",
        "quarter": "🏆 1/4 финал",
        "semi":    "🏆 1/2 финал",
    }
    label = label_map.get(key, "🏆 Босқич")

    # Show bracket pairings + two-leg buttons
    stage_key = _CAL_TO_STAGE.get(key, key)
    bracket = get_playoff_bracket() if key == "playoff" else get_stage_bracket(stage_key)

    if bracket:
        if key == "playoff":
            pairs_text = "\n".join(
                f"<b>{p['team1']}</b>  🆚  <b>{p['team2']}</b>"
                for p in bracket
            )
        else:
            pairs_text = "\n".join(
                f"<b>{p['home']}</b>  🆚  <b>{p['away']}</b>"
                for p in bracket
            )
        text = f"{label}\n\n🎯 <b>Жуфтликлар:</b>\n\n{pairs_text}\n\n📅 Ўйинни танланг:"
    else:
        # Show slot positions before bracket is determined
        from bot.data.league_stage_db import FIXED_BRACKET_ORDER
        if key == "playoff":
            slots = "\n".join(
                f"{p1}-ўрин  🆚  {p2}-ўрин"
                for p1, p2 in FIXED_BRACKET_ORDER
            )
            text = f"{label}\n\n🎯 <b>Жуфтликлар (қуръадан сўнг):</b>\n\n{slots}\n\n📅 Ўйинни танланг:"
        else:
            text = f"{label}\n\n⏳ Ҳали аниқланмаган.\n\n📅 Ўйинни танланг:"

    await callback.message.edit_text(
        text,
        reply_markup=_legs_keyboard(key),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("cal_leg:"))
async def cb_cal_leg(callback: CallbackQuery) -> None:
    parts = callback.data.split(":")
    if len(parts) != 3:
        await callback.answer()
        return
    _, key, leg_str = parts
    try:
        leg = int(leg_str)
    except ValueError:
        await callback.answer()
        return

    leg_md_map = _STAGE_LEG_MD.get(key)
    md_no = leg_md_map[leg - 1] if leg_md_map else 0
    date_str = get_stage_date(str(md_no)) if md_no else None
    date_line = f"📅 {date_str}" if date_str else "📅 Сана киритилмаган"

    label_map = {
        "playoff": "🔥 Плей-офф",
        "r16":     "🏆 1/8 финал",
        "quarter": "🏆 1/4 финал",
        "semi":    "🏆 1/2 финал",
    }
    label = label_map.get(key, "🏆 Босқич")
    stage_key = _CAL_TO_STAGE.get(key, key)

    # Get fixtures for this leg
    bracket = get_playoff_bracket() if key == "playoff" else get_stage_bracket(stage_key)

    back_kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Орқага", callback_data=f"cal_ps:{key}"),
    ]])

    if not bracket:
        await callback.message.edit_text(
            f"{label} — {leg}-ўйин\n\n{date_line}\n\n⏳ Ҳали аниқланмаган.",
            reply_markup=back_kb,
            parse_mode="HTML",
        )
        await callback.answer()
        return

    if key == "playoff":
        if leg == 2:
            pairs_text = "\n".join(
                f"{i}. <b>{p['team2']}</b>  🆚  <b>{p['team1']}</b>"
                for i, p in enumerate(bracket, 1)
            )
        else:
            pairs_text = "\n".join(
                f"{i}. <b>{p['team1']}</b>  🆚  <b>{p['team2']}</b>"
                for i, p in enumerate(bracket, 1)
            )
    else:
        if leg == 2:
            pairs_text = "\n".join(
                f"{i}. <b>{p['away']}</b>  🆚  <b>{p['home']}</b>"
                for i, p in enumerate(bracket, 1)
            )
        else:
            pairs_text = "\n".join(
                f"{i}. <b>{p['home']}</b>  🆚  <b>{p['away']}</b>"
                for i, p in enumerate(bracket, 1)
            )

    await callback.message.edit_text(
        f"{label} — {leg}-ўйин\n\n{date_line}\n\n{pairs_text}",
        reply_markup=back_kb,
        parse_mode="HTML",
    )
    await callback.answer()


# ── Final ──────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "cal_final")
async def cb_cal_final(callback: CallbackQuery) -> None:
    date_str  = get_stage_date("final")
    date_line = f"📅 {date_str}" if date_str else "📅 Сана киритилмаган"
    await callback.message.edit_text(
        "👑 <b>ФИНАЛ</b>\n\n"
        f"{date_line}\n\n"
        "⏳ Ҳали аниқланмаган.",
        reply_markup=_back_to_main(),
        parse_mode="HTML",
    )
    await callback.answer()
