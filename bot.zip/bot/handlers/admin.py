"""
/admin — admin-only control panel.

Top-level menu:
  👥 Иштирокчилар    — info only (list, licenses, coaches)
  📜 Буйруқлар       — command reference
  🛡 Тизим бошқаруви — all management actions

System Management sub-menu:
  👤 Иштирокчини ўчириш   → /removeparticipant
  🔄 Жамоани бўшатиш       → releaseteam flow
  🏟 Жамоани алмаштириш  → replaceteam flow
  🗑 Мавсумни ўчириш        → /deleteseason
  🗓 Турни ўчириш            → /deletematchday
  📢 Эълон маркази          → announcement flow
"""

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.admin_ids import is_admin as _is_admin

router = Router()


# ── Keyboards ─────────────────────────────────────────────────────────────────

_MAIN_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="👥 Иштирокчилар",     callback_data="adm:participants")],
    [InlineKeyboardButton(text="🛡 Тизим бошқаруви", callback_data="adm:system")],
])

_SYSTEM_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="👤 Иштирокчини ўчириш",  callback_data="adm:sys:rmpart")],
    [InlineKeyboardButton(text="🔄 Жамоани бўшатиш",      callback_data="adm:sys:release")],
    [InlineKeyboardButton(text="🏟 Жамоани алмаштириш",  callback_data="adm:sys:replace")],
    [InlineKeyboardButton(text="🗑 Мавсумни ўчириш",       callback_data="adm:sys:rmseason")],
    [InlineKeyboardButton(text="🗓 Турни ўчириш",           callback_data="adm:sys:rmmd")],
    [InlineKeyboardButton(text="📢 Эълон маркази",         callback_data="adm:announcement")],
    [InlineKeyboardButton(text="⬅️ Орқага",                callback_data="adm:menu")],
])

_BACK_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:menu"),
]])

_BACK_SYS_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:system"),
]])


# ── /admin ────────────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        await message.answer("⛔ Сизда админ ҳуқуқлари мавжуд эмас.")
        return
    await message.answer(
        "🛠 <b>АДМИН ПАНЕЛИ</b>",
        reply_markup=_MAIN_KB,
        parse_mode="HTML",
    )


# ── Top-level navigation ──────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:menu")
async def cb_main_menu(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "🛠 <b>АДМИН ПАНЕЛИ</b>",
        reply_markup=_MAIN_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── System Management menu ────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:system")
async def cb_system(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "🛡 <b>ТИЗИМ БОШҚАРУВИ</b>\n\n"
        "⚠️ Бу бўлимдаги амаллар тасдиқлашни талаб қилади.\n\n"
        "🔒 <b>Ҳимояланган:</b> Hall of Fame, рейтинглар, мавсум созламалари",
        reply_markup=_SYSTEM_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── System Management — guidance items ───────────────────────────────────────

@router.callback_query(F.data == "adm:sys:rmpart")
async def cb_sys_rmpart(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    from bot.handlers.removeparticipant import RemoveParticipantForm
    await state.set_state(RemoveParticipantForm.waiting_input)
    await callback.message.answer(
        "👤 <b>Иштирокчини ўчириш</b>\n\n"
        "Лицензия рақами <i>(VFL0001)</i> ёки жамоа номини киритинг:\n\n"
        "<i>Бекор қилиш: /cancel</i>",
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "adm:sys:rmseason")
async def cb_sys_rmseason(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text(
        "🗑 <b>Мавсумни ўчириш</b>\n\n"
        "Қуйидаги буйруқни ишлатинг:\n\n"
        "<code>/deleteseason</code>\n\n"
        "⚠️ Икки босқичли тасдиқлаш талаб қилинади.\n\n"
        "🔒 Ҳеч қачон ўчирилмайди: Hall of Fame, рейтинглар.",
        reply_markup=_BACK_SYS_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "adm:sys:rmmd")
async def cb_sys_rmmd(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text(
        "🗓 <b>Турни ўчириш</b>\n\n"
        "Қуйидаги буйруқни ишлатинг:\n\n"
        "<code>/deletematchday</code>\n\n"
        "⚠️ Тасдиқлаш талаб қилинади.",
        reply_markup=_BACK_SYS_KB,
        parse_mode="HTML",
    )
    await callback.answer()
