from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()

_SHOW = 15   # max items displayed per request


@router.message(Command("news"))
async def cmd_news(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.news_db import load_news

    news = load_news()   # already newest-first

    if not news:
        await message.answer(
            "📰 <b>VFL News</b>\n\n"
            "Ҳозирча янгиликлар йўқ.\n\n"
            "Биринчи Match Day якунлангандан кейин автоматик яратилади.",
            parse_mode="HTML",
        )
        return

    items = news[:_SHOW]
    lines = [f"📰 <b>VFL NEWS</b>  <i>(сўнгги {len(items)} та)</i>"]

    for item in items:
        icon     = item.get("icon", "📌")
        headline = item.get("headline", "")
        body     = item.get("body", "")
        date     = item.get("date", "")
        md       = item.get("match_day", "")

        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"{icon} <b>{headline}</b>")
        if date or md:
            meta = f"MD#{md}" if md else ""
            meta = f"{meta}  {date}" if date else meta
            lines.append(f"<i>{meta.strip()}</i>")
        if body:
            lines.append(body)

    if len(news) > _SHOW:
        lines.append(f"\n<i>…яна {len(news) - _SHOW} та янгилик мавжуд</i>")

    # Split into chunks if needed (Telegram 4096 char limit)
    text = "\n".join(lines)
    if len(text) <= 4096:
        await message.answer(text, parse_mode="HTML")
    else:
        # Send in two halves
        mid = len(items) // 2
        await message.answer(_render(items[:mid]), parse_mode="HTML")
        await message.answer(_render(items[mid:]), parse_mode="HTML")


def _render(items: list[dict]) -> str:
    lines: list[str] = []
    for item in items:
        icon     = item.get("icon", "📌")
        headline = item.get("headline", "")
        body     = item.get("body", "")
        date     = item.get("date", "")
        md       = item.get("match_day", "")
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"{icon} <b>{headline}</b>")
        if date or md:
            meta = f"MD#{md}  {date}".strip() if md else date
            lines.append(f"<i>{meta}</i>")
        if body:
            lines.append(body)
    return "\n".join(lines)
