from bot.data.admin_ids import is_admin as _is_admin
"""
/editdate — edit an existing round date (admin only).

Flow:
  1. /editdate → inline list of rounds that have a date set
  2. Admin taps a round → shown current date, prompted for new date
  3. Admin types new date → saved, confirmation shown
"""


from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.dates_db import STAGE_LABELS, STAGE_ORDER, get_all_dates, set_date

router = Router()





class EditDateSG(StatesGroup):
    waiting_new_date = State()


_CB_PREFIX = "editdate:round:"
_CB_CANCEL = "editdate:cancel"


def _round_list_kb(all_dates: dict) -> InlineKeyboardMarkup:
    """One button per round that has a date set."""
    rows = []
    for stage in STAGE_ORDER:
        date = all_dates.get(stage)
        if not date:
            continue
        label = STAGE_LABELS[stage].replace("⚽ ", "").replace("🔥 ", "").replace("🏆 ", "").replace("👑 ", "")
        rows.append([InlineKeyboardButton(
            text=f"{label} — {date}",
            callback_data=f"{_CB_PREFIX}{stage}",
        )])
    rows.append([InlineKeyboardButton(text="❌ Бекор қилиш", callback_data=_CB_CANCEL)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(Command("editdate"))
async def cmd_editdate(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        await message.answer("⛔ Сизда админ ҳуқуқи мавжуд эмас.")
        return

    await state.clear()

    all_dates = get_all_dates()
    has_any = any(v for v in all_dates.values())

    if not has_any:
        await message.answer("⚠️ Ҳозирча ҳеч қандай сана белгиланмаган.")
        return

    await message.answer(
        "📅 <b>Тур санасини ўзгартириш</b>\n\n"
        "Қайси тур санасини ўзгартирмоқчисиз?",
        reply_markup=_round_list_kb(all_dates),
    )


@router.callback_query(F.data.startswith(_CB_PREFIX))
async def cb_select_round(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    stage = callback.data[len(_CB_PREFIX):]
    all_dates = get_all_dates()
    current_date = all_dates.get(stage) or "—"
    label = STAGE_LABELS.get(stage, stage)

    await state.set_state(EditDateSG.waiting_new_date)
    await state.update_data(stage=stage, old_date=current_date, label=label)

    await callback.message.edit_text(
        f"📅 <b>{label}</b>\n\n"
        f"Жорий сана:\n{current_date}\n\n"
        "Янги санани киритинг:\n\n"
        "Масалан:\n<code>30.09.2026</code>",
    )
    await callback.answer()


@router.callback_query(F.data == _CB_CANCEL)
async def cb_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("❌ Бекор қилинди.")
    await callback.answer()


@router.message(EditDateSG.waiting_new_date)
async def msg_new_date(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    new_date = (message.text or "").strip()
    if new_date.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return
    if not new_date:
        await message.answer("❌ Сана бўш бўлиши мумкин эмас. Илтимос, қайта киритинг.")
        return

    data = await state.get_data()
    stage: str = data["stage"]
    old_date: str = data["old_date"]
    label: str = data["label"]

    set_date(stage, new_date)
    await state.clear()

    await message.answer(
        "✅ <b>Тур санаси янгиланди</b>\n\n"
        f"📅 <b>{label}</b>\n\n"
        f"Эски сана:\n{old_date}\n\n"
        f"Янги сана:\n{new_date}",
    )
