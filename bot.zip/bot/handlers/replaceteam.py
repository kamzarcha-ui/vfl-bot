from bot.data.admin_ids import is_admin as _is_admin
"""
🏟 Replace Team — Admin: rename a club without reducing league size.

Coach ownership, license, players, statistics, and HOF records are all
preserved. Only the club name changes. League always stays at 36 teams.

Flow:
  System Management → 🏟 Жамоани алмаштириш
  → FSM: type current team name
  → Validate → type new team name
  → Validate → confirm (inline ✅ / ❌)
  → Execute rename + broadcast announcement
"""

import os

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

router = Router()

_GROUP_ID = os.environ.get("GROUP_ID", "").strip()

_BACK_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:system"),
]])

_CONFIRM_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="✅ Ҳа, алмаштириш",  callback_data="adm:rep:confirm"),
    InlineKeyboardButton(text="❌ Бекор қилиш",     callback_data="adm:rep:cancel"),
]])




async def _broadcast(bot, text: str) -> None:
    from bot.data.teams_db import load_teams
    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), text, parse_mode="HTML")
        except Exception:
            pass


# ── FSM ───────────────────────────────────────────────────────────────────────

class ReplaceTeamForm(StatesGroup):
    waiting_old_name = State()
    waiting_new_name = State()


# ── Start ─────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:sys:replace")
async def cb_replace_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.set_state(ReplaceTeamForm.waiting_old_name)
    await callback.message.edit_text(
        "🏟 <b>Жамоани алмаштириш</b>\n\n"
        "Алмаштириладиган жорий жамоа номини киритинг:\n\n"
        "<i>Бекор қилиш: /cancel</i>",
        reply_markup=None,
        parse_mode="HTML",
    )
    await callback.answer()


# ── Step 1: current team name ─────────────────────────────────────────────────

@router.message(ReplaceTeamForm.waiting_old_name)
async def process_old_name(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди.")
        return

    from bot.data.teams_db import load_teams
    teams   = load_teams()
    matched = next((k for k in teams if k.lower() == text.lower()), None)

    if not matched:
        await message.answer(
            f"⚠️ <b>{text}</b> — жамоа топилмади.\n\n"
            "Жамоа номини аниқ киритинг:",
            parse_mode="HTML",
        )
        return

    await state.update_data(rep_old=matched)
    await state.set_state(ReplaceTeamForm.waiting_new_name)

    info  = teams[matched]
    coach = info.get("coach", "—")
    lic   = info.get("license", "—")

    await message.answer(
        f"✅ <b>{matched}</b> топилди.\n"
        f"   👤 {coach}  •  🪪 {lic}\n\n"
        "Янги жамоа номини киритинг:\n\n"
        "<i>Бекор қилиш: /cancel</i>",
        parse_mode="HTML",
    )


# ── Step 2: new team name ─────────────────────────────────────────────────────

@router.message(ReplaceTeamForm.waiting_new_name)
async def process_new_name(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди.")
        return

    data     = await state.get_data()
    old_name = data.get("rep_old", "")

    from bot.data.teams_db import load_teams
    teams = load_teams()

    # Reject if the new name already exists (and is not the old name itself)
    if any(k.lower() == text.lower() and k != old_name for k in teams):
        await message.answer(
            f"⚠️ <b>{text}</b> — бу ном аллақачон мавжуд.\n\n"
            "Бошқа ном киритинг:",
            parse_mode="HTML",
        )
        return

    await state.update_data(rep_new=text)

    info  = teams.get(old_name, {})
    coach = info.get("coach", "—")

    await message.answer(
        "🏟 <b>Жамоани алмаштириш — Тасдиқлаш</b>\n\n"
        f"❌ Эски ном: <b>{old_name}</b>\n"
        f"✅ Янги ном: <b>{text}</b>\n"
        f"👤 Мураббий: <b>{coach}</b>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "✅ Сақланади: мураббий, лицензия, ўйинчилар, статистика, HOF\n"
        "✅ Лига: 36 жамоа (ўзгармайди)\n\n"
        "<b>Тасдиқлайсизми?</b>",
        reply_markup=_CONFIRM_KB,
        parse_mode="HTML",
    )


# ── Confirm ───────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:rep:confirm")
async def cb_replace_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    data     = await state.get_data()
    old_name = data.get("rep_old", "")
    new_name = data.get("rep_new", "")
    await state.clear()

    if not old_name or not new_name:
        await callback.message.edit_text("⚠️ Маълумот топилмади.", reply_markup=_BACK_KB)
        await callback.answer()
        return

    _execute_replace(old_name, new_name)

    await callback.message.edit_text(
        f"✅ <b>{old_name}</b> → <b>{new_name}</b>\n\n"
        "Жамоа муваффақиятли алмаштирилди.\n"
        "Мураббий, лицензия ва статистикалар сақланди.\n"
        "Лига: 36 жамоа ✅",
        reply_markup=_BACK_KB,
        parse_mode="HTML",
    )
    await callback.answer()

    ann_text = (
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "📢 <b>VFL РАСМИЙ ХАБАРИ</b>\n\n"
        f"🏟 <b>{old_name}</b> VFL таркибидан чиқарилди.\n\n"
        f"🆕 <b>{new_name}</b> VFL га қўшилди.\n\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )

    if _GROUP_ID:
        try:
            await callback.message.bot.send_message(int(_GROUP_ID), ann_text, parse_mode="HTML")
        except Exception:
            pass
    await _broadcast(callback.message.bot, ann_text)

    try:
        from bot.data.announcements_db import save_announcement
        from bot.data.season_db import get_current_season
        save_announcement(
            f"🏟 {old_name} VFL таркибидан чиқарилди. 🆕 {new_name} VFL га қўшилди.",
            get_current_season(),
        )
    except Exception:
        pass


# ── Cancel ────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:rep:cancel")
async def cb_replace_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "❌ Жамоани алмаштириш бекор қилинди.",
        reply_markup=_BACK_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── Execution ─────────────────────────────────────────────────────────────────

def _execute_replace(old_name: str, new_name: str) -> None:
    """
    Rename old_name → new_name in teams.json.
    All values (coach, telegram_id, license, players, stats) are preserved.
    League count is unchanged — 36 teams remain.
    """
    from bot.data.teams_db import load_teams, save_teams

    teams = load_teams()
    if old_name not in teams:
        return
    teams[new_name] = teams.pop(old_name)
    save_teams(teams)
