from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("awards"))
async def cmd_awards(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.season_db import load_awards

    all_awards = sorted(load_awards(), key=lambda x: x.get("season", 0))

    if not all_awards:
        await message.answer(
            "🏆 <b>Мавсум совринлари</b>\n\n"
            "Ҳозирча совринлар мавжуд эмас.\n\n"
            "Мавсум якунида автоматик аниқланади.",
            parse_mode="HTML",
        )
        return

    lines = ["🏆 <b>МАВСУМ СОВРИНЛАРИ</b>"]

    for a in all_awards:
        season = a.get("season", "?")
        gb     = a.get("golden_boot")
        gp     = a.get("golden_predictor")
        bp     = a.get("best_player")
        dt     = a.get("dream_team", [])

        gb_text = f"{gb['name']} ({gb.get('goals', 0)} гол)" if gb else "—"
        gp_text = f"{gp['name']} ({gp.get('exact', 0)} аниқ)" if gp else "—"
        bp_text = bp["name"] if bp else "—"
        dt_text = (
            ", ".join(dt[:6]) + ("…" if len(dt) > 6 else "")
            if dt else "—"
        )

        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"🏆 <b>Мавсум {season}</b>\n")
        lines.append(f"⚽ Golden Boot: <b>{gb_text}</b>")
        lines.append(f"🎯 Golden Predictor: <b>{gp_text}</b>")
        lines.append(f"⭐ Энг яхши футболчи: <b>{bp_text}</b>")
        lines.append(f"⭐ Dream Team: {dt_text}")

    await message.answer("\n".join(lines), parse_mode="HTML")
