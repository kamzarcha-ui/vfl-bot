from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("history"))
async def cmd_history(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.season_db import load_history

    history = sorted(load_history(), key=lambda x: x.get("season", 0))

    if not history:
        await message.answer(
            "📚 <b>Мавсумлар архиви</b>\n\n"
            "Ҳозирча архив мавжуд эмас.\n\n"
            "Биринчи мавсум якунлангач архив автоматик шаклланади.",
            parse_mode="HTML",
        )
        return

    for entry in history:
        season    = entry.get("season", "?")
        champion  = entry.get("champion") or "—"
        runner_up = entry.get("runner_up") or "—"

        sf_all = entry.get("sf_all") or entry.get("semi_finalists", [])
        qf     = entry.get("quarter_finalists", [])
        r16    = entry.get("r16_participants", [])
        po     = entry.get("playoff_teams", [])

        gb = entry.get("top_scorer")
        gp = entry.get("golden_predictor")
        bp = entry.get("best_player")
        dt = entry.get("dream_team", [])
        lt = entry.get("league_table", [])

        gb_text = f"{gb['name']} ({gb.get('goals', 0)} гол)" if gb else "—"
        gp_text = f"{gp['name']} ({gp.get('exact', 0)} аниқ)" if gp else "—"
        bp_text = bp["name"] if bp else "—"
        dt_text = (
            ", ".join(dt[:7]) + ("…" if len(dt) > 7 else "")
            if dt else "—"
        )

        sf_text = ", ".join(sf_all[:4]) if sf_all else "—"
        qf_text = (
            ", ".join(qf[:4]) + ("…" if len(qf) > 4 else "")
            if qf else "—"
        )
        r16_text = f"{len(r16)} жамоа" if r16 else "—"
        po_text  = f"{len(po)} жамоа"  if po  else "—"

        lt_lines = ""
        for row in lt[:5]:
            lt_lines += f"{row.get('pos', '?')}. {row.get('team', '?')} — {row.get('pts', 0)} оч\n"

        lines = [
            "━━━━━━━━━━━━━━━━━━━━",
            f"🏆 <b>МАВСУМ {season}</b>",
            "",
            f"👑 Чемпион: <b>{champion}</b>",
            f"🥈 Финалист: <b>{runner_up}</b>",
            f"🥉 Ярим финалчилар: {sf_text}",
            f"🏅 Чорак финалчилар: {qf_text}",
            f"🎟 1/8 финал: {r16_text}",
            f"🔥 Плей-офф: {po_text}",
            "",
            f"⚽ Golden Boot: <b>{gb_text}</b>",
            f"🎯 Golden Predictor: <b>{gp_text}</b>",
            f"⭐ Энг яхши: <b>{bp_text}</b>",
            f"⭐ Dream Team: {dt_text}",
        ]
        if lt_lines:
            lines += ["", "📊 Лига жадвали (ТОП-5):", lt_lines.strip()]

        await message.answer("\n".join(lines), parse_mode="HTML")

    await message.answer(
        f"📚 <b>Жами архивланган мавсумлар: {len(history)} та</b>",
        parse_mode="HTML",
    )
