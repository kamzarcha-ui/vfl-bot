from bot.data.admin_ids import is_admin as _is_admin
"""
/setdeadline   — interactively set a new deadline (admin only, FSM).
/editdeadline  — interactively change an existing deadline (admin only, FSM).
/deadline      — view the current deadline (any user).
/resetdeadline — wipe the deadline with confirmation (admin only).
"""

import re as _re
from datetime import datetime

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.deadline_db import (
    deadline_display,
    get_deadline,
    reset_deadline,
    set_deadline,
)

from bot.data.teams_db import load_teams

router = Router()



# ── FSM states ─────────────────────────────────────────────────────────────────

class SetDeadlineSG(StatesGroup):
    waiting = State()


class EditDeadlineSG(StatesGroup):
    waiting = State()


# ── Shared helpers ─────────────────────────────────────────────────────────────

_EXAMPLE = "17.06.2026 08:30"
_FORMAT  = "%d.%m.%Y %H:%M"


def _autocorrect_date(s: str) -> str | None:
    """
    Return a corrected date string or None if the pattern is unrecognizable.
    Handles: DD.MMYYYY → DD.MM.YYYY  (missing dot between month and year).
    """
    if _re.fullmatch(r'\d{1,2}\.\d{1,2}\.\d{4}', s):
        return s
    m = _re.fullmatch(r'(\d{1,2})\.(\d{2})(\d{4})', s)
    if m:
        return f"{m.group(1)}.{m.group(2)}.{m.group(3)}"
    return None


def _parse_detailed(text: str) -> tuple[tuple[str, str, bool], None] | tuple[None, str]:
    """
    Parse deadline input with auto-correction and specific error codes.

    Returns ((date_str, time_str, was_corrected), None) on success.
    Returns (None, error_key) on failure — error_key ∈ {"format", "date", "time"}.
    """
    parts = text.split()
    if len(parts) != 2:
        return None, "format"

    date_raw, time_raw = parts

    date_str = _autocorrect_date(date_raw)
    if date_str is None:
        return None, "format"

    try:
        datetime.strptime(date_str, "%d.%m.%Y")
    except ValueError:
        return None, "date"

    try:
        datetime.strptime(time_raw, "%H:%M")
    except ValueError:
        return None, "time"

    return (date_str, time_raw, date_str != date_raw), None


def _error_msg(err: str) -> str:
    if err == "time":
        return (
            "❌ Вақт нотўғри.\n\n"
            "Вақт формати: <code>HH:MM</code>\n\n"
            "Масалан: <code>08:30</code>"
        )
    if err == "date":
        return (
            "❌ Сана нотўғри.\n\n"
            "Тўғри формат:\n\n"
            "<code>DD.MM.YYYY HH:MM</code>\n\n"
            f"Масалан: <code>{_EXAMPLE}</code>"
        )
    return (
        "❌ Сана формати нотўғри.\n\n"
        "Тўғри формат:\n\n"
        "<code>DD.MM.YYYY HH:MM</code>\n\n"
        f"Масалан: <code>{_EXAMPLE}</code>"
    )


def _fmt_deadline(date_str: str, time_str: str) -> str:
    return f"📅 {date_str}\n🕒 {time_str}"


# ── /setdeadline ───────────────────────────────────────────────────────────────

@router.message(Command("setdeadline"))
async def cmd_setdeadline(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    if get_deadline():
        display = deadline_display()
        date_str, time_str = display if display else ("—", "—")
        await message.answer(
            "⚠️ Дедлайн аллақачон белгиланган.\n\n"
            f"{_fmt_deadline(date_str, time_str)}\n\n"
            "Ўзгартириш учун /editdeadline командасидан фойдаланинг.",
        )
        return

    await state.set_state(SetDeadlineSG.waiting)
    await message.answer(
        "⏰ <b>Дедлайн белгилаш</b>\n\n"
        "Match Day учун дедлайн белгиланг.\n\n"
        "Дедлайнни киритинг:\n\n"
        f"Масалан:\n<code>{_EXAMPLE}</code>",
    )


@router.message(SetDeadlineSG.waiting)
async def msg_setdeadline_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()
    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    result, err = _parse_detailed(text)

    if err:
        await message.answer(_error_msg(err), parse_mode="HTML")
        return

    date_str, time_str, was_corrected = result
    set_deadline(date_str, time_str)
    await state.clear()

    correction_note = (
        f"\n\n✏️ Автоматик тузатиш: <code>{text.split()[0]}</code> → <code>{date_str}</code>"
        if was_corrected else ""
    )
    await message.answer(
        "✅ <b>Янги дедлайн сақланди</b>\n\n"
        f"{_fmt_deadline(date_str, time_str)}"
        f"{correction_note}\n\n"
        "⏰ Вақт зонаси:\n"
        "Москва вақти (MSK, UTC+3)",
        parse_mode="HTML",
    )

    _dm = (
        "⏳ <b>Match Day дедлайни белгиланди.</b>\n\n"
        f"📅 Дедлайн:\n{date_str}\n{time_str}\n\n"
        "⚽ Тахминларни киритиш мумкин:\n\n"
        "/predict"
    )
    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await message.bot.send_message(int(tid), _dm, parse_mode="HTML")
        except Exception:
            pass


# ── /editdeadline ──────────────────────────────────────────────────────────────

@router.message(Command("editdeadline"))
async def cmd_editdeadline(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    display = deadline_display()
    if not display:
        await message.answer(
            "⚠️ Ҳозирча дедлайн белгиланмаган.\n\n"
            "Аввал /setdeadline орқали дедлайн белгиланг.",
        )
        return

    date_str, time_str = display
    await state.set_state(EditDeadlineSG.waiting)
    await state.update_data(old_date=date_str, old_time=time_str)

    await message.answer(
        "⏰ <b>Дедлайнни ўзгартириш</b>\n\n"
        "Жорий дедлайн:\n\n"
        f"{_fmt_deadline(date_str, time_str)}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "Янги дедлайнни киритинг:\n\n"
        f"Масалан:\n<code>{_EXAMPLE}</code>",
    )


@router.message(EditDeadlineSG.waiting)
async def msg_editdeadline_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()
    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return

    result, err = _parse_detailed(text)

    if err:
        await message.answer(_error_msg(err), parse_mode="HTML")
        return

    new_date, new_time, was_corrected = result
    data = await state.get_data()
    old_date: str = data["old_date"]
    old_time: str = data["old_time"]

    set_deadline(new_date, new_time)
    await state.clear()

    correction_note = (
        f"\n\n✏️ Автоматик тузатиш: <code>{text.split()[0]}</code> → <code>{new_date}</code>"
        if was_corrected else ""
    )
    await message.answer(
        "✅ <b>Дедлайн янгиланди</b>\n\n"
        "Эски дедлайн:\n\n"
        f"{_fmt_deadline(old_date, old_time)}\n\n"
        "Янги дедлайн:\n\n"
        f"{_fmt_deadline(new_date, new_time)}"
        f"{correction_note}",
        parse_mode="HTML",
    )

    _dm = (
        "🔄 <b>Match Day дедлайни ўзгартирилди.</b>\n\n"
        f"📅 Янги дедлайн:\n{new_date}\n{new_time}"
    )
    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await message.bot.send_message(int(tid), _dm, parse_mode="HTML")
        except Exception:
            pass


# ── /deadline ──────────────────────────────────────────────────────────────────

@router.message(Command("deadline"))
async def cmd_deadline(message: Message) -> None:
    result = deadline_display()
    if not result:
        await message.answer("⏳ Муддат ҳали белгиланмаган.")
        return

    date_str, time_str = result
    await message.answer(
        "⏰ <b>Match Day муддати</b>\n\n"
        f"{_fmt_deadline(date_str, time_str)}\n\n"
        "Вақт зонаси: Москва вақти (MSK, UTC+3)",
    )


# ── /resetdeadline ─────────────────────────────────────────────────────────────

_RDL_CONFIRM = "resetdeadline:confirm"
_RDL_CANCEL  = "resetdeadline:cancel"


@router.message(Command("resetdeadline"))
async def cmd_resetdeadline(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    if not get_deadline():
        await message.answer("⚠️ Белгиланган муддат мавжуд эмас.")
        return

    await message.answer(
        "⚠️ <b>Муддатни ўчириш</b>\n\n"
        "Муддатни ўчиришни тасдиқлайсизми?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Ҳа",  callback_data=_RDL_CONFIRM),
            InlineKeyboardButton(text="❌ Йўқ", callback_data=_RDL_CANCEL),
        ]]),
    )


@router.callback_query(F.data == _RDL_CONFIRM)
async def cb_resetdeadline_confirm(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⚠️ Рухсат йўқ.", show_alert=True)
        return
    reset_deadline()
    await callback.message.edit_text("🗑 Муддат ўчирилди.")
    await callback.answer()


@router.callback_query(F.data == _RDL_CANCEL)
async def cb_resetdeadline_cancel(callback: CallbackQuery) -> None:
    await callback.message.edit_text("❌ Ўчириш бекор қилинди.")
    await callback.answer()
