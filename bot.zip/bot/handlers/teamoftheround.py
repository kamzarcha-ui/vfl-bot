"""
/teamoftheround — Тур Лауреатлари for the latest completed Match Day.

Data sources (all correct post-closematchday):
  - db.json["duel_results"][str(md)]  → match scores (Biggest Win, Top Scoring)
  - db.json["results"]["md{n}_m{k}"]  → processed prediction results
  - db.json["predictions"]            → per-coach predictions (Best Predictor)
  - coaches.json                      → coach name/team lookup
  - teams.json                        → player goals lookup
"""

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.db import (
    get_all_predictions_for_match,
    get_completed_match_days,
    get_duel_results,
    get_processed_result_ids,
    get_result,
)
from bot.data.stats_db import (
    get_coach_name_by_tid,
    get_coach_team_name_by_tid,
    score_prediction,
)
from bot.data.club_abbr import abbr

router = Router()

_SEP = "━" * 22


# ── Laureates broadcast (called by closematchday after MD closure) ─────────────

def build_laureates_broadcast(md: int) -> str:
    """
    Build the Match Day Laureates broadcast text.

    Sections:
      🎮 Энг яхши ўйин    — most total goals; tie-break: smallest GD
      ⚽ Энг яхши ўйинчи  — top player by MD goals
      🧠 Энг яхши мураббий — top coach: exact predictions → MD goals → lower tid
      ⭐ Рамзий жамоа     — top-3 players by MD goals
    Hall of Fame records are NOT included here (shown via button only).
    """
    from bot.data.db import get_duel_results

    _S = "━" * 22
    duels = get_duel_results(md)
    coach_exacts, coach_md_goals, player_goals = _compute_md_stats(md)

    lines: list[str] = [
        f"🏆 <b>MATCH DAY #{md} ЛАУРЕАТЛАРИ</b>",
        "",
        _S,
    ]

    # ── Энг яхши ўйин ─────────────────────────────────────────────────────────
    lines += ["", "🎮 <b>ЭНГ ЯХШИ ЎЙИН</b>", ""]
    if duels:
        best = max(
            duels,
            key=lambda d: (
                d["goals_home"] + d["goals_away"],
                -(abs(d["goals_home"] - d["goals_away"])),
            ),
        )
        total = best["goals_home"] + best["goals_away"]
        if total > 0:
            lines.append(
                f"⚔️ {best['home']} "
                f"{best['goals_home']}–{best['goals_away']} "
                f"{best['away']}"
            )
        else:
            lines.append("<i>Маълумот мавжуд эмас.</i>")
    else:
        lines.append("<i>Маълумот мавжуд эмас.</i>")

    # ── Энг яхши ўйинчи ───────────────────────────────────────────────────────
    lines += ["", _S, "", "⚽ <b>ЭНГ ЯХШИ ЎЙИНЧИ</b>", ""]
    if player_goals:
        ranked = sorted(player_goals.items(), key=lambda kv: (-kv[1], kv[0][0]))
        (top_player, top_club), top_pg = ranked[0]
        lines.append(f"👤 <b>{top_player}</b> ({abbr(top_club)})")
        lines.append(f"⚽ {top_pg} гол")
    else:
        lines.append("<i>Маълумот мавжуд эмас.</i>")

    # ── Энг яхши мураббий ─────────────────────────────────────────────────────
    lines += ["", _S, "", "🧠 <b>ЭНГ ЯХШИ МУРАББИЙ</b>", ""]
    if coach_exacts:
        best_tid = max(
            coach_exacts,
            key=lambda t: (coach_exacts[t], coach_md_goals.get(t, 0), -int(t)),
        )
        try:
            tid_int = int(best_tid)
            coach_name = get_coach_name_by_tid(tid_int) or f"ID:{best_tid}"
            coach_team = get_coach_team_name_by_tid(tid_int) or "—"
        except ValueError:
            coach_name, coach_team = f"ID:{best_tid}", "—"

        lines.append(f"👤 <b>{coach_name}</b> ({abbr(coach_team)})")
        lines.append("")
        lines.append(f"🎯 {coach_exacts[best_tid]} та аниқ ҳисоб")
        lines.append(f"⚽ {coach_md_goals.get(best_tid, 0)} гол")
    else:
        lines.append("<i>Бу турда аниқ тахминлар йўқ.</i>")

    # ── Рамзий жамоа ──────────────────────────────────────────────────────────
    lines += ["", _S, "", "⭐ <b>РАМЗИЙ ЖАМОА</b>", ""]
    if player_goals:
        ranked = sorted(player_goals.items(), key=lambda kv: (-kv[1], kv[0][0]))
        for (pl_name, pl_team), _ in ranked[:3]:
            lines.append(f"⚽ <b>{pl_name}</b> ({abbr(pl_team)})")
    else:
        lines.append("<i>Маълумот мавжуд эмас.</i>")

    lines += [
        "",
        _S,
        "",
        "🏛 Hall of Fame янгиланди.",
        "Тўлиқ рекордлар Hall of Fame бўлимида сақланди.",
    ]

    return "\n".join(lines)


# ── helpers ───────────────────────────────────────────────────────────────────

def _biggest_win(duels: list[dict]) -> str | None:
    """Return formatted string for the match with the largest goal difference."""
    if not duels:
        return None
    best = max(duels, key=lambda d: abs(d["goals_home"] - d["goals_away"]))
    diff = abs(best["goals_home"] - best["goals_away"])
    if diff == 0:
        return None
    return f"{best['home']} {best['goals_home']}–{best['goals_away']} {best['away']}"


def _highest_scoring(duels: list[dict]) -> str | None:
    """Return formatted string for the match with the most total goals."""
    if not duels:
        return None
    best = max(duels, key=lambda d: d["goals_home"] + d["goals_away"])
    total = best["goals_home"] + best["goals_away"]
    if total == 0:
        return None
    return f"{best['home']} {best['goals_home']}–{best['goals_away']} {best['away']}"


def _compute_md_stats(md: int) -> tuple[
    dict[str, int],              # coach_exacts  {tid_str: exact_count}
    dict[str, int],              # coach_md_goals {tid_str: goals_this_md}
    dict[tuple[str, str], int],  # player_goals  {(player, team): goals}
]:
    """
    Walk every processed result for match day `md` and derive per-MD stats.

    perf_score formula (from score_prediction):
      3 = exact scoreline
      3 = correct goal difference (different score, same GD)
      1 = correct result only (right outcome, wrong GD)
      0 = wrong
    coach_md_goals:
      2 = exact scoreline
      1 = correct goal difference
      0 = otherwise
    """
    result_ids = get_processed_result_ids(md)

    coach_exacts: dict[str, int] = {}
    coach_md_goals: dict[str, int] = {}
    player_goals: dict[tuple[str, str], int] = {}

    for fid in result_ids:
        result = get_result(fid)
        if not result:
            continue
        real_score = result["score"]
        preds = get_all_predictions_for_match(fid)

        for tid_str, pred in preds.items():
            predicted = pred.get("score", "")
            player_name = pred.get("player", "")
            if not predicted:
                continue

            try:
                tid_int = int(tid_str)
            except ValueError:
                continue

            _, is_exact, _, goals = score_prediction(predicted, real_score)
            team_name = get_coach_team_name_by_tid(tid_int)

            if is_exact:
                coach_exacts[tid_str] = coach_exacts.get(tid_str, 0) + 1

            coach_md_goals[tid_str] = coach_md_goals.get(tid_str, 0) + goals

            if goals > 0 and player_name and team_name:
                key = (player_name, team_name)
                player_goals[key] = player_goals.get(key, 0) + goals

    return coach_exacts, coach_md_goals, player_goals


# ── command ───────────────────────────────────────────────────────────────────

@router.message(Command("teamoftheround"))
async def cmd_teamoftheround(message: Message, *, user_id: int | None = None) -> None:
    completed = get_completed_match_days()

    if not completed:
        await message.answer(
            "🏅 <b>Тур Лауреатлари</b>\n\n"
            f"{_SEP}\n\n"
            "<i>Ҳали якунланган турлар йўқ.</i>",
            parse_mode="HTML",
        )
        return

    md = completed[-1]  # latest completed match day
    duels = get_duel_results(md)
    coach_exacts, coach_md_goals, player_goals = _compute_md_stats(md)

    lines: list[str] = [f"🏅 <b>Тур Лауреатлари — {md}-тур</b>\n"]
    lines.append(_SEP)

    # ── Тур Мураббийи (Best Coach of the MD) ─────────────────────────────────
    # Ranked by: exact predictions DESC → MD goals DESC → tid ASC (tie-break)
    lines.append("")
    lines.append("🏆 <b>Тур Мураббийи</b>\n")
    if coach_exacts:
        best_tid = max(
            coach_exacts,
            key=lambda t: (coach_exacts[t], coach_md_goals.get(t, 0), -int(t)),
        )
        try:
            tid_int = int(best_tid)
            coach_name = get_coach_name_by_tid(tid_int) or f"ID:{best_tid}"
            coach_team = get_coach_team_name_by_tid(tid_int) or "—"
        except ValueError:
            coach_name, coach_team = f"ID:{best_tid}", "—"

        exact_count = coach_exacts[best_tid]
        md_goals    = coach_md_goals.get(best_tid, 0)
        team_abbr   = abbr(coach_team)

        lines.append(f"🎯 <b>{coach_name}</b> ({team_abbr})\n")
        lines.append(f"{exact_count} та аниқ ҳисоб")
        lines.append(f"{md_goals} гол")
    else:
        lines.append("<i>Бу турда аниқ тахминлар йўқ.</i>")

    # ── Тур Қаҳрамони (Player of the Round) ──────────────────────────────────
    lines.append("")
    lines.append("🌟 <b>Тур Қаҳрамони</b>\n")
    if player_goals:
        ranked = sorted(player_goals.items(), key=lambda kv: (-kv[1], kv[0][0]))
        (top_player, top_club), top_goals = ranked[0]
        lines.append(f"⚽ <b>{top_player}</b> ({abbr(top_club)}) — {top_goals} гол")
    else:
        lines.append("<i>Бу турда ўйинчи маълумоти йўқ.</i>")

    # ── Энг Катта Ғалаба (Biggest Win) ───────────────────────────────────────
    lines.append("")
    lines.append("💪 <b>Энг Катта Ғалаба</b>\n")
    bw = _biggest_win(duels)
    lines.append(f"⚔️ {bw}" if bw else "<i>Маълумот мавжуд эмас.</i>")

    # ── Энг Кўп Голли Ўйин (Highest Scoring Match) ───────────────────────────
    lines.append("")
    lines.append("🔥 <b>Энг Кўп Голли Ўйин</b>\n")
    hs = _highest_scoring(duels)
    lines.append(f"⚽ {hs}" if hs else "<i>Маълумот мавжуд эмас.</i>")

    lines.append("")
    lines.append(_SEP)

    await message.answer("\n".join(lines), parse_mode="HTML")
