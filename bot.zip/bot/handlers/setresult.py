import os
import re
from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

from bot.data.db import (
    get_fixtures,
    get_all_predictions_for_match,
    get_result,
    get_matchups_for_round,
    is_matchup_club_scored,
    mark_matchup_club_scored,
    save_result,
    mark_result_processed,
    update_club_pts,
)
from bot.data.stats_db import (
    compute_matchup_club_pts,
    get_coach_name_by_tid,
    get_coach_team_name_by_tid,
    score_prediction,
    update_coach_stats,
    update_player_goals,
)

router = Router()
SCORE_RE = re.compile(r"^\d{1,2}-\d{1,2}$")


def _admin_id() -> str | None:
    return os.environ.get("ADMIN_ID", "").strip() or None




class SetResultForm(StatesGroup):
    waiting_for_score = State()


# ── /setresult ────────────────────────────────────────────────────────────────

@router.message(Command("setresult"))
async def cmd_setresult(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ This command is for admins only.")
        return

    all_fixtures = get_fixtures()
    if not all_fixtures:
        await message.answer("⚠️ No fixtures found in the database.")
        return

    current_round = max(f["round"] for f in all_fixtures)
    round_fixtures = [f for f in all_fixtures if f["round"] == current_round]

    pending = [
        f for f in round_fixtures
        if not (get_result(f["id"]) or {}).get("processed", False)
    ]

    if not pending:
        await message.answer(
            f"✅ All results for Round {current_round} have already been entered."
        )
        return

    await state.set_data({
        "pending": pending,
        "round": current_round,
        "index": 0,
        "summary": [],
    })
    await state.set_state(SetResultForm.waiting_for_score)
    await _ask_result(message, pending, 0)


async def _ask_result(message: Message, pending: list, idx: int) -> None:
    fixture = pending[idx]
    existing = get_result(fixture["id"])
    prev_text = ""
    if existing and existing.get("score"):
        prev_text = (
            f"\nPrevious result: <code>{existing['score']}</code> (will be overwritten)"
        )
    await message.answer(
        f"🏟️ <b>Result {idx + 1} of {len(pending)}</b>\n"
        f"{fixture['home']} 🆚 {fixture['away']}\n"
        f"🕐 {fixture['date']}{prev_text}\n\n"
        "Enter the final score (e.g. <code>2-1</code>):\n"
        "<i>Send /cancel to stop.</i>",
        parse_mode="HTML",
    )


@router.message(SetResultForm.waiting_for_score)
async def process_result_score(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()

    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer("❌ Result entry cancelled. Run /setresult again to continue.")
        return

    if not SCORE_RE.match(text):
        await message.answer(
            "⚠️ Invalid format. Enter a score like <code>2-1</code> or <code>0-0</code>.",
            parse_mode="HTML",
        )
        return

    data = await state.get_data()
    pending: list = data["pending"]
    idx: int = data["index"]
    round_no: int = data["round"]
    summary: list = data["summary"]

    fixture = pending[idx]
    match_id = fixture["id"]
    real_score = text

    save_result(match_id, real_score)

    # ── score individual predictions ──────────────────────────────────────────
    predictions = get_all_predictions_for_match(match_id)
    match_lines: list[str] = []

    for tid_str, pred in predictions.items():
        predicted_score = pred.get("score", "")
        player_name = pred.get("player", "")
        if not predicted_score:
            continue
        try:
            tid_int = int(tid_str)
        except ValueError:
            continue

        perf_score, is_exact, is_correct_gd, player_goals = score_prediction(
            predicted_score, real_score
        )

        # Coach: exact predictions only
        update_coach_stats(tid_int, is_exact)

        # Player goals: 2 exact / 1 correct GD / 0 other
        if player_goals > 0 and player_name:
            team_name = get_coach_team_name_by_tid(tid_int)
            if team_name:
                update_player_goals(team_name, player_name, player_goals)

        coach_name = get_coach_name_by_tid(tid_int) or f"ID:{tid_str}"

        if is_exact:
            icon, outcome_label = "🎯", "Exact!"
        elif is_correct_gd:
            icon, outcome_label = "🟡", "Correct GD"
        elif perf_score == 1:
            icon, outcome_label = "✅", "Correct result"
        else:
            icon, outcome_label = "❌", "Wrong"

        goal_note = f"  ⚽ +{player_goals} goal{'s' if player_goals != 1 else ''} → {player_name}" if player_goals > 0 and player_name else ""
        match_lines.append(
            f"  {icon} {coach_name}: <code>{predicted_score}</code> — {outcome_label}{goal_note}"
        )

    mark_result_processed(match_id)

    no_pred_note = "" if predictions else "\n  <i>No predictions for this match.</i>"
    summary_entry = (
        f"<b>{fixture['home']} {real_score} {fixture['away']}</b>\n"
        + ("\n".join(match_lines) if match_lines else no_pred_note)
    )
    summary.append(summary_entry)

    next_idx = idx + 1
    await state.update_data(index=next_idx, summary=summary)

    await message.answer(
        f"✅ Result saved: <b>{fixture['home']} {real_score} {fixture['away']}</b>\n\n"
        + ("\n".join(match_lines) if match_lines else "<i>No predictions for this match.</i>"),
        parse_mode="HTML",
    )

    if next_idx < len(pending):
        await _ask_result(message, pending, next_idx)
        return

    # ── all pending fixtures done — calculate club points ─────────────────────
    await state.clear()

    full_summary = [f"🏆 <b>Round {round_no} — All Results Entered!</b>\n"]
    for i, entry in enumerate(summary, 1):
        full_summary.append(f"<b>Match {i}</b>\n{entry}\n")
    await message.answer("\n".join(full_summary), parse_mode="HTML")

    club_lines = await _process_club_points(round_no)
    if club_lines:
        await message.answer(
            f"🏟️ <b>Round {round_no} — Club Standings Update</b>\n\n"
            + "\n".join(club_lines),
            parse_mode="HTML",
        )


async def _process_club_points(round_no: int) -> list[str]:
    """
    For each matchup in round_no where all fixtures are processed and club
    points haven't been awarded yet, compute the winner and update club_stats.
    Returns summary lines to send to the admin.
    """
    matchups = get_matchups_for_round(round_no)
    lines: list[str] = []

    for matchup in matchups:
        coach_a = matchup.get("coach_a", "")
        coach_b = matchup.get("coach_b", "")
        fixture_ids: list[str] = matchup.get("fixture_ids", [])

        if not coach_a or not coach_b or not fixture_ids:
            continue

        # Skip if already scored
        if is_matchup_club_scored(round_no, coach_a, coach_b):
            continue

        # Check all fixtures in this matchup are processed
        all_done = all(
            (get_result(fid) or {}).get("processed", False)
            for fid in fixture_ids
        )
        if not all_done:
            continue

        score_a, score_b, pts_a, pts_b = compute_matchup_club_pts(
            fixture_ids, coach_a, coach_b
        )

        team_a = get_coach_team_name_by_tid(int(coach_a)) if coach_a.isdigit() else coach_a
        team_b = get_coach_team_name_by_tid(int(coach_b)) if coach_b.isdigit() else coach_b
        coach_name_a = get_coach_name_by_tid(int(coach_a)) if coach_a.isdigit() else coach_a
        coach_name_b = get_coach_name_by_tid(int(coach_b)) if coach_b.isdigit() else coach_b

        if team_a:
            update_club_pts(team_a, pts_a)
        if team_b:
            update_club_pts(team_b, pts_b)

        mark_matchup_club_scored(round_no, coach_a, coach_b)

        def result_icon(pts: int) -> str:
            return "🏆" if pts == 3 else ("🤝" if pts == 1 else "❌")

        lines.append(
            f"{result_icon(pts_a)} <b>{team_a or coach_a}</b> ({coach_name_a or '?'}) "
            f"<code>{score_a}</code>  vs  "
            f"<code>{score_b}</code> "
            f"<b>{team_b or coach_b}</b> ({coach_name_b or '?'}) {result_icon(pts_b)}\n"
            f"  Club pts awarded: <b>{team_a or '?'} +{pts_a}</b> | "
            f"<b>{team_b or '?'} +{pts_b}</b>"
        )

    return lines
