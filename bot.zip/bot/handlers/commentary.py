from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()

_SHOW = 5   # number of previews shown per /commentary call


@router.message(Command("commentary"))
async def cmd_commentary(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.commentary_db import load_commentary

    items = load_commentary()   # newest first

    if not items:
        await message.answer(
            "🎙 <b>VFL Шарҳловчи</b>\n\n"
            "Ҳозирча превью мавжуд эмас.\n\n"
            "Янги Match Day яратилганда автоматик равишда "
            "превью мақола яратилади ва бу ерда кўрсатилади.",
            parse_mode="HTML",
        )
        return

    # Show the latest preview in full, then titles of older ones
    latest = items[0]
    await message.answer(latest["text"], parse_mode="HTML")

    if len(items) > 1:
        older = items[1:_SHOW]
        lines = ["\n📂 <b>Олдинги превьюлар:</b>\n"]
        for it in older:
            lines.append(
                f"📌 <b>{it.get('title', '—')}</b>"
                f"  <i>({it.get('date', '')})</i>"
            )
        lines.append(
            "\n<i>Барча превьюлар /vfltv орқали мавжуд.</i>"
        )
        await message.answer("\n".join(lines), parse_mode="HTML")
