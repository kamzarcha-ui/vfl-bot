from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("champions"))
async def cmd_champions(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.season_db import load_champions

    champions = sorted(load_champions(), key=lambda x: x.get("season", 0))

    if not champions:
        await message.answer(
            "👑 <b>Чемпионлар</b>\n\n"
            "Ҳозирча чемпионлар мавжуд эмас.\n\n"
            "Биринчи чемпион аниқлангач бу ерда сақланади.",
            parse_mode="HTML",
        )
        return

    lines = ["👑 <b>VFL ЧЕМПИОНЛАР</b>\n"]
    medals = {1: "🥇", 2: "🥈", 3: "🥉"}

    for c in champions:
        season   = c.get("season", "?")
        champion = c.get("champion") or "—"
        runner_up = c.get("runner_up") or ""
        ru_part  = f"  <i>(финалист: {runner_up})</i>" if runner_up else ""
        lines.append(f"🏆 Мавсум {season} — <b>{champion}</b>{ru_part}")

    await message.answer("\n".join(lines), parse_mode="HTML")
