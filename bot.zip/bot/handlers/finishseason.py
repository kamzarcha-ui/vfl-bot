"""
/finishseason — Admin-only season close command.

Validates the Final is complete, archives all season data,
updates Hall of Fame, updates rankings, resets season-specific data,
and starts the next season automatically.
"""

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

router = Router()





@router.message(Command("finishseason"))
async def cmd_finishseason(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Сизда админ ҳуқуқи мавжуд эмас.")
        return

    from bot.data.league_stage_db import get_stage_winners
    from bot.data.season_db import get_current_season, archive_season, reset_season_data
    from bot.data.hall_of_fame_db import check_and_update_records
    from bot.data.season_records_db import archive_season_records

    # Validate: final must be completed
    final_winners = get_stage_winners("final")
    if not final_winners:
        await message.answer(
            "⛔ <b>Финал ҳали якунланмаган.</b>\n\n"
            "/finishseason фақат финал якунлангандан сўнг ишлайди.",
            parse_mode="HTML",
        )
        return

    season = get_current_season()
    await message.answer(
        f"⏳ <b>Мавсум {season} якунланяпти…</b>",
        parse_mode="HTML",
    )

    # 1. Archive season (history, champions, awards, rankings)
    entry = archive_season(season)

    # 2. Final Hall of Fame check
    await check_and_update_records(
        season=season,
        bot=message.bot,
        match_day=17,
        completed_stage="final",
    )

    # 3. Archive season records snapshot before clearing data
    archive_season_records(season)

    # 4. Reset season data (also increments season counter)
    reset_season_data()
    new_season = get_current_season()

    # 5. Confirmation summary
    champion  = entry.get("champion") or "—"
    runner_up = entry.get("runner_up") or "—"
    gb        = entry.get("top_scorer")
    gp        = entry.get("golden_predictor")
    gb_text   = f"{gb['name']} ({gb.get('goals', 0)} гол)" if gb else "—"
    gp_text   = f"{gp['name']} ({gp.get('exact', 0)} аниқ)" if gp else "—"

    sf_names = ", ".join(entry.get("sf_all", [])[:4]) or "—"

    await message.answer(
        f"✅ <b>Мавсум {season} муваффақиятли якунланди!</b>\n\n"
        f"👑 Чемпион: <b>{champion}</b>\n"
        f"🥈 Финалист: <b>{runner_up}</b>\n"
        f"🥉 Ярим финалчилар: {sf_names}\n\n"
        f"⚽ Golden Boot: <b>{gb_text}</b>\n"
        f"🎯 Golden Predictor: <b>{gp_text}</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📦 Сақланди: /history · /champions · /awards\n"
        f"📊 Рейтинг янгиланди: /clubranking · /coachranking\n"
        f"🏛 Hall of Fame янгиланди: /halloffame\n"
        f"♻️ Мавсум маълумотлари тозаланди\n\n"
        f"🆕 <b>Мавсум {new_season} бошланди!</b>",
        parse_mode="HTML",
    )
