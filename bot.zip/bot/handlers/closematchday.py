from bot.data.admin_ids import is_admin as _is_admin
"""
/closematchday — Finalise Match Day and run all calculations (admin only).

Must be run after /setmdresult (and optionally /editmdresult).
Shows a confirmation prompt, then executes:
  ✅ Score all predictions
  ✅ Update player goal stats
  ✅ Update Coach Rating
  ✅ Compute duel results
  ✅ Award league (club) points
  ✅ Mark Match Day as CLOSED (blocks further edits)
  ✅ MD8: auto-classify teams into zones
  ✅ Playoff MDs: save leg results, compute winners after leg 2, build next bracket
"""

import os

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.db import (
    get_all_predictions_for_match,
    get_playoff_results,
    get_result,
    mark_result_processed,
    save_duel_results,
    save_playoff_results,
    update_club_pts,
)
from bot.data.draw_db import get_round_fixtures
from bot.data.league_stage_db import (
    build_standings_from_club_stats,
    build_next_stage_bracket,
    compute_two_leg_winners,
    get_playoff_bracket,
    get_stage_bracket,
    save_classification,
    save_leg_result,
    save_stage_bracket,
    save_stage_winners,
)
from bot.data.matchday_db import advance_matchday, get_matchday, is_matchday_closed, set_matchday_closed
from bot.data.stats_db import (
    get_coach_name_by_tid,
    get_coach_team_name_by_tid,
    score_prediction,
    update_coach_matchday_goals,
    update_coach_stats,
    update_player_goals,
)
from bot.data.hall_of_fame_db import check_and_update_records
from bot.data.news_db import generate_and_store_news
from bot.data.sensations_db import detect_and_store_sensations
from bot.data.teams_db import load_teams

router = Router()

TOTAL_MATCHES = 5
_CB_YES       = "cmd:close_yes"
_CB_NO        = "cmd:close_no"

# Match days 9-17 are playoff stages (stage, leg)
PLAYOFF_STAGE_MAP: dict[int, tuple[str, int]] = {
    9:  ("playoff", 1),
    10: ("playoff", 2),
    11: ("r16",     1),
    12: ("r16",     2),
    13: ("qf",      1),
    14: ("qf",      2),
    15: ("sf",      1),
    16: ("sf",      2),
    17: ("final",   1),
}

# After each second leg, the next stage to build
_NEXT_STAGE: dict[str, str] = {
    "playoff": "r16",
    "r16":     "qf",
    "qf":      "sf",
    "sf":      "final",
}

_STAGE_LABELS: dict[str, str] = {
    "playoff": "🔥 Плей-офф",
    "r16":     "🏆 1/8 финал",
    "qf":      "🏆 1/4 финал",
    "sf":      "🏆 1/2 финал",
    "final":   "👑 Финал",
}


def _get_playoff_pairings(stage: str, leg: int) -> list[dict]:
    """
    Return home/away pairings for a playoff stage and leg.
    Leg 1: as stored in bracket.
    Leg 2: home/away swapped (second leg reversal).
    """
    if stage == "playoff":
        bracket = get_playoff_bracket()
        if not bracket:
            return []
        pairs = [{"home": p["team1"], "away": p["team2"]} for p in bracket]
    else:
        pairs = get_stage_bracket(stage)
        if not pairs:
            return []

    if leg == 2:
        pairs = [{"home": p["away"], "away": p["home"]} for p in pairs]

    return pairs




def _fixture_id(match_day: int, idx: int) -> str:
    return f"md{match_day}_m{idx + 1}"


def _compute_duel_pts(score_a: int, score_b: int) -> tuple[int, int]:
    if score_a > score_b:
        return 3, 0
    elif score_a < score_b:
        return 0, 3
    return 1, 1


def _confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Ҳа, якунлаш", callback_data=_CB_YES),
        InlineKeyboardButton(text="❌ Йўқ",          callback_data=_CB_NO),
    ]])


# ── /closematchday ────────────────────────────────────────────────────────────

@router.message(Command("closematchday"))
async def cmd_closematchday(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        await message.answer("⛔ Бу буйруқ фақат администратор учун.")
        return

    if is_matchday_closed():
        await message.answer("⚠️ Match Day аллақачон якунланган.")
        return

    md = get_matchday()
    if not md or not md.get("fixtures"):
        await message.answer(
            "⚠️ Ҳозирча Match Day натижалари киритилмаган.\n\n"
            "Аввал /setmdresult орқали натижаларни киритинг."
        )
        return

    match_day = md["match_day"]

    if get_result(_fixture_id(match_day, 0)) is None:
        await message.answer(
            "⚠️ Ҳозирча Match Day натижалари киритилмаган.\n\n"
            "Аввал /setmdresult орқали натижаларни киритинг."
        )
        return

    missing = [
        i + 1 for i in range(TOTAL_MATCHES)
        if get_result(_fixture_id(match_day, i)) is None
    ]
    if missing:
        await message.answer(
            "⚠️ Барча Match Day натижалари киритилмаган.\n\n"
            "Аввал барча ўйинлар натижаларини киритинг."
        )
        return

    await message.answer(
        "🏁 <b>Match Day'ни якунлаш</b>\n\n"
        "Барча натижалар текширилганми?\n"
        "Ҳисоблаш бошланади.",
        reply_markup=_confirm_kb(),
    )


# ── Confirmation callbacks ─────────────────────────────────────────────────────

@router.callback_query(F.data == _CB_NO)
async def cb_close_no(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text("❌ Якунлаш бекор қилинди.")
    await callback.answer()


@router.callback_query(F.data == _CB_YES)
async def cb_close_yes(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    if is_matchday_closed():
        await callback.message.edit_text("⚠️ Match Day аллақачон якунланган.")
        await callback.answer()
        return

    md = get_matchday()
    if not md:
        await callback.message.edit_text("⚠️ Match Day мавжуд эмас.")
        await callback.answer()
        return

    match_day = md["match_day"]
    fixtures  = md["fixtures"]

    # Capture standings BEFORE this MD's duels are applied
    _standings_before = build_standings_from_club_stats()

    await callback.message.edit_text("⏳ Ҳисоблаш бошланди...")
    await callback.answer()

    # ── Score all predictions ─────────────────────────────────────────────────
    coach_goals: dict[str, int] = {}

    for idx in range(TOTAL_MATCHES):
        match_id = _fixture_id(match_day, idx)
        result   = get_result(match_id)
        if not result:
            continue

        real_score  = result["score"]
        predictions = get_all_predictions_for_match(match_id)

        for tid_str, pred in predictions.items():
            predicted   = pred.get("score", "")
            player_name = pred.get("player", "")
            if not predicted:
                continue
            try:
                tid_int = int(tid_str)
            except ValueError:
                continue

            _, is_exact, is_correct_gd, goals = score_prediction(predicted, real_score)

            update_coach_stats(tid_int, is_exact)
            update_coach_matchday_goals(tid_int, goals)
            coach_goals[tid_str] = coach_goals.get(tid_str, 0) + goals

            if goals > 0 and player_name:
                team_name = get_coach_team_name_by_tid(tid_int)
                if team_name:
                    update_player_goals(team_name, player_name, goals)

        mark_result_processed(match_id)

    # ── Duel processing ───────────────────────────────────────────────────────
    duel_lines, advancement_text = _process_duels(match_day, coach_goals)

    # ── MD8: auto-classify teams ──────────────────────────────────────────────
    if match_day == 8:
        standings = build_standings_from_club_stats()
        save_classification(standings)

    # ── Lock Match Day then advance ───────────────────────────────────────────
    set_matchday_closed()
    next_md = advance_matchday()

    # ── Final message ─────────────────────────────────────────────────────────
    extra = ""
    if match_day == 8:
        extra = "\n📋 Жамоалар таснифланди → /playoffteams"
    elif advancement_text:
        extra = f"\n\n{advancement_text}"

    await callback.message.answer(
        f"✅ <b>Match Day якунланди</b>\n\n"
        "⚽ Голлар ҳисобланди\n"
        "🎯 Coach Rating янгиланди\n"
        "🏟 Тур натижалари ҳисобланди\n"
        "📊 Лига очколари янгиланди"
        f"{extra}\n\n"
        f"▶️ Навбатдаги: <b>Match Day #{next_md}</b>\n"
        "Давом эттириш учун /setfixtures",
        parse_mode="HTML",
    )

    if duel_lines:
        results_text = f"📊 <b>{match_day}-ТУР НАТИЖАЛАРИ</b>\n\n" + "\n".join(duel_lines)

        for info in load_teams().values():
            tid = info.get("telegram_id")
            if not tid:
                continue
            try:
                await callback.message.bot.send_message(
                    int(tid), results_text, parse_mode="HTML"
                )
            except Exception:
                pass

    # Broadcast MD8 classification notification
    if match_day == 8:
        await _broadcast_md8_classification(callback.message.bot)

    # Broadcast stage-completed notification for playoff stages
    playoff_info = PLAYOFF_STAGE_MAP.get(match_day)
    if playoff_info:
        stage, leg = playoff_info
        if leg == 2 or stage == "final":
            await _broadcast_stage_completed(callback.message.bot, stage, match_day)

    # Hall of Fame: check and update records after every MD closure
    # Records and history are saved; broadcast is suppressed (shown via button only).
    _hof_stage = None
    _playoff = PLAYOFF_STAGE_MAP.get(match_day)
    if _playoff:
        _stage, _leg = _playoff
        if _leg == 2 or _stage == "final":
            _hof_stage = _stage
    await check_and_update_records(
        season=1,
        bot=callback.message.bot,
        match_day=match_day,
        completed_stage=_hof_stage,
    )

    # Broadcast MD Laureates (replaces HOF auto-broadcast)
    from bot.handlers.teamoftheround import build_laureates_broadcast
    _laureates_text = build_laureates_broadcast(match_day)
    _group_id = os.environ.get("GROUP_ID", "").strip()
    if _laureates_text:
        if _group_id:
            try:
                await callback.message.bot.send_message(
                    int(_group_id), _laureates_text, parse_mode="HTML"
                )
            except Exception:
                pass
        await _broadcast(callback.message.bot, _laureates_text)

    # Generate news and detect sensations from this MD's results
    generate_and_store_news(match_day, _standings_before, _hof_stage)
    detect_and_store_sensations(match_day, _standings_before, _hof_stage)

    # Generate and broadcast Match Day Review (runs last, after all calculations)
    from bot.data.preview_engine import generate_review
    from bot.data.commentary_db import store_commentary
    from bot.data.season_db import get_current_season

    _rev_season   = get_current_season()
    _rev_group_id = os.environ.get("GROUP_ID", "").strip()
    try:
        _review_text, _review_item = generate_review(
            match_day, _standings_before, _hof_stage, _rev_season
        )
        store_commentary(_review_item)
    except Exception:
        _review_text = None

    if _review_text:
        if _rev_group_id:
            try:
                await callback.message.bot.send_message(
                    int(_rev_group_id), _review_text, parse_mode="HTML"
                )
            except Exception:
                pass
        await _broadcast(callback.message.bot, _review_text)

    # ── Playoff Experience events ──────────────────────────────────────────────
    _pe_info = PLAYOFF_STAGE_MAP.get(match_day)
    if _pe_info:
        from bot.data.playoff_engine import (
            generate_leg_review,
            generate_qualification_drama,
            generate_final_countdown,
            generate_champion_ceremony,
        )
        from bot.data.news_db import prepend_news_items

        _pe_stage, _pe_leg = _pe_info

        if _pe_leg == 2:
            # Stage 3: Two-leg stage review
            try:
                _lr_text, _lr_item = generate_leg_review(match_day, _pe_stage, _rev_season)
                if _lr_text:
                    store_commentary(_lr_item)
                    if _rev_group_id:
                        try:
                            await callback.message.bot.send_message(
                                int(_rev_group_id), _lr_text, parse_mode="HTML"
                            )
                        except Exception:
                            pass
                    await _broadcast(callback.message.bot, _lr_text)
            except Exception:
                pass

            # Stage 4: Qualification drama (winners/eliminated announcement)
            try:
                _qd_text, _qd_news, _qd_comm = generate_qualification_drama(_pe_stage)
                if _qd_text:
                    prepend_news_items([_qd_news])
                    store_commentary(_qd_comm)
            except Exception:
                pass

            # Stage 5: Final Countdown (only after SF second leg)
            if _pe_stage == "sf":
                try:
                    _fc_text, _fc_news, _fc_comm = generate_final_countdown(_rev_season)
                    if _fc_text:
                        prepend_news_items([_fc_news])
                        store_commentary(_fc_comm)
                        if _rev_group_id:
                            try:
                                await callback.message.bot.send_message(
                                    int(_rev_group_id), _fc_text, parse_mode="HTML"
                                )
                            except Exception:
                                pass
                        await _broadcast(callback.message.bot, _fc_text)
                except Exception:
                    pass

        elif _pe_stage == "final":
            # Stage 6: Champion Ceremony (final is single leg in this system)
            try:
                _cc_text, _cc_news, _cc_comm = generate_champion_ceremony(_rev_season)
                if _cc_text:
                    prepend_news_items([_cc_news])
                    store_commentary(_cc_comm)
                    if _rev_group_id:
                        try:
                            await callback.message.bot.send_message(
                                int(_rev_group_id), _cc_text, parse_mode="HTML"
                            )
                        except Exception:
                            pass
                    await _broadcast(callback.message.bot, _cc_text)
            except Exception:
                pass


# ── Duel logic ────────────────────────────────────────────────────────────────

def _process_duels(
    match_day: int,
    coach_goals: dict[str, int],
) -> tuple[list[str], str]:
    """
    Returns (duel_display_lines, advancement_summary_text).
    """
    playoff_info = PLAYOFF_STAGE_MAP.get(match_day)

    if match_day <= 8:
        round_fixtures = get_round_fixtures(match_day)
        if not round_fixtures:
            return [], ""
    else:
        if not playoff_info:
            return [], ""
        stage, leg = playoff_info
        round_fixtures = _get_playoff_pairings(stage, leg)
        if not round_fixtures:
            return [], ""

    teams = load_teams()
    team_to_tid: dict[str, str] = {
        team: str(info.get("telegram_id", ""))
        for team, info in teams.items()
        if info.get("telegram_id")
    }

    duel_lines: list[str] = []
    duel_records: list[dict] = []

    for fx in round_fixtures:
        home_team = fx["home"]
        away_team = fx["away"]
        home_tid  = team_to_tid.get(home_team, "")
        away_tid  = team_to_tid.get(away_team, "")

        goals_home = coach_goals.get(home_tid, 0) if home_tid else 0
        goals_away = coach_goals.get(away_tid, 0) if away_tid else 0

        pts_home, pts_away = _compute_duel_pts(goals_home, goals_away)

        update_club_pts(home_team, pts_home, gf=goals_home, ga=goals_away)
        update_club_pts(away_team, pts_away, gf=goals_away, ga=goals_home)

        result_icon = "🤝" if pts_home == pts_away else "🏆"
        duel_lines.append(
            f"{result_icon} <b>{home_team}</b> {goals_home}–{goals_away} <b>{away_team}</b>"
        )
        duel_records.append({
            "home":       home_team,
            "away":       away_team,
            "goals_home": goals_home,
            "goals_away": goals_away,
        })

    save_duel_results(match_day, duel_records)

    advancement_text = ""

    if playoff_info:
        stage, leg = playoff_info

        # Save leg result for two-leg tracking
        save_leg_result(stage, leg, duel_records)

        # Save to playoff_results for /tourresults compatibility
        # Leg 2 result overwrites leg 1 (tournament result = last leg + context)
        save_playoff_results(stage, duel_records)

        if leg == 2:
            # Compute aggregate winners (returns list[dict] with reason per pair)
            winner_details = compute_two_leg_winners(stage)
            winners = [d["winner"] for d in winner_details]
            save_stage_winners(stage, winners)

            next_stage = _NEXT_STAGE.get(stage)
            if next_stage and winners:
                next_bracket = build_next_stage_bracket(stage, winners)
                save_stage_bracket(next_stage, next_bracket)
                next_label = _STAGE_LABELS.get(next_stage, next_stage)
                winners_str = _format_winner_lines(winner_details)
                advancement_text = (
                    f"🏆 <b>{_STAGE_LABELS.get(stage, stage)} якунланди!</b>\n\n"
                    f"<b>Кейинги босқичга ўтганлар:</b>\n{winners_str}\n\n"
                    f"▶️ {next_label} учрашувлари аниқланди → /playofftable"
                )

        elif stage == "final" and leg == 1:
            # Single-leg final
            winners = [
                r["home"] if r["goals_home"] >= r["goals_away"] else r["away"]
                for r in duel_records
            ]
            save_stage_winners("final", winners)
            if winners:
                advancement_text = (
                    f"👑 <b>VFL Champions League чемпиони: {winners[0]}!</b>"
                )

    return duel_lines, advancement_text


# ── Tie-break display helper ───────────────────────────────────────────────────

_REASON_LABELS: dict[str, str] = {
    "away goals":        "ташқи майдон голлари ҳисобига",
    "exact predictions": "аниқ прогнозлар ҳисобига",
    "player goals":      "ўйинчи голлари ҳисобига",
}


def _format_winner_lines(winner_details: list[dict]) -> str:
    """
    Build a multi-line advancement string with tie-break reasons.
    winner_details: list of {"winner": str, "reason": str, "penalty": dict | None}
    """
    lines: list[str] = []
    for d in winner_details:
        winner = d["winner"]
        reason = d["reason"]
        pen    = d.get("penalty")

        if reason == "aggregate":
            lines.append(f"  ✅ {winner}")
        elif reason == "penalties" and pen:
            sw = pen["score_winner"]
            sl = pen["score_loser"]
            lines.append(f"  🥅 Пенальтилар: {winner} {sw}–{sl}")
            lines.append(f"  ✅ {winner} пенальтилар серияси ҳисобига")
        else:
            label = _REASON_LABELS.get(reason, reason)
            lines.append(f"  ✅ {winner} {label}")

    return "\n".join(lines)


# ── Broadcast helpers ─────────────────────────────────────────────────────────

async def _broadcast(bot, text: str) -> None:
    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), text, parse_mode="HTML")
        except Exception:
            pass


async def _broadcast_md8_classification(bot) -> None:
    from bot.data.league_stage_db import get_classification
    clf = get_classification()
    if not clf:
        return
    r16 = clf.get("r16_direct", [])
    pz  = clf.get("playoff_zone", [])
    elim = clf.get("eliminated", [])

    lines = ["📋 <b>Лига босқичи якунланди!</b>\n"]
    if r16:
        lines.append(f"✅ <b>1/8 финалга тўғридан-тўғри ({len(r16)} жамоа)</b>")
        for t in r16:
            lines.append(f"  • {t}")
        lines.append("")
    if pz:
        lines.append(f"🎯 <b>Плей-офф босқичига ({len(pz)} жамоа)</b>")
        for t in pz:
            lines.append(f"  • {t}")
        lines.append("")
    if elim:
        lines.append(f"❌ <b>Мусобақани тарк этганлар ({len(elim)} жамоа)</b>")
        for t in elim:
            lines.append(f"  • {t}")
    lines.append("\n🎯 Плей-офф қуръаси яқинда!")
    await _broadcast(bot, "\n".join(lines))

    # Send possible opponents table as a second broadcast message
    await _broadcast_md8_possible_opponents(bot)


async def _broadcast_md8_possible_opponents(bot) -> None:
    """
    Broadcast the UEFA-bracket possible opponents for each direct seed (1–8).

    Seed order follows the UEFA 2024/25 knockout mapping:
      Seeds 1 & 2 → face W(17/18) or W(15/16)
      Seeds 7 & 8 → face W(23/24) or W(9/10)
      Seeds 5 & 6 → face W(21/22) or W(11/12)
      Seeds 3 & 4 → face W(19/20) or W(13/14)
    """
    # Sequential display order 1–8 (league position).
    # Pair assignments follow UEFA bracket; only the display order changes.
    # Each entry: (league_pos, pair_a_label, pair_b_label)
    _SEED_OPPONENTS: list[tuple[int, str, str]] = [
        (1, "17/18", "15/16"),
        (2, "17/18", "15/16"),
        (3, "19/20", "13/14"),
        (4, "19/20", "13/14"),
        (5, "21/22", "11/12"),
        (6, "21/22", "11/12"),
        (7, "23/24",  "9/10"),
        (8, "23/24",  "9/10"),
    ]
    _NUM_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣"]

    lines: list[str] = ["🎯 <b>ЭҲТИМОЛИЙ РАҚИБЛАР</b>\n"]
    for emoji, (seed_pos, pair_a, pair_b) in zip(_NUM_EMOJIS, _SEED_OPPONENTS):
        lines += [
            f"{emoji} <b>{seed_pos}-ўрин</b>",
            f"→ {pair_a} ғолиби ёки {pair_b} ғолиби",
            "",
        ]

    await _broadcast(bot, "\n".join(lines).rstrip())


async def _broadcast_stage_completed(bot, stage: str, match_day: int) -> None:
    from bot.data.league_stage_db import get_stage_winners
    winners = get_stage_winners(stage)
    label   = _STAGE_LABELS.get(stage, stage)

    if not winners:
        return

    lines = [f"🏆 <b>{label} якунланди!</b>\n", "<b>Кейинги босқичга ўтганлар:</b>"]
    for w in winners:
        lines.append(f"  ✅ {w}")

    next_stage = _NEXT_STAGE.get(stage)
    if next_stage:
        next_label = _STAGE_LABELS.get(next_stage, next_stage)
        lines.append(f"\n▶️ Навбатдаги босқич: <b>{next_label}</b>")

    await _broadcast(bot, "\n".join(lines))
