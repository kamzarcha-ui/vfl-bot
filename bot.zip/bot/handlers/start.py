"""
/start — Main menu with inline button navigation.

All existing commands remain fully functional via their own handlers.
This file handles only the start menu UI and navigation callbacks.

Callback namespace: mn:*
"""

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.admin_ids import is_admin as _is_admin
from bot.data.stats_db import get_coach_name_by_tid

from bot.handlers.clubtable import cmd_clubtable
from bot.handlers.topscorers import cmd_topscorers
from bot.handlers.goldenpredictor import cmd_goldenpredictor
from bot.handlers.teamoftheround import cmd_teamoftheround
from bot.handlers.tourresults import cmd_tourresults
from bot.handlers.fixtures import cmd_fixtures
from bot.handlers.predict import cmd_predict
from bot.handlers.predictions import cmd_predictions
from bot.handlers.results import cmd_results
from bot.handlers.vfltv import cmd_vflstudio
from bot.handlers.news import cmd_news
from bot.handlers.commentary import cmd_commentary
from bot.handlers.records import cmd_records
from bot.handlers.sensations import cmd_sensations
from bot.handlers.clubranking import cmd_clubranking
from bot.handlers.coachranking import cmd_coachranking
from bot.handlers.history import cmd_history
from bot.handlers.champions import cmd_champions
from bot.handlers.awards import cmd_awards
from bot.handlers.halloffame import cmd_halloffame
from bot.handlers.register import cmd_register
from bot.handlers.regulation import cmd_regulation
from bot.handlers.season_calendar import cmd_calendar
from bot.handlers.stats import cmd_stats

router = Router()

_BACK_HOME = InlineKeyboardButton(text="⬅️ Орқага", callback_data="mn:home")
_SEP = "━" * 20


# ── helpers ───────────────────────────────────────────────────────────────────

def _coach_name(telegram_id: int, first_name: str) -> str:
    name = get_coach_name_by_tid(telegram_id)
    return name or first_name or "ўйинчи"


def _get_registration(telegram_id: int) -> tuple[str, str] | None:
    """Return (license, team) if coach is registered, else None."""
    from bot.data.teams_db import load_coaches
    coaches = load_coaches()
    tid = str(telegram_id)
    for info in coaches.values():
        if info.get("telegram_id") == tid:
            return info.get("license", "—"), info.get("team", "—")
    return None


# ── keyboards ─────────────────────────────────────────────────────────────────

def _main_kb(is_admin: bool, user_id: int | None = None) -> InlineKeyboardMarkup:
    reg = _get_registration(user_id) if user_id else None
    if reg:
        license_no, team = reg
        reg_text = f"✅ {license_no} | {team}"
    else:
        reg_text = "📝 Рўйхатдан ўтиш"
    rows = [
        [
            InlineKeyboardButton(text=reg_text, callback_data="mn:pr:rg"),
        ],
        [
            InlineKeyboardButton(text="⚽ Тахминлар",  callback_data="mn:preds"),
            InlineKeyboardButton(text="📊 Жадваллар",  callback_data="mn:tables"),
        ],
        [
            InlineKeyboardButton(text="📺 VFL Studio",  callback_data="mn:studio"),
        ],
        [
            InlineKeyboardButton(text="🏛 Тарих",       callback_data="mn:history"),
            InlineKeyboardButton(text="👤 Профил",      callback_data="mn:profile"),
        ],
    ]
    if is_admin:
        rows.append([
            InlineKeyboardButton(text="⚙️ Админ",      callback_data="mn:admin"),
        ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


_TABLES_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="📊 Турнир жадвали",      callback_data="mn:t:ct")],
    [InlineKeyboardButton(text="⚽ Тўпурарлар",          callback_data="mn:t:ts")],
    [InlineKeyboardButton(text="🎯 Мураббийлар рейтинги", callback_data="mn:t:gp")],
    [InlineKeyboardButton(text="🏅 Тур лауреатлари",     callback_data="mn:t:tor")],
    [InlineKeyboardButton(text="📊 Тур натижалари",      callback_data="mn:t:tr")],
    [_BACK_HOME],
])

_PREDS_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="⚽ Match Day",           callback_data="mn:p:fx")],
    [InlineKeyboardButton(text="🎯 Тахмин киритиш",      callback_data="mn:p:pr")],
    [InlineKeyboardButton(text="👥 Барча тахминлар",     callback_data="mn:p:all")],
    [InlineKeyboardButton(text="📊 Match Day натижалари", callback_data="mn:p:res")],
    [_BACK_HOME],
])

_STUDIO_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="📺 Studio",              callback_data="mn:s:tv")],
    [InlineKeyboardButton(text="📰 News",                callback_data="mn:s:nw")],
    [InlineKeyboardButton(text="🎙 Commentary",           callback_data="mn:s:cm")],
    [InlineKeyboardButton(text="🚨 Мавсум рекордлари",   callback_data="mn:s:rc")],
    [InlineKeyboardButton(text="🔥 Sensations",          callback_data="mn:s:sn")],
    [_BACK_HOME],
])

_HISTORY_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🏅 Клублар рейтинги",    callback_data="mn:h:cr")],
    [InlineKeyboardButton(text="👔 Мураббийлар рейтинги", callback_data="mn:h:cor")],
    [InlineKeyboardButton(text="📚 Барча мавсумлар архиви", callback_data="mn:h:hs")],
    [InlineKeyboardButton(text="👑 Барча чемпионлар",    callback_data="mn:h:ch")],
    [InlineKeyboardButton(text="🏆 Мавсум совринлари",   callback_data="mn:h:aw")],
    [InlineKeyboardButton(text="🏛 Hall of Fame",         callback_data="mn:h:hf")],
    [_BACK_HOME],
])

_PROFILE_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="📝 Рўйхатдан ўтиш",     callback_data="mn:pr:rg")],
    [InlineKeyboardButton(text="📚 Регламент",            callback_data="mn:pr:rl")],
    [InlineKeyboardButton(text="🗓 Мавсум тақвими",      callback_data="mn:pr:cl")],
    [InlineKeyboardButton(text="📊 Шахсий статистика",   callback_data="mn:pr:st")],
    [_BACK_HOME],
])

_ADMIN_TOP_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🛡 Админ панели",        callback_data="mn:adm:panel")],
    [InlineKeyboardButton(text="🏆 Қуръа ва турнир",     callback_data="mn:adm:draw")],
    [InlineKeyboardButton(text="⚽ Match Day",            callback_data="mn:adm:md")],
    [_BACK_HOME],
])

_ADMIN_DRAW_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🎲 Қуръа ташлаш",            callback_data="mn:adm:d:draw")],
    [InlineKeyboardButton(text="📊 Қуръани текшириш",        callback_data="mn:adm:d:stats")],
    [InlineKeyboardButton(text="♻️ Қуръани бекор қилиш",    callback_data="mn:adm:d:reset")],
    [InlineKeyboardButton(text="📅 Тур санасини белгилаш",   callback_data="mn:adm:d:setdate")],
    [InlineKeyboardButton(text="✏️ Тур санасини ўзгартириш", callback_data="mn:adm:d:editdate")],
    [InlineKeyboardButton(text="🏆 Плей-офф қуръаси",        callback_data="mn:adm:d:playoff")],
    [InlineKeyboardButton(text="⬅️ Орқага",                  callback_data="mn:admin")],
])

_ADMIN_MD_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🚀 Match Day бошлаш",         callback_data="mn:adm:m:start")],
    [InlineKeyboardButton(text="⚽ Ўйинларни киритиш",        callback_data="mn:adm:m:setfx")],
    [InlineKeyboardButton(text="✏️ Ўйинларни ўзгартириш",    callback_data="mn:adm:m:editfx")],
    [InlineKeyboardButton(text="⏰ Дедлайн белгилаш",         callback_data="mn:adm:m:setdl")],
    [InlineKeyboardButton(text="✏️ Дедлайнни ўзгартириш",   callback_data="mn:adm:m:editdl")],
    [InlineKeyboardButton(text="📊 Match Day натижалари",     callback_data="mn:adm:m:setres")],
    [InlineKeyboardButton(text="✏️ Натижаларни ўзгартириш",  callback_data="mn:adm:m:editres")],
    [InlineKeyboardButton(text="🏁 Match Day якунлаш",        callback_data="mn:adm:m:close")],
    [InlineKeyboardButton(text="⬅️ Орқага",                   callback_data="mn:admin")],
])


# ── text builders ─────────────────────────────────────────────────────────────

def _home_text(coach_name: str) -> str:
    return (
        f"👋 Хуш келибсиз, <b>{coach_name}</b>!\n\n"
        f"🏆 <b>VFL CHAMPIONS LEAGUE</b>\n\n"
        f"{_SEP}\n\n"
        "Футбол ўйинлари натижаларини тахмин қилинг, жадвалда юқори "
        "ўринларни эгалланг ва чемпионлик учун курашинг!\n\n"
        f"{_SEP}"
    )


# ── /start ────────────────────────────────────────────────────────────────────

@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    uid  = message.from_user.id
    name = _coach_name(uid, message.from_user.first_name or "ўйинчи")
    await message.answer(
        _home_text(name),
        reply_markup=_main_kb(_is_admin(uid), user_id=uid),
        parse_mode="HTML",
    )


# ── Back to home ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:home")
async def cb_home(callback: CallbackQuery) -> None:
    uid  = callback.from_user.id
    name = _coach_name(uid, callback.from_user.first_name or "ўйинчи")
    await callback.message.edit_text(
        _home_text(name),
        reply_markup=_main_kb(_is_admin(uid), user_id=uid),
        parse_mode="HTML",
    )
    await callback.answer()


# ── Submenu openers ───────────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:tables")
async def cb_tables(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        f"📊 <b>ЖАДВАЛЛАР</b>\n\n{_SEP}",
        reply_markup=_TABLES_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "mn:preds")
async def cb_preds(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        f"⚽ <b>ТАХМИНЛАР</b>\n\n{_SEP}",
        reply_markup=_PREDS_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "mn:studio")
async def cb_studio(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        f"📺 <b>VFL STUDIO</b>\n\n{_SEP}",
        reply_markup=_STUDIO_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "mn:history")
async def cb_history_menu(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        f"🏛 <b>ТАРИХ</b>\n\n{_SEP}",
        reply_markup=_HISTORY_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "mn:profile")
async def cb_profile(callback: CallbackQuery) -> None:
    await callback.message.edit_text(
        f"👤 <b>ПРОФИЛ</b>\n\n{_SEP}",
        reply_markup=_PROFILE_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "mn:admin")
async def cb_admin_menu(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text(
        f"⚙️ <b>АДМИН</b>\n\n{_SEP}",
        reply_markup=_ADMIN_TOP_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── 📊 Жадваллар buttons ──────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:t:ct")
async def cb_clubtable(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_clubtable(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:t:ts")
async def cb_topscorers(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_topscorers(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:t:gp")
async def cb_goldenpredictor(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_goldenpredictor(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:t:tor")
async def cb_teamoftheround(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_teamoftheround(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:t:tr")
async def cb_tourresults(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_tourresults(callback.message, user_id=callback.from_user.id)


# ── ⚽ Тахминлар buttons ──────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:p:fx")
async def cb_fixtures(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_fixtures(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:p:pr")
async def cb_predict(callback: CallbackQuery, state: FSMContext) -> None:
    await callback.answer()
    await cmd_predict(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:p:all")
async def cb_predictions(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_predictions(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:p:res")
async def cb_results(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_results(callback.message, user_id=callback.from_user.id)


# ── 📺 VFL Studio buttons ─────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:s:tv")
async def cb_vflstudio(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_vflstudio(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:s:nw")
async def cb_news(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_news(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:s:cm")
async def cb_commentary(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_commentary(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:s:rc")
async def cb_records(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_records(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:s:sn")
async def cb_sensations(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_sensations(callback.message, user_id=callback.from_user.id)


# ── 🏛 Тарих buttons ──────────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:h:cr")
async def cb_clubranking(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_clubranking(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:h:cor")
async def cb_coachranking(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_coachranking(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:h:hs")
async def cb_history(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_history(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:h:ch")
async def cb_champions(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_champions(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:h:aw")
async def cb_awards(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_awards(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:h:hf")
async def cb_halloffame(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_halloffame(callback.message, user_id=callback.from_user.id)


# ── 👤 Профил buttons ─────────────────────────────────────────────────────────

_REGISTERED_PROFILE_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="📊 Шахсий статистика", callback_data="mn:pr:st")],
    [InlineKeyboardButton(text="📚 Регламент",          callback_data="mn:pr:rl")],
    [InlineKeyboardButton(text="🗓 Мавсум тақвими",    callback_data="mn:pr:cl")],
    [_BACK_HOME],
])


@router.callback_query(F.data == "mn:pr:rg")
async def cb_register(callback: CallbackQuery, state: FSMContext) -> None:
    reg = _get_registration(callback.from_user.id)
    if reg:
        license_no, team = reg
        await callback.message.edit_text(
            f"👤 <b>ПРОФИЛ</b>\n\n{_SEP}\n\n"
            f"🪪 Лицензия: <b>{license_no}</b>\n"
            f"🏟 Жамоа: <b>{team}</b>",
            reply_markup=_REGISTERED_PROFILE_KB,
            parse_mode="HTML",
        )
    else:
        await cmd_register(callback.message, state, user_id=callback.from_user.id)
    await callback.answer()


@router.callback_query(F.data == "mn:pr:rl")
async def cb_regulation(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_regulation(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:pr:cl")
async def cb_calendar(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_calendar(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:pr:st")
async def cb_stats(callback: CallbackQuery) -> None:
    await callback.answer()
    await cmd_stats(callback.message, user_id=callback.from_user.id)


# ── ⚙️ Admin top-level buttons ────────────────────────────────────────────────

@router.callback_query(F.data == "mn:adm:panel")
async def cb_adm_panel(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.admin import cmd_admin
    await cmd_admin(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:draw")
async def cb_adm_draw_menu(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text(
        f"🏆 <b>ҚУРЪА ВА ТУРНИР</b>\n\n{_SEP}",
        reply_markup=_ADMIN_DRAW_KB,
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "mn:adm:md")
async def cb_adm_md_menu(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text(
        f"⚽ <b>MATCH DAY</b>\n\n{_SEP}",
        reply_markup=_ADMIN_MD_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── 🏆 Қуръа ва турнир buttons ────────────────────────────────────────────────

@router.callback_query(F.data == "mn:adm:d:draw")
async def cb_adm_draw(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.draw import cmd_draw
    await cmd_draw(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:d:stats")
async def cb_adm_drawstats(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.draw import cmd_drawstats
    await cmd_drawstats(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:d:reset")
async def cb_adm_resetdraw(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.draw import cmd_resetdraw
    await cmd_resetdraw(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:d:setdate")
async def cb_adm_setdate(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.dates import cmd_setdate
    await cmd_setdate(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:d:editdate")
async def cb_adm_editdate(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.editdate import cmd_editdate
    await cmd_editdate(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:d:playoff")
async def cb_adm_playoffdraw(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.playoff_draw import cmd_playoffdraw
    await cmd_playoffdraw(callback.message, user_id=callback.from_user.id)


# ── ⚽ Match Day buttons ───────────────────────────────────────────────────────

@router.callback_query(F.data == "mn:adm:m:start")
async def cb_adm_startmd(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.matchday_control import cmd_startmatchday
    await cmd_startmatchday(callback.message, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:setfx")
async def cb_adm_setfixtures(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.setfixtures import cmd_setfixtures
    await cmd_setfixtures(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:editfx")
async def cb_adm_editfixtures(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.editfixtures import cmd_editfixtures
    await cmd_editfixtures(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:setdl")
async def cb_adm_setdeadline(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.deadline import cmd_setdeadline
    await cmd_setdeadline(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:editdl")
async def cb_adm_editdeadline(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.deadline import cmd_editdeadline
    await cmd_editdeadline(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:setres")
async def cb_adm_setmdresult(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.setmdresult import cmd_setmdresult
    await cmd_setmdresult(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:editres")
async def cb_adm_editmdresult(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.editmdresult import cmd_editmdresult
    await cmd_editmdresult(callback.message, state, user_id=callback.from_user.id)


@router.callback_query(F.data == "mn:adm:m:close")
async def cb_adm_closematchday(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.answer()
    from bot.handlers.closematchday import cmd_closematchday
    await cmd_closematchday(callback.message, user_id=callback.from_user.id)
