from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("coachranking"))
async def cmd_coachranking(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.season_db import load_coach_ranking

    ranking = load_coach_ranking()

    if not ranking:
        await message.answer(
            "👔 <b>Мураббийлар рейтинги</b>\n\n"
            "Ҳозирча рейтинг мавжуд эмас.\n\n"
            "Биринчи мавсумдан кейин автоматик шаклланади.",
            parse_mode="HTML",
        )
        return

    sorted_coaches = sorted(
        ranking.items(),
        key=lambda x: x[1].get("total_points", 0),
        reverse=True,
    )

    lines = ["👔 <b>МУРАББИЙЛАР РЕЙТИНГИ</b>\n"]
    top_medals = ["🥇", "🥈", "🥉"]

    for i, (coach, data) in enumerate(sorted_coaches, 1):
        pos  = top_medals[i - 1] if i <= 3 else f"{i}."
        pts  = data.get("total_points", 0)
        seasons_data = sorted(data.get("seasons", []), key=lambda x: x.get("season", 0))

        season_parts = []
        for s in seasons_data:
            sn  = s.get("season", "?")
            lbl = s.get("label", "")
            sp  = s.get("pts", 0)
            season_parts.append(f"М{sn}: {lbl} (+{sp})")

        lines.append(f"{pos} <b>{coach}</b> — {pts} оч")
        if season_parts:
            lines.append(f"   {' │ '.join(season_parts)}")

    await message.answer("\n".join(lines), parse_mode="HTML")
