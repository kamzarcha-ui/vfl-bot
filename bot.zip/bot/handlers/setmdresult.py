"""
/setmdresult — admin command to enter real scores for the current Match Day.

Only saves the scores.  Calculations (predictions, duels, league points) are
triggered separately by /closematchday once all scores are confirmed.
"""

import re

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

from bot.data.db import get_result, save_result
from bot.data.deadline_db import is_deadline_passed
from bot.data.matchday_db import get_matchday, is_matchday_closed
from bot.data.matchday_state_db import is_matchday_active

router = Router()
SCORE_RE = re.compile(r"^\d{1,2}-\d{1,2}$")




# ── states ────────────────────────────────────────────────────────────────────

class SetMdResultForm(StatesGroup):
    waiting_for_score = State()


# ── helpers ───────────────────────────────────────────────────────────────────

def _fixture_id(match_day: int, idx: int) -> str:
    return f"md{match_day}_m{idx + 1}"


async def _ask_score(message: Message, fixtures: list, idx: int) -> None:
    fx = fixtures[idx]
    await message.answer(
        f"🏟 <b>Натижа {idx + 1}/{len(fixtures)}</b>\n"
        f"⚽ {fx['home']} 🆚 {fx['away']}\n\n"
        "Якуний счётни киритинг (<code>2-1</code> кўринишида):\n"
        "<i>/cancel — тўхтатиш</i>",
        parse_mode="HTML",
    )


# ── /setmdresult ──────────────────────────────────────────────────────────────

@router.message(Command("setmdresult"))
async def cmd_setmdresult(message: Message, state: FSMContext, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        await message.answer("⛔ Бу буйруқ фақат администратор учун.")
        return

    if not is_matchday_active():
        await message.answer("⚠️ Фаол Матч Куни топилмади.")
        return

    if not is_deadline_passed():
        await message.answer(
            "⚠️ Тахмин муддати ҳали тугамаган.\n"
            "Матч Куни натижаларини муддат тугагандан кейин киритинг."
        )
        return

    md = get_matchday()
    if not md or not md.get("fixtures"):
        await message.answer("⚠️ Матч Куни мавжуд эмас.")
        return

    fixtures  = md["fixtures"]
    match_day = md["match_day"]

    # Block if Match Day already closed
    if is_matchday_closed():
        await message.answer(
            "⚠️ Match Day якунланган.\n\nНатижаларни ўзгартириш мумкин эмас."
        )
        return

    # Block if results already entered → redirect to editmdresult
    if get_result(_fixture_id(match_day, 0)) is not None:
        await message.answer(
            "⚠️ Match Day натижалари аллақачон киритилган.\n\n"
            "Натижаларни ўзгартириш учун:\n/editmdresult\n\nкомандасидан фойдаланинг."
        )
        return

    await state.set_data({
        "fixtures":  fixtures,
        "match_day": match_day,
        "index":     0,
        "entries":   [],
    })
    await state.set_state(SetMdResultForm.waiting_for_score)
    await _ask_score(message, fixtures, 0)


# ── score input ───────────────────────────────────────────────────────────────

@router.message(SetMdResultForm.waiting_for_score, ~F.text.startswith("/"))
async def process_md_score(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    text = (message.text or "").strip()

    if text.lower() == "cancel":
        await state.clear()
        await message.answer("❌ Натижа киритиш тўхтатилди.")
        return

    if not SCORE_RE.match(text):
        await message.answer(
            "⚠️ Нотўғри формат. Масалан: <code>2-1</code>",
            parse_mode="HTML",
        )
        return

    data      = await state.get_data()
    fixtures  = data["fixtures"]
    match_day = data["match_day"]
    idx       = data["index"]
    entries: list[str] = data["entries"]

    fx       = fixtures[idx]
    match_id = _fixture_id(match_day, idx)

    save_result(match_id, text)

    entry = f"{idx + 1}. {fx['home']} {text} {fx['away']}"
    entries.append(entry)

    next_idx = idx + 1
    await state.update_data(index=next_idx, entries=entries)

    await message.answer(
        f"✅ Натижа сақланди: <b>{fx['home']} {text} {fx['away']}</b>",
        parse_mode="HTML",
    )

    if next_idx < len(fixtures):
        await _ask_score(message, fixtures, next_idx)
        return

    # ── All 5 saved ───────────────────────────────────────────────────────────
    await state.clear()

    scores_list = "\n".join(entries)
    await message.answer(
        f"✅ <b>Барча натижалар сақланди</b>\n\n"
        f"{scores_list}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "Натижаларни таҳрирлаш учун: /editmdresult\n"
        "Ҳисоблашни бошлаш учун: /closematchday",
        parse_mode="HTML",
    )
