from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.db import get_club_stats
from bot.data.teams_db import load_teams

router = Router()

_W_NAME = 20
_W_PTS  = 3

_HDR  = f"   {'#':>2}  {'ЖАМОА':<{_W_NAME}}  {'ОЧК':>{_W_PTS}}  ГФ-ГА"
_DASH = "─" * 38


def _row(pos: int, name: str, pts: int, gf: int, ga: int) -> str:
    return f"   {pos:>2}. {name[:_W_NAME]:<{_W_NAME}}  {pts:>{_W_PTS}}  {gf}-{ga}"


def _pre(rows: list[str]) -> str:
    """Block code — renders with a Telegram copy button."""
    return "<pre>" + "\n".join([_HDR, _DASH] + rows) + "</pre>"


def _code(rows: list[str]) -> str:
    """Inline code block — monospace rendering, no copy button."""
    return "<code>" + "\n".join([_HDR, _DASH] + rows) + "</code>"


@router.message(Command("clubtable"))
async def cmd_clubtable(message: Message, *, user_id: int | None = None) -> None:
    all_teams  = load_teams()
    club_stats = get_club_stats()

    data: list[tuple[str, int, int, int]] = []
    for team_name in all_teams:
        s = club_stats.get(team_name, {})
        data.append((team_name, s.get("pts", 0), s.get("gf", 0), s.get("ga", 0)))

    data.sort(key=lambda r: (-r[1], -(r[2] - r[3]), r[0]))

    numbered = [(i + 1, name, pts, gf, ga) for i, (name, pts, gf, ga) in enumerate(data)]

    z1 = [t for t in numbered if t[0] <= 8]
    z2 = [t for t in numbered if 9  <= t[0] <= 24]
    z3 = [t for t in numbered if t[0] >= 25]

    # Build ordered list of non-empty sections.
    # The LAST section uses <pre> (one copy button at the bottom).
    # All earlier sections use <code> (monospace, no copy button).
    sections: list[tuple[str, list]] = []
    if z1:
        sections.append(("✅ <b>Тўғридан-тўғри 1/8 финал</b>", z1))
    if z2:
        sections.append(("🎯 <b>Плей-офф босқичи</b>", z2))
    if z3:
        sections.append(("⚠️ <b>Мусобақани тарк этиш зонаси</b>", z3))

    parts = [
        "🏆 <b>VFL CHAMPIONS LEAGUE</b>",
        "",
        "📊 <b>ТУРНИР ЖАДВАЛИ</b>",
        "",
    ]

    for i, (label, zone) in enumerate(sections):
        parts.append(label)
        rows = [_row(*t) for t in zone]
        if i < len(sections) - 1:
            parts.append(_code(rows))   # no copy button
        else:
            parts.append(_pre(rows))    # copy button on the last section only

    await message.answer("\n".join(parts), parse_mode="HTML")
