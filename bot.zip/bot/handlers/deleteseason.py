from bot.data.admin_ids import is_admin as _is_admin
"""
/deleteseason — Admin: delete a season's data (archive + live).

PROTECTED files never touched:
  hall_of_fame_records.json, hall_of_fame_history.json,
  club_ranking.json, coach_ranking.json, season_settings.json

Deletion scope:
  Past season  → history.json entry, champions.json entry, awards.json entry
  Current season → same + live db.json data, player goals, coach season stats,
                   matchday files  (season counter NOT decremented)
"""

import os

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

router = Router()




# ── FSM ──────────────────────────────────────────────────────────────────────

class DeleteSeasonForm(StatesGroup):
    waiting_season_select  = State()
    waiting_first_confirm  = State()   # ✅ HA / ❌ YO'Q buttons
    waiting_text_confirm   = State()   # must type "DELETE SEASON X"


# ── Keyboard helpers ──────────────────────────────────────────────────────────

def _seasons_kb(season_numbers: list[int]) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(
            text=f"{n}-мавсум",
            callback_data=f"dseason:pick:{n}",
        )]
        for n in season_numbers
    ]
    rows.append([InlineKeyboardButton(text="❌ Бекор қилиш", callback_data="dseason:cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _confirm_kb(season: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ ҲА", callback_data=f"dseason:yes:{season}"),
            InlineKeyboardButton(text="❌ ЙЎҚ", callback_data="dseason:cancel"),
        ]
    ])


# ── Helpers ───────────────────────────────────────────────────────────────────

def _available_seasons() -> list[int]:
    """Return list of season numbers that can be deleted (archived + current)."""
    from bot.data.season_db import load_history, get_current_season
    archived = [h["season"] for h in load_history() if "season" in h]
    current  = get_current_season()
    all_nums = sorted(set(archived + [current]))
    return all_nums


def _warning_text(season: int) -> str:
    from bot.data.season_db import get_current_season
    current = get_current_season()
    extra   = " (жорий мавсум)" if season == current else " (архив)"
    return (
        f"⚠️ <b>ДИҚҚАТ!</b>\n\n"
        f"Сиз <b>{season}-мавсум</b>{extra}ни ўчирмоқчисиз.\n\n"
        "Қуйидагилар ўчирилади:\n\n"
        "• Барча Match Day маълумотлари\n"
        "• Барча натижалар\n"
        "• Барча прогнозлар\n"
        "• Барча статистикалар\n"
        "• Барча совринлар\n"
        "• Чемпион маълумоти\n"
        "• Архив маълумоти\n\n"
        "<b>Бу амални бекор қилиб бўлмайди.</b>\n\n"
        "Давом этасизми?"
    )


def _execute_delete(season: int) -> str:
    """
    Delete season data. Returns a human-readable summary of what was done.
    NEVER touches: HOF files, club_ranking, coach_ranking, season_settings.
    """
    from bot.data.season_db import (
        load_history, save_history,
        load_champions, save_champions,
        load_awards, save_awards,
        get_current_season,
    )
    import bot.data.db as _db
    from bot.data.teams_db import load_teams, save_teams, load_coaches, save_coaches
    from bot.data.matchday_db import reset_matchday

    done: list[str] = []

    # ── Archive files ─────────────────────────────────────────────────────────
    history = load_history()
    before  = len(history)
    history = [h for h in history if h.get("season") != season]
    if len(history) < before:
        save_history(history)
        done.append("📚 Тарих архиви ўчирилди")

    champions = load_champions()
    champions = [c for c in champions if c.get("season") != season]
    save_champions(champions)
    done.append("👑 Чемпион маълумоти ўчирилди")

    awards = load_awards()
    awards = [a for a in awards if a.get("season") != season]
    save_awards(awards)
    done.append("🏆 Совринлар ўчирилди")

    # ── Current season: also clear live data ──────────────────────────────────
    current = get_current_season()
    if season == current:
        # Clear db.json season data
        data = _db._load()
        for key in ("predictions", "fixtures", "results", "duel_results",
                    "playoff_results", "club_stats", "matchups", "matchup_club_scored"):
            data.pop(key, None)
        data["current_matchday"] = 0
        _db._save(data)
        done.append("📊 Жорий мавсум статистикаси тозаланди")

        # Reset league_stage.json
        league_path = os.path.join(os.path.dirname(__file__), "..", "data", "league_stage.json")
        league_path = os.path.normpath(league_path)
        if os.path.exists(league_path):
            os.remove(league_path)
            done.append("🏟 Лига босқичи маълумоти ўчирилди")

        # Reset player goals
        teams = load_teams()
        for info in teams.values():
            for p in info.get("players", []):
                if isinstance(p, dict):
                    p["goals"] = 0
        save_teams(teams)
        done.append("⚽ Ўйинчи голлари тозаланди")

        # Reset coach season stats
        coaches = load_coaches()
        for info in coaches.values():
            info["exact_predictions"] = 0
            info["matchday_goals"]    = 0
        save_coaches(coaches)
        done.append("🎯 Мураббий статистикаси тозаланди")

        # Clear matchday files
        try:
            reset_matchday()
            done.append("📅 Match Day ўчирилди")
        except Exception:
            pass

        # Clear matchday state
        _mds_path = os.path.join(os.path.dirname(__file__), "..", "data", "matchday_state.json")
        _mds_path = os.path.normpath(_mds_path)
        if os.path.exists(_mds_path):
            import json
            with open(_mds_path, "w") as f:
                json.dump({"active": False, "closed": False}, f)

    return "\n".join(f"✅ {d}" for d in done)


# ── /deleteseason command ─────────────────────────────────────────────────────

@router.message(Command("deleteseason"))
async def cmd_deleteseason(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    seasons = _available_seasons()
    if not seasons:
        await message.answer("⚠️ Ўчирилиши мумкин мавсумлар мавжуд эмас.")
        return

    await state.set_state(DeleteSeasonForm.waiting_season_select)
    await message.answer(
        "🗑 <b>Мавсумни ўчириш</b>\n\n"
        "Ўчирмоқчи бўлган мавсумни танланг:",
        reply_markup=_seasons_kb(seasons),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("dseason:pick:"))
async def cb_season_pick(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    season = int(callback.data.split(":")[-1])
    await state.update_data(season=season)
    await state.set_state(DeleteSeasonForm.waiting_first_confirm)

    await callback.message.edit_text(
        _warning_text(season),
        reply_markup=_confirm_kb(season),
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data.startswith("dseason:yes:"))
async def cb_season_yes(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    season = int(callback.data.split(":")[-1])
    await state.update_data(season=season)
    await state.set_state(DeleteSeasonForm.waiting_text_confirm)

    await callback.message.edit_text(
        f"✏️ Тасдиқлаш учун қуйидагини аниқ ёзинг:\n\n"
        f"<code>DELETE SEASON {season}</code>",
        parse_mode="HTML",
    )
    await callback.answer()


@router.callback_query(F.data == "dseason:cancel")
async def cb_season_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("❌ Амалиёт бекор қилинди.")
    await callback.answer()


@router.message(DeleteSeasonForm.waiting_text_confirm)
async def process_season_text_confirm(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    data   = await state.get_data()
    season = data.get("season")
    expected = f"DELETE SEASON {season}"

    if (message.text or "").strip() != expected:
        await message.answer(
            f"⚠️ Нотўғри матн. Аниқ қуйидагини ёзинг:\n\n"
            f"<code>{expected}</code>",
            parse_mode="HTML",
        )
        return

    await state.clear()
    summary = _execute_delete(season)
    await message.answer(
        f"🗑 <b>{season}-мавсум ўчирилди</b>\n\n{summary}",
        parse_mode="HTML",
    )
