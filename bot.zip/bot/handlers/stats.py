from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.teams_db import load_coaches, load_teams

router = Router()


@router.message(Command("stats"))
async def cmd_stats(message: Message, user_id: int | None = None) -> None:
    tid = str(user_id or message.from_user.id)

    coaches = load_coaches()
    coach_name: str | None = None
    coach_info: dict | None = None
    for name, info in coaches.items():
        if info.get("telegram_id") == tid:
            coach_name = name
            coach_info = info
            break

    if coach_info is None:
        await message.answer(
            "⚠️ Сиз ҳали рўйхатдан ўтмагансиз.\n"
            "VFL Чемпионлар Лигасига қўшилиш учун /register ни ишлатинг."
        )
        return

    team_name: str = coach_info.get("team", "—")
    license_no: str = coach_info.get("license", "—")
    exact_preds: int = coach_info.get("exact_predictions", 0)

    teams = load_teams()
    raw_players: list = teams.get(team_name, {}).get("players", [])
    players = [p for p in raw_players if isinstance(p, dict)]

    if players:
        player_lines = ""
        for i, p in enumerate(players, 1):
            goals = p.get("goals", 0)
            goal_icon = "⚽" if goals > 0 else "—"
            player_lines += f"  {i}. {p.get('name', '?')}  {goal_icon} {goals} гол\n"
    else:
        player_lines = "  <i>Ўйинчилар ҳали рўйхатдан ўтмаган.</i>\n"

    await message.answer(
        f"📊 <b>Мураббий Статистикаси</b>\n\n"
        f"👤 <b>{coach_name}</b>\n"
        f"🪪 Лицензия: <code>{license_no}</code>\n"
        f"🏟 Жамоа: <b>{team_name}</b>\n\n"
        f"<b>Тахмин рекорди</b>\n"
        f"  🎯 Аниқ тахминлар: <b>{exact_preds}</b>\n\n"
        f"<b>Жамоа таркиби</b>\n"
        f"{player_lines}",
        parse_mode="HTML",
    )
