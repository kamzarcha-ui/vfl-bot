from bot.data.admin_ids import is_admin as _is_admin
"""
👥 Иштирокчилар — admin participants panel (sub-menu of /admin).

Sub-menus:
  📋 Барча иштирокчилар  — paginated read-only list
  🔍 Иштирокчини қидириш — FSM text search (name / license / team)
  🗑 Иштирокчини ўчириш  — pick → confirm → delete
"""


from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.teams_db import get_all_registered, remove_participant

router = Router()

PAGE_SIZE = 5




# ── FSM ───────────────────────────────────────────────────────────────────────

class ParticipantsForm(StatesGroup):
    waiting_search     = State()
    waiting_del_confirm = State()


# ── Keyboards ─────────────────────────────────────────────────────────────────

def _menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Барча иштирокчилар",  callback_data="part:list:0")],
        [InlineKeyboardButton(text="🔍 Иштирокчини қидириш", callback_data="part:search")],
        [InlineKeyboardButton(text="🗑 Иштирокчини ўчириш",  callback_data="part:del_page:0")],
        [InlineKeyboardButton(text="⬅️ Орқага",              callback_data="adm:menu")],
    ])


def _back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:participants"),
    ]])


def _list_nav_kb(page: int, total: int) -> InlineKeyboardMarkup:
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"part:list:{page - 1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"part:list:{page + 1}"))
    rows = [nav] if nav else []
    rows.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:participants")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _del_list_kb(page: int, participants: list[dict]) -> InlineKeyboardMarkup:
    total = len(participants)
    start = page * PAGE_SIZE
    end   = min(start + PAGE_SIZE, total)
    rows  = []
    for i in range(start, end):
        p = participants[i]
        rows.append([InlineKeyboardButton(
            text=f"🗑 {p['team']} — {p['coach']}",
            callback_data=f"part:del_pick:{i}",
        )])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"part:del_page:{page - 1}"))
    if end < total:
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"part:del_page:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:participants")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _del_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Ҳа", callback_data="part:del_yes"),
        InlineKeyboardButton(text="❌ Йўқ", callback_data="part:del_no"),
    ]])


# ── Text helpers ──────────────────────────────────────────────────────────────

def _participant_block(p: dict) -> str:
    players = p.get("players", [])
    player_lines = "\n".join(f"• {pl}" for pl in players) if players else "• —"
    return (
        f"🏟 {p['team']}\n"
        f"👤 {p['coach']}\n"
        f"🆔 {p['license']}\n\n"
        f"⚽ Футболчилар:\n{player_lines}"
    )


def _list_page_text(participants: list[dict], page: int) -> str:
    total = len(participants)
    if not total:
        return "⚠️ Рўйхатдан ўтган иштирокчилар йўқ."
    start = page * PAGE_SIZE
    end   = min(start + PAGE_SIZE, total)
    pages = (total + PAGE_SIZE - 1) // PAGE_SIZE
    header = f"📋 <b>БАРЧА ИШТИРОКЧИЛАР</b> ({total} нафар)"
    if pages > 1:
        header += f"\nСаҳифа {page + 1}/{pages}"
    header += "\n\n"
    sep  = "\n━━━━━━━━━━━━━━━━━━━━\n\n"
    body = sep.join(_participant_block(p) for p in participants[start:end])
    return header + body


# ── adm:participants ───────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:participants")
async def cb_menu(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "👥 <b>ИШТИРОКЧИЛАР</b>\n\n━━━━━━━━━━━━━━━━━━━━",
        reply_markup=_menu_kb(),
    )
    await callback.answer()


# ── 📋 Барча иштирокчилар ─────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("part:list:"))
async def cb_list(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    try:
        page = int(callback.data.split(":")[-1])
    except ValueError:
        page = 0

    participants = get_all_registered()
    await callback.message.edit_text(
        _list_page_text(participants, page),
        reply_markup=_list_nav_kb(page, len(participants)),
    )
    await callback.answer()


# ── 🔍 Иштирокчини қидириш ────────────────────────────────────────────────────

@router.callback_query(F.data == "part:search")
async def cb_search_start(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.set_state(ParticipantsForm.waiting_search)
    await callback.message.edit_text(
        "🔍 <b>Иштирокчини қидириш</b>\n\n"
        "Исм, лицензия рақами ёки жамоа номини киритинг:\n\n"
        "Масалан: <code>Азиз</code>, <code>VFL0002</code>, <code>Реал Мадрид</code>",
        reply_markup=_back_kb(),
    )
    await callback.answer()


@router.message(ParticipantsForm.waiting_search)
async def msg_search(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return

    query = (message.text or "").strip()
    if query.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди. Буйруқни қайта юборинг.")
        return
    if not query:
        await message.answer("⚠️ Сўров бўш бўлиши мумкин эмас.")
        return

    await state.clear()

    q     = query.lower()
    found = [
        p for p in get_all_registered()
        if q in p["team"].lower()
        or q in p["coach"].lower()
        or q in p["license"].lower()
    ]

    if not found:
        await message.answer("⚠️ Иштирокчи топилмади.", reply_markup=_back_kb())
        return

    sep   = "\n\n━━━━━━━━━━━━━━━━━━━━\n\n"
    blocks = []
    for p in found:
        players     = p.get("players", [])
        player_lines = "\n".join(f"• {pl}" for pl in players) if players else "• —"
        blocks.append(
            f"🏟 {p['team']}\n"
            f"👤 {p['coach']}\n"
            f"🆔 {p['license']}\n\n"
            f"⚽ Футболчилар:\n{player_lines}"
        )
    await message.answer(sep.join(blocks), reply_markup=_back_kb())


# ── 🗑 Иштирокчини ўчириш — рўйхат ───────────────────────────────────────────

@router.callback_query(F.data.startswith("part:del_page:"))
async def cb_del_page(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    try:
        page = int(callback.data.split(":")[-1])
    except ValueError:
        page = 0

    participants = get_all_registered()
    await state.clear()

    if not participants:
        await callback.message.edit_text(
            "⚠️ Рўйхатдан ўтган иштирокчилар йўқ.",
            reply_markup=_back_kb(),
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        "🗑 <b>Иштирокчини ўчириш</b>\n\n"
        "Ўчирмоқчи бўлган иштирокчини танланг:",
        reply_markup=_del_list_kb(page, participants),
    )
    await callback.answer()


# ── 🗑 Иштирокчини ўчириш — тасдиқ ──────────────────────────────────────────

@router.callback_query(F.data.startswith("part:del_pick:"))
async def cb_del_pick(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    try:
        idx = int(callback.data.split(":")[-1])
    except ValueError:
        await callback.answer("⚠️ Хато.", show_alert=True)
        return

    participants = get_all_registered()
    if idx < 0 or idx >= len(participants):
        await callback.answer("⚠️ Иштирокчи топилмади.", show_alert=True)
        return

    p = participants[idx]
    await state.set_state(ParticipantsForm.waiting_del_confirm)
    await state.update_data(team=p["team"])

    await callback.message.edit_text(
        "⚠️ <b>Иштирокчини ўчириш</b>\n\n"
        f"🏟 {p['team']}\n"
        f"👤 {p['coach']}\n"
        f"🆔 {p['license']}\n\n"
        "Тасдиқлайсизми?",
        reply_markup=_del_confirm_kb(),
    )
    await callback.answer()


@router.callback_query(F.data == "part:del_yes")
async def cb_del_yes(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    data      = await state.get_data()
    team_name = data.get("team", "")
    await state.clear()

    if not team_name:
        await callback.message.edit_text(
            "⚠️ Хато: жамоа аниқланмади.",
            reply_markup=_back_kb(),
        )
        await callback.answer()
        return

    ok = remove_participant(team_name)
    if ok:
        await callback.message.edit_text(
            f"✅ <b>{team_name}</b> жамоаси ва мураббийи рўйхатдан ўчирилди.",
            reply_markup=_back_kb(),
        )
    else:
        await callback.message.edit_text(
            f"⚠️ <b>{team_name}</b> — иштирокчи топилмади ёки аллақачон ўчирилган.",
            reply_markup=_back_kb(),
        )
    await callback.answer()


@router.callback_query(F.data == "part:del_no")
async def cb_del_no(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await callback.message.edit_text(
        "❌ Ўчириш бекор қилинди.",
        reply_markup=_back_kb(),
    )
    await callback.answer()
