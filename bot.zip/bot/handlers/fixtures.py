from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.db import get_fixtures, get_result
from bot.data.matchday_db import get_matchday

router = Router()


@router.message(Command("fixtures"))
async def cmd_fixtures(message: Message, *, user_id: int | None = None) -> None:
    # ── New Match Day format (when admin has set fixtures via /setfixtures) ────
    md = get_matchday()
    if md:
        match_day     = md.get("match_day", "?")
        deadline_date = md.get("deadline_date", "—")
        deadline_time = md.get("deadline_time", "—")
        fixtures      = md.get("fixtures", [])

        lines = [
            f"⚽ <b>Match Day #{match_day}</b>\n",
            "⏰ <b>Тахмин қабул қилиш муддати:</b>\n",
            f"📅 {deadline_date} • {deadline_time} (Москва вақти)\n",
            "━━━━━━━━━━━━━━━━━━━━\n",
        ]
        for i, fx in enumerate(fixtures, 1):
            lines.append(f"{i}. <b>{fx['home']}</b> vs <b>{fx['away']}</b>")
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("\n🎯 Тахмин бериш: /predict")

        await message.answer("\n".join(lines), parse_mode="HTML")
        return

    # ── Legacy format (draw-based fixtures from db.json) ─────────────────────
    all_fixtures = get_fixtures()
    if not all_fixtures:
        await message.answer("📅 Матчлар жадвали ҳали мавжуд эмас.")
        return

    current_round = max(f["round"] for f in all_fixtures)
    round_fixtures = [f for f in all_fixtures if f["round"] == current_round]

    lines = [f"⚽ <b>{current_round}-тур — Match Day</b>\n"]
    for i, match in enumerate(round_fixtures, 1):
        result = get_result(match["id"])
        if result and result.get("processed"):
            score = result["score"]
            status = f"✅ <b>{match['home']} {score} {match['away']}</b>"
        else:
            status = f"⚽ {match['home']} 🆚 {match['away']}  |  🕐 {match['date']}"
        lines.append(f"{i}. {status}")

    lines.append("\nТахминларингизни бериш учун /predict ни ишлатинг!")
    await message.answer("\n".join(lines), parse_mode="HTML")
