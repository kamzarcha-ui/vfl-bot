"""
/removeparticipant — Admin: remove a registered participant.

Searches by license number (VFL0001) or team name.
Clears telegram_id binding, resets coach season stats.
Team remains in the system and becomes available for re-registration.

NEVER deletes: team record itself, HOF data, rankings, season archive.
"""


from aiogram import Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

router = Router()




# ── FSM ──────────────────────────────────────────────────────────────────────

class RemoveParticipantForm(StatesGroup):
    waiting_input   = State()   # admin types license or team name
    waiting_confirm = State()   # must type "REMOVE CONFIRM"


# ── Lookup ────────────────────────────────────────────────────────────────────

def _find_participant(query: str) -> tuple[str | None, dict | None, str | None]:
    """
    Search teams.json by license number or team name (case-insensitive).
    Returns (team_name, team_info, coach_name) or (None, None, None) if not found.
    """
    from bot.data.teams_db import load_teams

    q      = query.strip()
    ql     = q.lower()
    teams  = load_teams()

    for name, info in teams.items():
        # Match by license (case-insensitive) OR team name (case-insensitive)
        lic   = info.get("license", "") or ""
        coach = info.get("coach")
        if lic.lower() == ql or name.lower() == ql:
            # Only return if actually registered (has telegram_id or coach)
            if info.get("telegram_id") or coach:
                return name, info, coach
    return None, None, None


def _participant_card(team_name: str, info: dict, coach_name: str | None) -> str:
    lic = info.get("license", "—")
    tid = info.get("telegram_id", "—")
    return (
        f"🏟 <b>Жамоа:</b> {team_name}\n"
        f"👤 <b>Мураббий:</b> {coach_name or '—'}\n"
        f"🪪 <b>Лицензия:</b> {lic}\n"
        f"📱 <b>Telegram ID:</b> {tid}"
    )


def _execute_remove(team_name: str) -> str:
    """
    Remove participant registration.
    Clears: telegram_id from team, telegram_id from coach entry,
    resets coach season stats.
    Team stays in the system, coach entry stays but loses binding.
    """
    from bot.data.teams_db import load_teams, save_teams, load_coaches, save_coaches

    teams   = load_teams()
    coaches = load_coaches()
    done: list[str] = []

    team_info = teams.get(team_name, {})
    coach_name = team_info.get("coach")

    # Remove binding from team entry
    if "telegram_id" in team_info:
        del team_info["telegram_id"]
        done.append(f"📱 {team_name} — Telegram боғлиқлиги ўчирилди")

    # Clear coach field on team (optional — keeps team "available")
    # We keep the coach name so history is preserved; only remove telegram binding
    teams[team_name] = team_info
    save_teams(teams)

    # Remove telegram_id from coaches entry and reset season stats
    if coach_name and coach_name in coaches:
        coach_info = coaches[coach_name]
        if "telegram_id" in coach_info:
            del coach_info["telegram_id"]
            done.append(f"👤 {coach_name} — Telegram боғлиқлиги ўчирилди")
        coach_info["exact_predictions"] = 0
        coach_info["matchday_goals"]    = 0
        coaches[coach_name] = coach_info
        save_coaches(coaches)
        done.append(f"🎯 {coach_name} — Мавсум статистикаси тозаланди")
    else:
        # Search by telegram_id match in coaches (in case coach name is mislinked)
        old_tid = str(team_info.get("telegram_id", ""))
        for cname, cinfo in coaches.items():
            if str(cinfo.get("telegram_id", "")) == old_tid and old_tid:
                del cinfo["telegram_id"]
                cinfo["exact_predictions"] = 0
                cinfo["matchday_goals"]    = 0
                coaches[cname] = cinfo
                done.append(f"👤 {cname} — Telegram боғлиқлиги ўчирилди")
                save_coaches(coaches)
                break

    if not done:
        return "⚠️ Ўчириладиган маълумот топилмади."

    return "\n".join(f"✅ {d}" for d in done)


# ── /removeparticipant command ────────────────────────────────────────────────

@router.message(Command("removeparticipant"))
async def cmd_removeparticipant(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    await state.set_state(RemoveParticipantForm.waiting_input)
    await message.answer(
        "👤 <b>Қатнашчини ўчириш</b>\n\n"
        "Лицензия рақами <i>(VFL0001)</i> ёки жамоа номини киритинг:\n\n"
        "<i>Бекор қилиш: /cancel</i>",
        parse_mode="HTML",
    )


@router.message(RemoveParticipantForm.waiting_input)
async def process_rp_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди.")
        return

    team_name, info, coach = _find_participant(text)
    if not team_name or not info:
        await message.answer(
            "⚠️ Қатнашчи топилмади.\n\n"
            "Лицензия рақами ёки жамоа номини текширинг."
        )
        return

    await state.update_data(team_name=team_name)
    await state.set_state(RemoveParticipantForm.waiting_confirm)

    card = _participant_card(team_name, info, coach)
    await message.answer(
        f"🔍 <b>Қатнашчи топилди:</b>\n\n"
        f"{card}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "⚠️ <b>Қатнашчи бутунлай ўчирилади:</b>\n\n"
        "• Telegram боғлиқлиги ўчирилади\n"
        "• Мавсум статистикаси тозаланади\n"
        "• Рўйхатдан ўтиш маълумоти тозаланади\n\n"
        "<i>Жамоа системада қолади ва янги рўйхатдан ўтиш мумкин бўлади.</i>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Тасдиқлаш учун аниқ ёзинг:\n\n"
        "<code>REMOVE CONFIRM</code>",
        parse_mode="HTML",
    )


@router.message(RemoveParticipantForm.waiting_confirm)
async def process_rp_confirm(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    text = (message.text or "").strip()

    if text.startswith("/"):
        await state.clear()
        await message.answer("⚠️ Амалиёт тўхтатилди.")
        return

    if text != "REMOVE CONFIRM":
        await message.answer(
            "⚠️ Нотўғри матн. Аниқ қуйидагини ёзинг:\n\n"
            "<code>REMOVE CONFIRM</code>",
            parse_mode="HTML",
        )
        return

    data      = await state.get_data()
    team_name = data.get("team_name", "")
    await state.clear()

    summary = _execute_remove(team_name)
    await message.answer(
        f"🗑 <b>{team_name} — қатнашчи ўчирилди</b>\n\n{summary}",
        parse_mode="HTML",
    )
