from bot.data.admin_ids import is_admin as _is_admin
"""
Announcement Center — admin-only manual broadcast feature.

Flow:
  /admin → 📢 Эълон маркази → inner menu
    • 📢 Эълон юбориш   → FSM: ask for text → preview → confirm → broadcast
    • 📜 Эълонлар тарихи → show latest 20 announcements

Broadcasts to every registered participant DM + GROUP_ID (if configured).
Stores result in announcements.json (max 100, newest first).
"""

import os

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.announcements_db import load_announcements, save_announcement
from bot.data.teams_db import load_teams

router = Router()

_GROUP_ID = os.environ.get("GROUP_ID", "").strip()

_HISTORY_PAGE = 20  # max items shown per page




# ── FSM ───────────────────────────────────────────────────────────────────────

class AnnounceForm(StatesGroup):
    waiting_for_text = State()


# ── Keyboards ─────────────────────────────────────────────────────────────────

_INNER_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="📢 Эълон юбориш",     callback_data="adm:ann:send")],
    [InlineKeyboardButton(text="📜 Эълонлар тарихи",  callback_data="adm:ann:history")],
    [InlineKeyboardButton(text="⬅️ Орқага",            callback_data="adm:menu")],
])

_CONFIRM_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="✅ Ҳа",            callback_data="adm:ann:confirm"),
    InlineKeyboardButton(text="❌ Бекор қилиш",  callback_data="adm:ann:cancel"),
]])

_BACK_TO_ANN_KB = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(text="⬅️ Орқага", callback_data="adm:announcement"),
]])


def _build_preview(text: str) -> str:
    return (
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "📢 <b>VFL РАСМИЙ ХАБАРИ</b>\n\n"
        f"{text}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "Юборилсинми?"
    )


# ── Inner menu ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:announcement")
async def cb_announcement_menu(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "📢 <b>ЭЪЛОН МАРКАЗИ</b>\n\n"
        "Барча қатнашчилар ва гуруҳга хабар юборинг.",
        reply_markup=_INNER_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── Start send flow ───────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:ann:send")
async def cb_ann_send(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.set_state(AnnounceForm.waiting_for_text)
    await callback.message.edit_text(
        "✍️ <b>Юбориладиган хабарни киритинг:</b>\n\n"
        "<i>Бекор қилиш: /cancel</i>",
        reply_markup=None,
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(AnnounceForm.waiting_for_text)
async def process_ann_text(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return

    text = (message.text or "").strip()

    if text.lower() in ("/cancel", "cancel"):
        await state.clear()
        await message.answer(
            "❌ Эълон бекор қилинди.",
            reply_markup=_BACK_TO_ANN_KB,
            parse_mode="HTML",
        )
        return

    if not text:
        await message.answer(
            "⚠️ Хабар бўш бўлиши мумкин эмас. Қайта киритинг:"
        )
        return

    await state.update_data(ann_text=text)
    await message.answer(
        _build_preview(text),
        reply_markup=_CONFIRM_KB,
        parse_mode="HTML",
    )


# ── Confirm / Cancel ──────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:ann:confirm")
async def cb_ann_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    data = await state.get_data()
    text = data.get("ann_text", "")
    await state.clear()

    if not text:
        await callback.message.edit_text("⚠️ Хабар матни топилмади.")
        await callback.answer()
        return

    await callback.message.edit_text("⏳ Хабар юборилмоқда...")
    await callback.answer()

    broadcast_text = (
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "📢 <b>VFL РАСМИЙ ХАБАРИ</b>\n\n"
        f"{text}\n\n"
        "━━━━━━━━━━━━━━━━━━━━"
    )

    participants_ok = participants_fail = 0
    group_ok = 0

    # Broadcast to all registered participant DMs
    teams = load_teams()
    for info in teams.values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await callback.message.bot.send_message(
                int(tid), broadcast_text, parse_mode="HTML"
            )
            participants_ok += 1
        except Exception:
            participants_fail += 1

    # Broadcast to group
    if _GROUP_ID:
        try:
            await callback.message.bot.send_message(
                int(_GROUP_ID), broadcast_text, parse_mode="HTML"
            )
            group_ok = 1
        except Exception:
            pass

    # Persist announcement
    from bot.data.season_db import get_current_season
    save_announcement(text, get_current_season())

    # Delivery report
    await callback.message.answer(
        "✅ <b>Юборилди</b>\n\n"
        f"👥 Қатнашчилар: {participants_ok}\n"
        f"👥 Гуруҳлар: {group_ok}\n"
        f"❌ Хатолар: {participants_fail}",
        reply_markup=_BACK_TO_ANN_KB,
        parse_mode="HTML",
    )


@router.callback_query(F.data == "adm:ann:cancel")
async def cb_ann_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return
    await state.clear()
    await callback.message.edit_text(
        "❌ Эълон бекор қилинди.",
        reply_markup=_BACK_TO_ANN_KB,
        parse_mode="HTML",
    )
    await callback.answer()


# ── History ───────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "adm:ann:history")
async def cb_ann_history(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Рухсат йўқ.", show_alert=True)
        return

    items = load_announcements()[:_HISTORY_PAGE]

    if not items:
        await callback.message.edit_text(
            "📜 <b>Эълонлар тарихи</b>\n\nЯнгиликлар ҳали мавжуд эмас.",
            reply_markup=_BACK_TO_ANN_KB,
            parse_mode="HTML",
        )
        await callback.answer()
        return

    lines = [f"📜 <b>Эълонлар тарихи</b>  (сўнгги {len(items)} та)\n"]
    for i, it in enumerate(items, 1):
        date    = it.get("date", "—")
        snippet = it.get("text", "")[:80]
        if len(it.get("text", "")) > 80:
            snippet += "…"
        lines.append(f"<b>{i}.</b> <i>{date}</i>\n{snippet}")
        if i < len(items):
            lines.append("━━━━━━━━━━━━━━━━━━━━")

    full_text = "\n".join(lines)

    # Telegram message limit — truncate if needed
    if len(full_text) > 3800:
        full_text = full_text[:3800] + "\n\n<i>…(давоми қисқартирилди)</i>"

    await callback.message.edit_text(
        full_text,
        reply_markup=_BACK_TO_ANN_KB,
        parse_mode="HTML",
    )
    await callback.answer()
