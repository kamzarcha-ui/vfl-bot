
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.draw_db import (
    draw_exists,
    load_draw,
    reset_draw,
    run_draw,
    run_draw_diagnostic,
    save_draw,
    validate_draw,
)
from bot.data.admin_ids import is_admin as _is_admin

router = Router()





# ── /draw ──────────────────────────────────────────────────────────────────────

@router.message(Command("draw"))
async def cmd_draw(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    if draw_exists():
        await message.answer("⚠️ Қуръа аллақачон ўтказилган.")
        return

    status_msg = await message.answer("🎱 Қуръа ўтказилмоқда...")

    try:
        data = run_draw()
        save_draw(data)
        await status_msg.edit_text(
            "🏆 <b>VFL Champions League</b>\n\n"
            "🎱 <b>Қуръа якунланди!</b>\n\n"
            "✅ 36 жамоа\n"
            "✅ 8 тур\n"
            "✅ 144 учрашув\n"
            "✅ Календар тайёр",
            parse_mode="HTML",
        )
    except RuntimeError as e:
        await status_msg.edit_text(f"❌ Қуръа муваффақиятсиз тугади: {e}")


# ── /resetdraw ─────────────────────────────────────────────────────────────────

_CONFIRM = "resetdraw:confirm"
_CANCEL  = "resetdraw:cancel"


@router.message(Command("resetdraw"))
async def cmd_resetdraw(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    if not draw_exists():
        await message.answer("⚠️ Ўчириш учун қуръа мавжуд эмас.")
        return

    await message.answer(
        "⚠️ <b>Қуръани ўчириш</b>\n\n"
        "Бу амал қуръа натижалари, барча учрашувлар ва "
        "яратилган календар маълумотларини <b>батамом ўчиради</b>.\n\n"
        "Давом этасизми?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Тасдиқлаш", callback_data=_CONFIRM),
            InlineKeyboardButton(text="❌ Бекор қилиш", callback_data=_CANCEL),
        ]]),
        parse_mode="HTML",
    )


@router.callback_query(F.data == _CONFIRM)
async def cb_reset_confirm(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⚠️ Рухсат йўқ.", show_alert=True)
        return
    reset_draw()
    await callback.message.edit_text("🗑 Қуръа ва учрашувлар ўчирилди.")
    await callback.answer()


@router.callback_query(F.data == _CANCEL)
async def cb_reset_cancel(callback: CallbackQuery) -> None:
    await callback.message.edit_text("❌ Ўчириш бекор қилинди.")
    await callback.answer()


# ── /drawdebug ─────────────────────────────────────────────────────────────────

@router.message(Command("drawdebug"))
async def cmd_drawdebug(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    status_msg = await message.answer("🔍 Диагностика ўтказилмоқда...")
    r = run_draw_diagnostic()

    lines: list[str] = ["🔍 <b>Draw Diagnostic Report</b>\n"]

    # Fixture generation
    fx_icon = "✅" if r.get("fixtures_ok") else "❌"
    lines.append(f"{fx_icon} Fixture generation: {r.get('fixtures_count', 0)} / 144")
    if r.get("fixtures_error"):
        lines.append(f"   ⚠️ {r['fixtures_error']}")

    # Home/away balance
    ha_icon = "✅" if r.get("ha_ok") else "❌"
    lines.append(f"{ha_icon} Home/Away balance")
    for e in r.get("ha_errors", [])[:5]:
        lines.append(f"   ❌ {e}")
    if len(r.get("ha_errors", [])) > 5:
        lines.append(f"   … and {len(r['ha_errors']) - 5} more")

    # Round scheduling
    rs_icon = "✅" if r.get("round_ok") else "❌"
    lines.append(f"{rs_icon} Round scheduling")
    for e in r.get("sched_errors", [])[:5]:
        lines.append(f"   ❌ {e}")

    # Validation
    v_errors = r.get("validation_errors", [])
    if not v_errors:
        lines.append("✅ Full validation passed")
    else:
        lines.append(f"❌ Validation errors: {len(v_errors)}")
        for e in v_errors[:5]:
            lines.append(f"   {e}")
        if len(v_errors) > 5:
            lines.append(f"   … and {len(v_errors) - 5} more")

    # Summary verdict
    all_ok = r.get("fixtures_ok") and r.get("ha_ok") and r.get("round_ok") and not v_errors
    lines.append("")
    lines.append("✅ Алгоритм ишлаяпти" if all_ok else "❌ Алгоритмда хато бор")

    await status_msg.edit_text("\n".join(lines), parse_mode="HTML")


# ── /drawstats ─────────────────────────────────────────────────────────────────

@router.message(Command("drawstats"))
async def cmd_drawstats(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    if not draw_exists():
        await message.answer("⚠️ Қуръа ҳали ўтказилмаган. /draw ни ишлатинг.")
        return

    data   = load_draw()
    errors = validate_draw(data)

    if not errors:
        await message.answer(
            "🎱 <b>Draw Validation</b>\n\n"
            "✅ 36 clubs\n"
            "✅ 288 club-opponents generated\n"
            "✅ 144 fixtures generated\n"
            "✅ 8 rounds\n"
            "✅ No duplicate opponents\n"
            "✅ No duplicate fixtures\n"
            "✅ Home/Away balanced\n"
            "✅ Round validation passed\n"
            "✅ Draw valid",
            parse_mode="HTML",
        )
    else:
        lines = "\n".join(errors)
        await message.answer(
            f"❌ <b>Draw Validation Failed</b>\n\n{lines}",
            parse_mode="HTML",
        )
