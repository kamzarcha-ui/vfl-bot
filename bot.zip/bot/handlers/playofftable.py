"""
/playofftable — full bracket display.

Before draw:  shows slot positions (e.g. "17-ўрин / 18-ўрин").
After draw:   shows actual club names.
After stages: shows winners advancing.
"""


from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from bot.data.admin_ids import is_admin as _is_admin

from bot.data.league_stage_db import (
    FIXED_BRACKET_ORDER,
    get_classification,
    get_playoff_bracket,
    get_stage_bracket,
    get_stage_winners,
)

router = Router()

STAGE_ORDER = ["playoff", "r16", "qf", "sf", "final"]
STAGE_LABELS = {
    "playoff": "🔥 Плей-офф",
    "r16":     "🏆 1/8 финал",
    "qf":      "🏆 1/4 финал",
    "sf":      "🏆 1/2 финал",
    "final":   "👑 Финал",
}


def _playoff_section() -> list[str]:
    lines: list[str] = ["🔥 <b>Плей-офф</b>\n"]
    bracket = get_playoff_bracket()

    if not bracket:
        # Show slot positions only
        for p1, p2 in FIXED_BRACKET_ORDER:
            lines.append(f"  {p1}-ўрин  🆚  {p2}-ўрин")
        return lines

    winners = get_stage_winners("playoff")
    winner_set = set(winners)

    for pair in bracket:
        t1 = pair["team1"]
        t2 = pair["team2"]
        p1 = pair["pos1"]
        p2 = pair["pos2"]

        if winners:
            if t1 in winner_set:
                line = f"  ✅ <b>{t1}</b>  🆚  {t2}"
            elif t2 in winner_set:
                line = f"  {t1}  🆚  ✅ <b>{t2}</b>"
            else:
                line = f"  {t1} ({p1})  🆚  {t2} ({p2})"
        else:
            line = f"  <b>{t1}</b> ({p1}-ўрин)  🆚  <b>{t2}</b> ({p2}-ўрин)"
        lines.append(line)

    return lines


def _stage_section(stage: str) -> list[str]:
    label = STAGE_LABELS[stage]
    lines: list[str] = [f"\n{label}\n"]

    if stage == "r16":
        bracket = get_stage_bracket("r16")
        if not bracket:
            # Show direct qualifiers vs TBD
            clf = get_classification()
            directs = clf.get("r16_direct", []) if clf else []
            for i in range(8):
                direct = directs[i] if i < len(directs) else f"Тўғридан-тўғри {i + 1}"
                lines.append(f"  {direct}  🆚  Плей-офф ғолиби {i + 1}")
            return lines
    else:
        bracket = get_stage_bracket(stage)
        if not bracket:
            lines.append("  ⏳ Ҳали аниқланмаган")
            return lines

    winners = get_stage_winners(stage)
    winner_set = set(winners)

    for pair in bracket:
        home = pair["home"]
        away = pair["away"]
        if winners:
            if home in winner_set:
                line = f"  ✅ <b>{home}</b>  🆚  {away}"
            elif away in winner_set:
                line = f"  {home}  🆚  ✅ <b>{away}</b>"
            else:
                line = f"  {home}  🆚  {away}"
        else:
            line = f"  <b>{home}</b>  🆚  <b>{away}</b>"
        lines.append(line)

    return lines


@router.message(Command("playofftable"))
async def cmd_playofftable(message: Message) -> None:
    lines: list[str] = ["🏆 <b>VFL Champions League — Плей-офф жадвали</b>\n", "━━━━━━━━━━━━━━━━━━━━\n"]

    lines += _playoff_section()

    for stage in ("r16", "qf", "sf", "final"):
        lines += _stage_section(stage)

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")

    await message.answer("\n".join(lines), parse_mode="HTML")
