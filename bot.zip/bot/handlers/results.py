from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from bot.data.db import get_result
from bot.data.matchday_db import get_matchday

router = Router()


def _fixture_id(match_day: int, idx: int) -> str:
    return f"md{match_day}_m{idx + 1}"


@router.message(Command("results"))
async def cmd_results(message: Message, *, user_id: int | None = None) -> None:
    md = get_matchday()

    if not md or not md.get("fixtures"):
        await message.answer("📊 Ҳозирча Match Day натижалари мавжуд эмас.")
        return

    match_day = md["match_day"]
    fixtures = md["fixtures"]

    processed = []

    for idx, fixture in enumerate(fixtures):
        match_id = _fixture_id(match_day, idx)
        result = get_result(match_id)

        if result and result.get("processed", False):
            processed.append((fixture, result))

    if not processed:
        await message.answer(
            f"📊 <b>Match Day #{match_day} натижалари</b>\n\n"
            "<i>Натижалар ҳали эълон қилинмаган.</i>",
            parse_mode="HTML",
        )
        return

    lines = [f"📊 <b>Match Day #{match_day} натижалари</b>\n"]

    for fixture, result in processed:
        lines.append(
            f"⚽ <b>{fixture['home']}</b> {result['score']} <b>{fixture['away']}</b>"
        )

    if len(processed) < len(fixtures):
        remaining = len(fixtures) - len(processed)
        lines.append(
            f"\n<i>Яна {remaining} та ўйин натижаси кутилмоқда.</i>"
        )

    await message.answer(
        "\n".join(lines),
        parse_mode="HTML",
    )


