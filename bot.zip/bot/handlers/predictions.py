"""
/predictions — view all participants' predictions after the deadline.

Access: read-only, post-deadline only.
Rival button: shown only when a legacy matchup exists for the requesting user.
"""

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.db import (
    get_fixtures,
    get_fixtures_by_ids,
    get_matchup_for_coach,
    get_predictions,
)
from bot.data.deadline_db import is_deadline_passed
from bot.data.matchday_db import get_matchday
from bot.data.matchday_state_db import is_matchday_active
from bot.data.teams_db import load_coaches

router = Router()

_PV_RIVAL = "pv:rival"
_PV_ALL   = "pv:all"
_PV_COACH = "pv:coach:"   # + telegram_id string
_PV_BACK  = "pv:back"    # back to main menu from rival / direct coach view
_PV_CLOSE = "pv:close"


# ── data helpers ──────────────────────────────────────────────────────────────

def _all_coaches() -> list[dict]:
    """All registered coaches sorted by name: [{name, team, tid}]."""
    result = []
    for name, info in load_coaches().items():
        tid = info.get("telegram_id")
        if tid:
            result.append({"name": name, "team": info.get("team", "—"), "tid": tid})
    return sorted(result, key=lambda c: c["name"])


def _coach_by_tid(tid_str: str) -> dict | None:
    """Reverse-lookup: telegram_id string → {name, team} or None."""
    for name, info in load_coaches().items():
        if info.get("telegram_id") == tid_str:
            return {"name": name, "team": info.get("team", "—")}
    return None


def _current_fixtures() -> list | None:
    """
    Fixtures to display predictions against.
    Matchday mode: md{n}_m1…m5 IDs.
    Legacy mode:   all fixtures for the latest round.
    """
    if is_matchday_active():
        md = get_matchday()
        if not md:
            return None
        n = md["match_day"]
        return [
            {"id": f"md{n}_m{i + 1}", "home": fx["home"], "away": fx["away"]}
            for i, fx in enumerate(md["fixtures"])
        ]
    all_fx = get_fixtures()
    if not all_fx:
        return None
    current_round = max(f["round"] for f in all_fx)
    return [f for f in all_fx if f["round"] == current_round]


def _rival_info(user_id: int) -> dict | None:
    """
    Return rival's {name, team, tid, fixtures} or None.
    A rival only exists in legacy matchup mode.
    """
    if is_matchday_active():
        return None
    all_fx = get_fixtures()
    if not all_fx:
        return None
    current_round = max(f["round"] for f in all_fx)
    matchup = get_matchup_for_coach(user_id, current_round)
    if not matchup:
        return None
    tid_str   = str(user_id)
    coach_a   = matchup.get("coach_a", "")
    coach_b   = matchup.get("coach_b", "")
    rival_tid = coach_b if tid_str == coach_a else coach_a
    if not rival_tid:
        return None
    coach = _coach_by_tid(rival_tid)
    if not coach:
        return None
    fixture_ids = matchup.get("fixture_ids", [])
    fixtures    = get_fixtures_by_ids(fixture_ids) if fixture_ids else []
    return {**coach, "tid": rival_tid, "fixtures": fixtures}


# ── formatting ────────────────────────────────────────────────────────────────

def _fmt_predictions(coach_name: str, team: str, fixtures: list, preds: dict) -> str:
    lines = [f"🏟 {team}", f"👤 {coach_name}\n", "━━━━━━━━━━━━━━━━━━━━"]
    for i, m in enumerate(fixtures):
        pred = preds.get(m["id"])
        if pred:
            lines.append(
                f"\n{i + 1}. {m['home']} vs {m['away']}\n"
                f"   📊 {pred['score']}\n"
                f"   👤 {pred['player']}"
            )
        else:
            lines.append(f"\n{i + 1}. {m['home']} vs {m['away']}\n   —")
    return "\n".join(lines)


# ── keyboards ─────────────────────────────────────────────────────────────────

def _main_kb(has_rival: bool) -> InlineKeyboardMarkup:
    rows = []
    if has_rival:
        rows.append([InlineKeyboardButton(text="👤 Рақибим", callback_data=_PV_RIVAL)])
    rows.append([InlineKeyboardButton(text="🌍 Барча иштирокчилар", callback_data=_PV_ALL)])
    rows.append([InlineKeyboardButton(text="❌ Бекор қилиш",        callback_data=_PV_CLOSE)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _coaches_kb(coaches: list[dict]) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(
            text=f"👤 {c['name']} ({c['team']})",
            callback_data=f"{_PV_COACH}{c['tid']}",
        )]
        for c in coaches
    ]
    rows.append([InlineKeyboardButton(text="⬅️ Орқага", callback_data=_PV_BACK)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _back_to_list_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Орқага", callback_data=_PV_ALL)
    ]])


def _back_to_main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Орқага", callback_data=_PV_BACK)
    ]])


# ── /predictions ──────────────────────────────────────────────────────────────

@router.message(Command("predictions"))
async def cmd_predictions(message: Message, user_id: int | None = None) -> None:
    if not is_deadline_passed():
        await message.answer(
            "🔒 Барча тахминлар дедлайн тугагандан кейин очилади."
        )
        return

    rival = _rival_info(user_id or message.from_user.id)
    await message.answer(
        "👥 <b>Барча тахминлар</b>\n\nКўриш учун танланг:",
        reply_markup=_main_kb(has_rival=rival is not None),
        parse_mode="HTML",
    )


# ── rival view ────────────────────────────────────────────────────────────────

@router.callback_query(F.data == _PV_RIVAL)
async def cb_pv_rival(callback: CallbackQuery) -> None:
    if not is_deadline_passed():
        await callback.answer("🔒 Дедлайн ҳали тугамаган.", show_alert=True)
        return

    rival = _rival_info(callback.from_user.id)
    if not rival:
        await callback.answer("⚠️ Рақиб топилмади.", show_alert=True)
        return

    try:
        preds = get_predictions(int(rival["tid"]))
    except (ValueError, TypeError):
        preds = {}

    text = (
        "⚔️ <b>Сизнинг рақибингиз</b>\n\n"
        + _fmt_predictions(rival["name"], rival["team"], rival["fixtures"], preds)
    )
    await callback.message.edit_text(
        text,
        reply_markup=_back_to_main_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── all participants list ─────────────────────────────────────────────────────

@router.callback_query(F.data == _PV_ALL)
async def cb_pv_all(callback: CallbackQuery) -> None:
    if not is_deadline_passed():
        await callback.answer("🔒 Дедлайн ҳали тугамаган.", show_alert=True)
        return

    coaches = _all_coaches()
    if not coaches:
        await callback.answer("⚠️ Иштирокчилар топилмади.", show_alert=True)
        return

    await callback.message.edit_text(
        "👥 <b>Барча иштирокчилар</b>\n\nТахминларини кўриш учун иштирокчини танланг:",
        reply_markup=_coaches_kb(coaches),
        parse_mode="HTML",
    )
    await callback.answer()


# ── single coach view ─────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith(_PV_COACH))
async def cb_pv_coach(callback: CallbackQuery) -> None:
    if not is_deadline_passed():
        await callback.answer("🔒 Дедлайн ҳали тугамаган.", show_alert=True)
        return

    tid_str = callback.data[len(_PV_COACH):]
    coach   = _coach_by_tid(tid_str)
    if not coach:
        await callback.answer("⚠️ Иштирокчи топилмади.", show_alert=True)
        return

    fixtures = _current_fixtures()
    if not fixtures:
        await callback.answer("⚠️ Матчлар топилмади.", show_alert=True)
        return

    try:
        preds = get_predictions(int(tid_str))
    except (ValueError, TypeError):
        preds = {}

    await callback.message.edit_text(
        _fmt_predictions(coach["name"], coach["team"], fixtures, preds),
        reply_markup=_back_to_list_kb(),
        parse_mode="HTML",
    )
    await callback.answer()


# ── back to main menu ─────────────────────────────────────────────────────────

@router.callback_query(F.data == _PV_BACK)
async def cb_pv_back(callback: CallbackQuery) -> None:
    rival = _rival_info(callback.from_user.id)
    await callback.message.edit_text(
        "👥 <b>Барча тахминлар</b>\n\nКўриш учун танланг:",
        reply_markup=_main_kb(has_rival=rival is not None),
        parse_mode="HTML",
    )
    await callback.answer()


# ── close ─────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == _PV_CLOSE)
async def cb_pv_close(callback: CallbackQuery) -> None:
    await callback.message.edit_text("❌ Ёпилди.")
    await callback.answer()
