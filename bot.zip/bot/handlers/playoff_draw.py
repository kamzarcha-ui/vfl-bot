from bot.data.admin_ids import is_admin as _is_admin
"""
/playoffdraw — run the fixed-bracket playoff draw ceremony (admin only).

The bracket is fixed (9v10, 11v12, … per spec).
The ceremony reveals team names at each position one pair at a time.
"""

import asyncio

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from bot.data.league_stage_db import (
    FIXED_BRACKET_ORDER,
    build_standings_from_club_stats,
    classification_done,
    playoff_bracket_done,
    save_playoff_bracket,
)
from bot.data.matchday_db import get_current_match_day_number, is_matchday_closed
from bot.data.playoff_draw_db import (
    draw_exists,
    get_playoff_draw,
    reset_playoff_draw,
    run_draw,
)
from bot.data.teams_db import load_teams

router = Router()





async def _broadcast(bot, text: str) -> None:
    teams = load_teams()
    for info in teams.values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), text, parse_mode="HTML")
        except Exception:
            pass


# ── /playoffdraw ───────────────────────────────────────────────────────────────

@router.message(Command("playoffdraw"))
async def cmd_playoffdraw(message: Message, *, user_id: int | None = None) -> None:
    if not _is_admin(user_id if user_id is not None else message.from_user.id):
        return

    if draw_exists():
        await message.answer(
            "⚠️ Плей-офф қуръаси аллақачон ўтказилган.\n\n"
            "Қайта ўтказиш учун аввал /resetplayoffdraw командасини ишлатинг."
        )
        return

    # ── Bracket safety: league_stage.json bracket must not already exist ──────
    if playoff_bracket_done():
        await message.answer(
            "⛔ Плей-офф қуръаси аллақачон ўтказилган.\n\n"
            "Мавсум давомида қуръа фақат бир марта ўтказилади."
        )
        return

    # ── Guard 1: MD8 must be completed and closed ─────────────────────────────
    md_number = get_current_match_day_number()
    md_closed  = is_matchday_closed()
    # advance_matchday() increments the counter to 9 after MD8 closes, clearing
    # the "closed" flag — so both states must be accepted:
    #   a) md == 8 and closed=True  (just closed, not yet advanced)
    #   b) md >= 9                  (advanced past MD8)
    league_stage_done = (md_number == 8 and md_closed) or (md_number >= 9)
    if not league_stage_done:
        await message.answer(
            "⛔ Плей-офф қуръасини ўтказиш мумкин эмас.\n\n"
            "Лига босқичи ҳали якунланмаган.\n\n"
            "Аввал 8-турни якунланг."
        )
        return

    # ── Guard 2: Classification must have been generated ──────────────────────
    if not classification_done():
        await message.answer(
            "⛔ Плей-офф қуръасини ўтказиш мумкин эмас.\n\n"
            "Классификация ҳали тайёрланмаган.\n\n"
            "Аввал 8-турни якунланг ва классификацияни сақланг."
        )
        return

    # ── Guard 3: 24 qualified teams must exist in the standings ───────────────
    standings = build_standings_from_club_stats()
    if len(standings) < 24:
        await message.answer(
            "⛔ Плей-офф қуръасини ўтказиш мумкин эмас.\n\n"
            f"Жадвалда {len(standings)} та жамоа мавжуд — камида 24 та бўлиши керак.\n\n"
            "Лига босқичи тугалланган бўлиши керак.",
            parse_mode="HTML",
        )
        return

    status_msg = await message.answer("🎱 Қуръа бошланмоқда...")
    await asyncio.sleep(1)

    try:
        pairings = run_draw(standings)
        # Also save to league_stage_db for bracket use
        save_playoff_bracket(standings)
    except ValueError as e:
        await status_msg.edit_text(f"❌ Хато: {e}")
        return

    # ── Build ceremony message ────────────────────────────────────────────────
    by_pos: dict[int, str] = {p["upper_pos"]: p["upper_team"] for p in pairings}
    by_pos.update({p["lower_pos"]: p["lower_team"] for p in pairings})

    ceremony_lines: list[str] = [
        "🎱 <b>Плей-офф Қуръаси</b>\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
    ]

    for p1, p2 in FIXED_BRACKET_ORDER:
        team1 = by_pos.get(p1, f"{p1}-ўрин")
        team2 = by_pos.get(p2, f"{p2}-ўрин")
        ceremony_lines += [
            f"🎱 <b>{p1}-ўрин:</b>",
            f"<b>{team1}</b>",
            "",
            f"🎱 <b>{p2}-ўрин:</b>",
            f"<b>{team2}</b>",
            "",
            f"✅ <b>{team1}  vs  {team2}</b>",
            "━━━━━━━━━━━━━━━━━━━━\n",
        ]

    await status_msg.edit_text("\n".join(ceremony_lines), parse_mode="HTML")

    # ── Final summary ─────────────────────────────────────────────────────────
    summary_lines: list[str] = [
        "🔥 <b>Плей-офф жуфтликлари</b>\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
    ]
    for pair in pairings:
        summary_lines.append(
            f"<b>{pair['upper_pos']}-ўрин</b>  🆚  <b>{pair['lower_pos']}-ўрин</b>\n"
            f"<i>{pair['upper_team']}  —  {pair['lower_team']}</i>"
        )
    summary_lines += [
        "\n━━━━━━━━━━━━━━━━━━━━",
        "✅ <b>Қуръа муваффақиятли якунланди!</b>",
    ]
    summary_text = "\n".join(summary_lines)
    await message.answer(summary_text, parse_mode="HTML")

    # ── Road to the Final ─────────────────────────────────────────────────────
    # Each group: two playoff pairs whose winners will meet one of the top-8 seeds.
    # Groups are fixed by the UEFA-style bracket spec.
    ROAD_GROUPS = [
        # (seed_range_uz,  pair_upper,  pair_lower)
        ("1 ёки 2",  (17, 18), (15, 16)),
        ("7 ёки 8",  (23, 24), (9,  10)),
        ("5 ёки 6",  (21, 22), (11, 12)),
        ("3 ёки 4",  (19, 20), (13, 14)),
    ]

    road_lines: list[str] = ["🏆 <b>ФИНАЛГА ЙЎЛ</b>\n"]
    for seed_label, (p1, p2), (p3, p4) in ROAD_GROUPS:
        t1 = by_pos.get(p1, f"{p1}-ўрин")
        t2 = by_pos.get(p2, f"{p2}-ўрин")
        t3 = by_pos.get(p3, f"{p3}-ўрин")
        t4 = by_pos.get(p4, f"{p4}-ўрин")
        road_lines += [
            f"<b>{t1}</b> — <b>{t2}</b>  ┐",
            f"<b>{t3}</b> — <b>{t4}</b>  ┘ → <i>{seed_label}-ўрин эгасига</i>",
            "━━━━━━━━━━━━━━━━━━━━",
            "",
        ]
    await message.answer("\n".join(road_lines).rstrip(), parse_mode="HTML")

    # ── Possible opponents — club names from actual playoff bracket ────────────
    # Sequential display 1–8 (league position order).
    # Pair assignments follow UEFA bracket; only display order changes.
    # Each entry: (direct_idx, league_pos, pair_id_a, pair_id_b)
    #   direct_idx: 0-based index into r16_direct [pos1…pos8]
    #   pair_id:    index into FIXED_BRACKET_ORDER
    _DISPLAY_ORDER: list[tuple[int, int, int, int]] = [
        (0, 1, 0, 1),   # pos1 → pairs 0(17v18), 1(15v16)
        (1, 2, 0, 1),   # pos2 → pairs 0(17v18), 1(15v16)
        (2, 3, 6, 7),   # pos3 → pairs 6(19v20), 7(13v14)
        (3, 4, 6, 7),   # pos4 → pairs 6(19v20), 7(13v14)
        (4, 5, 4, 5),   # pos5 → pairs 4(21v22), 5(11v12)
        (5, 6, 4, 5),   # pos6 → pairs 4(21v22), 5(11v12)
        (6, 7, 2, 3),   # pos7 → pairs 2(23v24), 3(9v10)
        (7, 8, 2, 3),   # pos8 → pairs 2(23v24), 3(9v10)
    ]
    _NUM_EMOJIS_8 = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣"]

    from bot.data.league_stage_db import get_classification, get_playoff_bracket
    _clf     = get_classification() or {}
    _directs = _clf.get("r16_direct", [])      # [team_pos1, …, team_pos8]
    _bracket = get_playoff_bracket()            # [{pair_id,team1,team2}, …]
    _bkt     = {p["pair_id"]: p for p in _bracket}

    rivals_lines: list[str] = ["🎯 <b>ЭҲТИМОЛИЙ РАҚИБЛАР</b>\n"]

    for emoji, (di, pos, pa, pb) in zip(_NUM_EMOJIS_8, _DISPLAY_ORDER):
        seed_name = _directs[di] if di < len(_directs) else f"{pos}-ўрин"
        pair_a = _bkt.get(pa, {})
        pair_b = _bkt.get(pb, {})
        ta1 = pair_a.get("team1", "?");  ta2 = pair_a.get("team2", "?")
        tb1 = pair_b.get("team1", "?");  tb2 = pair_b.get("team2", "?")
        rivals_lines += [
            f"{emoji} <b>{seed_name} ({pos})</b>",
            "",
            f"→ <i>{ta1} / {ta2}</i>",
            "ёки",
            f"<i>{tb1} / {tb2}</i>",
            "",
            "━━━━━━━━━━━━━━━━━━━━",
            "",
        ]

    await message.answer("\n".join(rivals_lines).rstrip(), parse_mode="HTML")

    # ── Store playoff draw news item ──────────────────────────────────────────
    try:
        from bot.data.playoff_engine import generate_draw_news_item
        from bot.data.news_db import prepend_news_items
        prepend_news_items([generate_draw_news_item(pairings)])
    except Exception:
        pass

    # ── Broadcast draw result to all participants ─────────────────────────────
    notify_lines: list[str] = ["🔥 <b>Плей-офф қуръаси якунланди!</b>\n"]
    for pair in pairings:
        notify_lines.append(
            f"• <b>{pair['upper_team']}</b>  🆚  <b>{pair['lower_team']}</b>"
        )
    notify_lines.append("\n🎯 Плей-офф учрашувларини кутинг!")
    await _broadcast(message.bot, "\n".join(notify_lines))


# ── /resetplayoffdraw ──────────────────────────────────────────────────────────

_RPD_CONFIRM = "resetplayoffdraw:confirm"
_RPD_CANCEL  = "resetplayoffdraw:cancel"


@router.message(Command("resetplayoffdraw"))
async def cmd_resetplayoffdraw(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    if not draw_exists():
        await message.answer("⚠️ Плей-офф қуръаси мавжуд эмас.")
        return

    await message.answer(
        "⚠️ <b>Плей-офф қуръасини ўчириш</b>\n\n"
        "Плей-офф қуръасини ўчиришни тасдиқлайсизми?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Ҳа",  callback_data=_RPD_CONFIRM),
            InlineKeyboardButton(text="❌ Йўқ", callback_data=_RPD_CANCEL),
        ]]),
        parse_mode="HTML",
    )


@router.callback_query(F.data == _RPD_CONFIRM)
async def cb_resetplayoffdraw_confirm(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⚠️ Рухсат йўқ.", show_alert=True)
        return
    reset_playoff_draw()
    await callback.message.edit_text("🗑 Плей-офф қуръаси ўчирилди.")
    await callback.answer()


@router.callback_query(F.data == _RPD_CANCEL)
async def cb_resetplayoffdraw_cancel(callback: CallbackQuery) -> None:
    await callback.message.edit_text("❌ Ўчириш бекор қилинди.")
    await callback.answer()


# ── /playoffdrawstats ──────────────────────────────────────────────────────────

@router.message(Command("playoffdrawstats"))
async def cmd_playoffdrawstats(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        return

    if not draw_exists():
        await message.answer("⚠️ Плей-офф қуръаси ҳали ўтказилмаган.")
        return

    data = get_playoff_draw()
    ts   = data.get("timestamp", "—") if data else "—"
    pairings = data.get("pairings", []) if data else []

    await message.answer(
        "📊 <b>Плей-офф Қуръа Статистикаси</b>\n\n"
        f"✅ {len(pairings)} жуфтлик шакллантирилди\n"
        "✅ Фиксирланган жадвал (белгиланган жуфтликлар)\n"
        "✅ Лига таснифи асосида\n\n"
        f"🕐 <code>{ts}</code>",
        parse_mode="HTML",
    )
