"""
/vflstudio — VFL Studio dashboard (replaces /vfltv).

League mode (MD 1–8):  shows league table focus, playoff line, danger zone.
Playoff mode (MD 9–17): shows current stage bracket, remaining clubs, scorer/predictor races.

No broadcasts. No new statistics. Display only.
"""

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


# ── Playoff stage map ─────────────────────────────────────────────────────────

_PLAYOFF_MD_STAGE: dict[int, tuple[str, str]] = {
    9:  ("playoff", "🔥 Плей-офф"),
    10: ("playoff", "🔥 Плей-офф"),
    11: ("r16",     "🎟 1/8 Финал"),
    12: ("r16",     "🎟 1/8 Финал"),
    13: ("qf",      "🏅 1/4 Финал"),
    14: ("qf",      "🏅 1/4 Финал"),
    15: ("sf",      "🥉 1/2 Финал"),
    16: ("sf",      "🥉 1/2 Финал"),
    17: ("final",   "👑 Финал"),
}


# ── Shared helpers ────────────────────────────────────────────────────────────

def _get_top_scorer() -> tuple[str, str, int] | None:
    from bot.data.teams_db import load_teams
    best = 0
    p_name = t_name = ""
    for team, info in load_teams().items():
        for p in info.get("players", []):
            if isinstance(p, dict) and p.get("goals", 0) > best:
                best   = p["goals"]
                p_name = p.get("name", "")
                t_name = team
    if not p_name or best == 0:
        return None
    return p_name, t_name, best


def _get_golden_predictor() -> tuple[str, int, int] | None:
    from bot.data.teams_db import load_coaches
    best_mg = best_ep = 0
    best_name = ""
    for cname, cinfo in load_coaches().items():
        mg = cinfo.get("matchday_goals", 0)
        ep = cinfo.get("exact_predictions", 0)
        if mg > best_mg or (mg == best_mg and ep > best_ep):
            best_mg   = mg
            best_ep   = ep
            best_name = cname
    if not best_name or (best_mg == 0 and best_ep == 0):
        return None
    return best_name, best_mg, best_ep


def _get_latest_sensation() -> str | None:
    from bot.data.sensations_db import load_sensations
    items = load_sensations()
    return items[0].get("headline", "") if items else None


def _get_latest_hof_record() -> str | None:
    from bot.data.hall_of_fame_db import get_hof_history
    history = get_hof_history()
    if not history:
        return None
    entry  = history[-1]
    label  = entry.get("category_label", "")
    holder = entry.get("new_holder", "")
    value  = entry.get("new_value", "")
    rtype  = entry.get("type", "record")
    icon   = "😂" if rtype == "anti_record" else "🔥"
    return f"{icon} {label}: <b>{holder}</b> ({value})"


def _get_latest_news() -> str | None:
    from bot.data.news_db import load_news
    items = load_news()
    return items[0].get("headline", "") if items else None


def _get_latest_commentary() -> tuple[str, str] | None:
    from bot.data.commentary_db import load_commentary
    items = load_commentary()
    if not items:
        return None
    it = items[0]
    return it.get("title", ""), it.get("type", "preview")


def _get_md_stats(md_num: int) -> dict | None:
    from bot.data.db import get_duel_results, get_result, get_all_predictions_for_match
    duels = get_duel_results(md_num)
    if not duels:
        return None
    total_goals = wins = draws = biggest_win = 0
    biggest_home = biggest_away = ""
    bh = ba = 0
    for d in duels:
        gh, ga = d["goals_home"], d["goals_away"]
        total_goals += gh + ga
        margin = abs(gh - ga)
        if gh == ga:
            draws += 1
        else:
            wins += 1
            if margin > biggest_win:
                biggest_win  = margin
                biggest_home = d["home"] if gh > ga else d["away"]
                biggest_away = d["away"] if gh > ga else d["home"]
                bh           = max(gh, ga)
                ba           = min(gh, ga)
    exact_count = 0
    for i in range(5):
        match_id  = f"md{md_num}_m{i + 1}"
        result    = get_result(match_id)
        if not result:
            continue
        preds = get_all_predictions_for_match(match_id)
        for pred in preds.values():
            if pred.get("score") == result["score"]:
                exact_count += 1
    return {
        "total_goals":  total_goals,
        "exact":        exact_count,
        "wins":         wins,
        "draws":        draws,
        "biggest_home": biggest_home,
        "biggest_away": biggest_away,
        "biggest_bh":   bh,
        "biggest_ba":   ba,
    }


def _shared_tail_sections(lines: list[str], md_num_int: int | None) -> None:
    """Appends: sensation, HOF, news, commentary, MD stats."""
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🔥 <b>СЎНГГИ СЕНСАЦИЯ</b>\n")
    sens = _get_latest_sensation()
    lines.append(sens if sens else "Ҳали сенсация йўқ.")

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🏛 <b>СЎНГГИ РЕКОРД</b>\n")
    hof = _get_latest_hof_record()
    lines.append(hof if hof else "Рекордлар тарихи ҳали бошланмаган.")

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("📰 <b>СЎНГГИ ЯНГИЛИК</b>\n")
    news_h = _get_latest_news()
    lines.append(news_h if news_h else "Янгиликлар ҳали мавжуд эмас.")

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🎙 <b>СЎНГГИ ШАРҲ</b>\n")
    comm = _get_latest_commentary()
    if comm:
        title, ctype = comm
        icon = "🎙 Превью" if ctype in ("preview", "playoff_studio") else "📋 Шарҳ"
        lines.append(f"{icon}: <b>{title}</b>")
        lines.append("/commentary — тўлиқ матн")
    else:
        lines.append("Шарҳлар ҳали мавжуд эмас.")

    # MD Stats
    if md_num_int is not None:
        lines.append(f"\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"📊 <b>MATCH DAY {md_num_int} СТАТИСТИКАСИ</b>\n")
        md_stats = _get_md_stats(md_num_int)
        if md_stats:
            lines.append(f"⚽ Жами голлар: <b>{md_stats['total_goals']}</b>")
            lines.append(f"🎯 Аниқ тахминлар: <b>{md_stats['exact']}</b>")
            lines.append(f"🏆 Ғалабалар: <b>{md_stats['wins']}</b>")
            lines.append(f"🤝 Дуранглар: <b>{md_stats['draws']}</b>")
            if md_stats["biggest_home"]:
                lines.append(
                    f"💥 Энг йирик ғалаба: "
                    f"<b>{md_stats['biggest_home']}</b> "
                    f"{md_stats['biggest_bh']}–{md_stats['biggest_ba']} "
                    f"<b>{md_stats['biggest_away']}</b>"
                )
        else:
            lines.append("Match Day ҳали якунланмаган.")
    else:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("📊 <b>MATCH DAY СТАТИСТИКАСИ</b>\n")
        lines.append("Match Day ҳали яратилмаган.")


# ── League mode (MD 1–8) ──────────────────────────────────────────────────────

def _build_league_text(season: int, md_num, standings: list[dict]) -> str:
    from bot.data.league_stage_db import build_standings_from_club_stats

    lines: list[str] = [
        "📺 <b>VFL STUDIO</b>\n",
        f"🏆 <b>Мавсум {season}</b>",
        f"📊 <b>Match Day {md_num}</b>",
    ]

    # League Leader
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🥇 <b>ЛИГА ЛИДЕРИ</b>\n")
    if standings:
        r = standings[0]
        lines.append(f"<b>{r['team']}</b> — {r['pts']} очко")
    else:
        lines.append("Маълумот мавжуд эмас.")

    # Top Scorer
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("⚽ <b>ТОП БОМБАРДИР</b>\n")
    scorer = _get_top_scorer()
    if scorer:
        player, team, goals = scorer
        lines.append(f"<b>{player}</b> ({team}) — {goals} гол")
    else:
        lines.append("Мавсум голлари ҳали киритилмаган.")

    # Golden Predictor
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🎯 <b>GOLDEN PREDICTOR</b>\n")
    gp = _get_golden_predictor()
    if gp:
        coach, mg, ep = gp
        lines.append(f"<b>{coach}</b> — {mg} гол • {ep} аниқ тахмин")
    else:
        lines.append("Мавсум тахминлари ҳали бошланмаган.")

    # Shared tail (sensation, HOF, news, commentary, MD stats)
    md_int = None
    try:
        md_int = int(md_num)
    except (TypeError, ValueError):
        pass
    _shared_tail_sections(lines, md_int)

    # Playoff Line (if ≥ 25 teams)
    if standings and len(standings) >= 25:
        pos_map = {s["pos"]: s["team"] for s in standings}
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🎟 <b>КВАЛИФИКАЦИЯ ЧЕГАРАСИ</b>\n")
        lines.append(f"<b>8.</b> {pos_map.get(8, '—')}")
        lines.append("━━━━━━━ 1/8 финал чегараси ━━━━━━━")
        lines.append(f"<b>9.</b> {pos_map.get(9, '—')}\n")
        lines.append(f"<b>24.</b> {pos_map.get(24, '—')}")
        lines.append("━━━━━━━ Плей-офф чегараси ━━━━━━━")
        lines.append(f"<b>25.</b> {pos_map.get(25, '—')}")

    # Danger Zone
    bottom = [s for s in standings if s.get("pos", 0) >= 25]
    if bottom:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("⚠️ <b>ХАВФЛИ ЗОНА</b>\n")
        for s in bottom[:3]:
            lines.append(f"📉 <b>{s['team']}</b> — {s['pos']}-ўрин • {s['pts']} очко")

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(lines)


# ── Playoff mode (MD 9–17) ────────────────────────────────────────────────────

def _get_bracket_pairs(stage: str) -> list[dict]:
    from bot.data.league_stage_db import get_stage_bracket, get_playoff_bracket
    if stage == "playoff":
        raw = get_playoff_bracket() or []
        return [{"home": p.get("team1",""), "away": p.get("team2","")} for p in raw]
    return get_stage_bracket(stage) or []


def _build_playoff_text(season: int, md_num_int: int, standings: list[dict]) -> str:
    stage_key, stage_label = _PLAYOFF_MD_STAGE.get(md_num_int, ("playoff", "🔥 Плей-офф"))
    pairs   = _get_bracket_pairs(stage_key)
    is_leg2 = md_num_int % 2 == 0 and md_num_int != 17

    from bot.data.league_stage_db import get_stage_winners
    winners = get_stage_winners(stage_key) or []

    lines: list[str] = [
        "📺 <b>VFL STUDIO</b>  🔥 <b>PLAYOFF MODE</b>\n",
        f"🏆 <b>Мавсум {season}</b>",
        f"📊 <b>Match Day #{md_num_int}</b>",
        f"⚔️ <b>Босқич: {stage_label}</b>  "
        + ("(2-ўйин)" if is_leg2 else "(1-ўйин)"),
    ]

    # Current stage bracket
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🏟 <b>ЖОРИЙ ЖУФТЛИКЛАР</b>\n")
    if pairs:
        for i, pair in enumerate(pairs, 1):
            h = pair.get("home", pair.get("team1", "—"))
            a = pair.get("away", pair.get("team2", "—"))
            w_icon = ""
            if winners:
                if h in winners:
                    w_icon = " ✅"
                elif a in winners:
                    w_icon = " — " + a + " ✅"
                    a      = a  # already set
            lines.append(f"{i}. <b>{h}</b> 🆚 <b>{a}</b>{w_icon}")
    else:
        lines.append("Жадвал маълумоти мавжуд эмас.")

    # Remaining clubs count
    if pairs:
        remaining = len(pairs) * 2
        lines.append(f"\n🏆 <b>Қолган жамоалар:</b> {remaining} та")

    # Top Scorer Race
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("⚽ <b>ТОП БОМБАРДИР ПОЙГАСИ</b>\n")
    scorer = _get_top_scorer()
    if scorer:
        player, team, goals = scorer
        lines.append(f"🥇 <b>{player}</b> ({team}) — {goals} гол")
    else:
        lines.append("Ҳали ҳисобланмаган.")

    # Golden Predictor Race
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🎯 <b>GOLDEN PREDICTOR ПОЙГАСИ</b>\n")
    gp = _get_golden_predictor()
    if gp:
        coach, mg, ep = gp
        lines.append(f"🥇 <b>{coach}</b> — {mg} гол • {ep} аниқ тахмин")
    else:
        lines.append("Ҳали ҳисобланмаган.")

    # Shared tail (sensation, HOF, news, commentary, MD stats)
    _shared_tail_sections(lines, md_num_int)

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(lines)


# ── Main builder ──────────────────────────────────────────────────────────────

def _build_studio_text() -> str:
    from bot.data.league_stage_db import build_standings_from_club_stats
    from bot.data.season_db import get_current_season
    from bot.data.matchday_db import get_matchday

    season    = get_current_season()
    md_info   = get_matchday()
    md_num    = md_info.get("match_day", "—") if md_info else "—"
    standings = build_standings_from_club_stats()

    # Determine mode
    try:
        md_int = int(md_num)
    except (TypeError, ValueError):
        md_int = 0

    if md_int >= 9:
        return _build_playoff_text(season, md_int, standings)
    return _build_league_text(season, md_num, standings)


# ── Handlers ──────────────────────────────────────────────────────────────────

@router.message(Command("vflstudio"))
async def cmd_vflstudio(message: Message, *, user_id: int | None = None) -> None:
    await message.answer(_build_studio_text(), parse_mode="HTML")


@router.message(Command("vfltv"))
async def cmd_vfltv_redirect(message: Message) -> None:
    """Backward-compatibility alias."""
    await message.answer(_build_studio_text(), parse_mode="HTML")
