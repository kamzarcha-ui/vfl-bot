from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("records"))
async def cmd_records(message: Message, *, user_id: int | None = None) -> None:
    from bot.data.season_records_db import compute_season_records
    from bot.data.season_db import get_current_season

    season = get_current_season()
    rec    = compute_season_records(season)

    team   = rec.get("team",   {})
    coach  = rec.get("coach",  {})
    player = rec.get("player", {})
    match  = rec.get("match",  {})

    has_data = any([team, coach, player, match])

    if not has_data:
        await message.answer(
            f"📊 <b>Мавсум {season} — Рекордлар</b>\n\n"
            "Ҳозирча маълумотлар йўқ.\n\n"
            "Биринчи Match Day якунлангандан кейин рекордлар автоматик ҳисобланади.",
            parse_mode="HTML",
        )
        return

    lines: list[str] = [f"📊 <b>МАВСУМ {season} — РЕКОРДЛАР</b>"]

    # ── Team Records ──────────────────────────────────────────────────────────
    team_rows = [
        ("most_points",    "🏟", "Энг кўп очко"),
        ("most_wins",      "🏆", "Энг кўп ғалаба"),
        ("most_goals",     "⚽", "Энг кўп гол забити"),
        ("fewest_conceded","🛡", "Энг кам гол ўтказди"),
        ("win_streak",     "🔥", "Энг узун ғалаба серияси"),
        ("winless_run",    "❄️", "Энг узун ғалабасиз серия"),
        ("most_defeats",   "💔", "Энг кўп мағлубият"),
        ("lose_streak",    "🚫", "Энг узун мағлубият серияси"),
    ]
    team_lines = _section(team, team_rows)
    if team_lines:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🏟 <b>ЖАМОА РЕКОРДЛАРИ</b>\n")
        lines.extend(team_lines)

    # ── Match Records ─────────────────────────────────────────────────────────
    match_rows = [
        ("biggest_win",     "💥", "Энг йирик ғалаба"),
        ("biggest_defeat",  "💔", "Энг йирик мағлубият"),
        ("highest_scoring", "⚽", "Энг сергол ўйин"),
    ]
    match_lines = _section(match, match_rows)
    if match_lines:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🎮 <b>ЎЙИН РЕКОРДЛАРИ</b>\n")
        lines.extend(match_lines)

    # ── Coach Records ─────────────────────────────────────────────────────────
    coach_rows = [
        ("most_exact", "🎯", "Энг кўп аниқ ҳисоб"),
        ("most_goals", "⚽", "Энг кўп гол топди (башорат)"),
    ]
    coach_lines = _section(coach, coach_rows)
    if coach_lines:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🧠 <b>МУРАББИЙ РЕКОРДЛАРИ</b>\n")
        lines.extend(coach_lines)

    # ── Player Records ────────────────────────────────────────────────────────
    player_rows = [
        ("top_scorer", "⚽", "Мавсум бомбардири"),
    ]
    player_lines = _section(player, player_rows)
    if player_lines:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🌟 <b>ЎЙИНЧИ РЕКОРДЛАРИ</b>\n")
        lines.extend(player_lines)

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append(f"<i>🏛 Барча замон рекордлари → /halloffame</i>")

    text = "\n".join(lines)
    if len(text) <= 4096:
        await message.answer(text, parse_mode="HTML")
    else:
        # Split at match records boundary
        mid = len(lines) // 2
        await message.answer("\n".join(lines[:mid]), parse_mode="HTML")
        await message.answer("\n".join(lines[mid:]), parse_mode="HTML")


def _section(data: dict, rows: list[tuple]) -> list[str]:
    """Render a list of (key, icon, label) rows from a records dict."""
    out = []
    for key, icon, label in rows:
        entry = data.get(key)
        if not entry:
            continue
        holder = entry.get("holder", "—")
        detail = entry.get("detail", "")
        out.append(f"{icon} <b>{label}</b>")
        out.append(f"   👤 {holder}   {detail}")
    return out
