import asyncio
import logging
import os

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from bot.data.db import seed_default_data
from bot.handlers.notifications import notification_loop
from bot.handlers import (
    start,
    rules,
    table,
    tour,
    predict,
    register,
    setresult,
    stats,
    clubtable,
    topscorers,
    goldenpredictor,
    teamoftheround,
    addmatchup,
)
from bot.handlers import tournament_format, season_calendar, fixtures, results, regulation, draw, dates, deadline, playoff_draw, setfixtures, matchday_control, editfixtures, predictions, setmdresult, admin, editdate, editmdresult, participants, closematchday, tourresults, backfill_md1, playoffteams, playofftable
from bot.handlers import history, champions, awards, halloffame, clubranking, coachranking, news, commentary, vfltv, records, sensations
from bot.handlers import finishseason
from bot.handlers import deleteseason, removeparticipant, deletematchday
from bot.handlers import announcement, releaseteam, replaceteam


async def main() -> None:
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN environment variable is not set")

    seed_default_data()

    bot = Bot(token=token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    dp.include_router(start.router)
    dp.include_router(rules.router)
    dp.include_router(tournament_format.router)
    dp.include_router(season_calendar.router)
    dp.include_router(fixtures.router)
    dp.include_router(results.router)
    dp.include_router(table.router)
    dp.include_router(tour.router)
    dp.include_router(predict.router)
    dp.include_router(register.router)
    dp.include_router(setresult.router)
    dp.include_router(stats.router)
    dp.include_router(clubtable.router)
    dp.include_router(topscorers.router)
    dp.include_router(goldenpredictor.router)
    dp.include_router(teamoftheround.router)
    dp.include_router(addmatchup.router)
    dp.include_router(regulation.router)
    dp.include_router(draw.router)
    dp.include_router(dates.router)
    dp.include_router(deadline.router)
    dp.include_router(playoff_draw.router)
    dp.include_router(setfixtures.router)
    dp.include_router(matchday_control.router)
    dp.include_router(editfixtures.router)
    dp.include_router(predictions.router)
    dp.include_router(setmdresult.router)
    dp.include_router(editdate.router)
    dp.include_router(editmdresult.router)
    dp.include_router(participants.router)
    dp.include_router(closematchday.router)
    dp.include_router(tourresults.router)
    dp.include_router(backfill_md1.router)
    dp.include_router(playoffteams.router)
    dp.include_router(playofftable.router)
    dp.include_router(history.router)
    dp.include_router(champions.router)
    dp.include_router(awards.router)
    dp.include_router(halloffame.router)
    dp.include_router(clubranking.router)
    dp.include_router(coachranking.router)
    dp.include_router(news.router)
    dp.include_router(commentary.router)
    dp.include_router(vfltv.router)
    dp.include_router(records.router)
    dp.include_router(sensations.router)
    dp.include_router(deleteseason.router)
    dp.include_router(removeparticipant.router)
    dp.include_router(deletematchday.router)
    dp.include_router(announcement.router)
    dp.include_router(releaseteam.router)
    dp.include_router(replaceteam.router)
    dp.include_router(finishseason.router)
    dp.include_router(admin.router)

    logging.basicConfig(level=logging.INFO)
    logging.info("VFL Champions League bot starting…")

    asyncio.create_task(notification_loop(bot))
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
