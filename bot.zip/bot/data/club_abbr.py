"""
Shared club-abbreviation utility.

Used by /topscorers and /goldenpredictor to display consistent 3-char club codes.

Public API:
    abbr(club_name: str) -> str   — returns 3-char uppercase code
"""

_KNOWN: dict[str, str] = {
    "inter":                "INT",
    "inter milan":          "INT",
    "rangers":              "RAN",
    "rangers fc":           "RAN",
    "barcelona":            "BAR",
    "real madrid":          "RMA",
    "manchester city":      "MCI",
    "manchester united":    "MUN",
    "bayern munich":        "BAY",
    "borussia dortmund":    "DOR",
    "paris saint-germain":  "PSG",
    "psg":                  "PSG",
    "atletico madrid":      "ATM",
    "juventus":             "JUV",
    "liverpool":            "LIV",
    "chelsea":              "CHE",
    "arsenal":              "ARS",
    "tottenham":            "TOT",
    "tottenham hotspur":    "TOT",
    "ac milan":             "MIL",
    "milan":                "MIL",
    "as roma":              "ROM",
    "roma":                 "ROM",
    "napoli":               "NAP",
    "porto":                "POR",
    "benfica":              "BEN",
    "ajax":                 "AJX",
    "psv":                  "PSV",
    "psv eindhoven":        "PSV",
    "sevilla":              "SEV",
    "villarreal":           "VIL",
    "valencia":             "VAL",
    "celtic":               "CEL",
    "newcastle":            "NEW",
    "newcastle united":     "NEW",
    "rb leipzig":           "RBL",
    "bayer leverkusen":     "LEV",
    "sporting cp":          "SPO",
    "sporting":             "SPO",
    "marseille":            "MAR",
    "lyon":                 "LYO",
    "lazio":                "LAZ",
    "atalanta":             "ATA",
    "fiorentina":           "FIO",
    "shakhtar":             "SHA",
    "shakhtar donetsk":     "SHA",
    "galatasaray":          "GAL",
    "fenerbahce":           "FEN",
    "besiktas":             "BES",
    "red bull salzburg":    "SAL",
    "salzburg":             "SAL",
    "club brugge":          "BRU",
    "brugge":               "BRU",
    "anderlecht":           "AND",
}


def abbr(club: str) -> str:
    """Return a 3-character club code. Falls back to auto-generated initials."""
    key = club.strip().lower()
    if key in _KNOWN:
        return _KNOWN[key]
    words = club.split()
    if len(words) >= 3:
        return "".join(w[0] for w in words[:3]).upper()
    elif len(words) == 2:
        return (words[0][:2] + words[1][0]).upper()
    else:
        return club[:3].upper()
