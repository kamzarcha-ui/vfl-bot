"""
Scoring, coach statistics, and player goals persistence.

Coach stats  → coaches.json  (independent of club, survives season changes)
Player goals → teams.json    (inside each team's players list)
Club pts     → db.json       (via db.update_club_pts)
"""
from bot.data.teams_db import load_coaches, save_coaches, load_teams, save_teams

COACH_STAT_FIELDS = ("exact_predictions",)


# ── prediction scoring ────────────────────────────────────────────────────────

def score_prediction(predicted: str, actual: str) -> tuple[int, bool, bool, int]:
    """
    Evaluate a predicted scoreline against the real result.

    Returns
    -------
    perf_score   : int  — 3 (exact) / 1 (correct result) / 0 (wrong)
                         used internally to decide which club wins the matchup
    is_exact     : bool — predicted == actual
    is_correct_gd: bool — goal difference matches but score differs
    player_goals : int  — 2 (exact) / 1 (correct GD, not exact) / 0 (other)
    """
    if predicted == actual:
        return 3, True, False, 2

    try:
        p_h, p_a = map(int, predicted.split("-"))
        a_h, a_a = map(int, actual.split("-"))
    except (ValueError, AttributeError):
        return 0, False, False, 0

    p_gd = p_h - p_a
    a_gd = a_h - a_a

    def outcome(h: int, a: int) -> str:
        return "H" if h > a else ("A" if h < a else "D")

    correct_result = outcome(p_h, p_a) == outcome(a_h, a_a)
    correct_gd = p_gd == a_gd  # implies correct_result for non-zero GD

    if correct_gd:
        # Same goal difference, different scoreline → +1 player goal
        return (3 if correct_result else 1), False, True, 1

    if correct_result:
        # Right result, wrong goal difference → perf_score 1, no player goals
        return 1, False, False, 0

    return 0, False, False, 0


# ── coach stats ───────────────────────────────────────────────────────────────

def _find_coach_by_tid(tid: str) -> tuple[str | None, dict | None]:
    coaches = load_coaches()
    for name, info in coaches.items():
        if info.get("telegram_id") == tid:
            return name, info
    return None, None


def update_coach_stats(telegram_id: int, is_exact: bool) -> None:
    """Track only exact score predictions for a coach (coach rating)."""
    if not is_exact:
        return
    tid = str(telegram_id)
    coaches = load_coaches()
    for name, info in coaches.items():
        if info.get("telegram_id") == tid:
            info["exact_predictions"] = info.get("exact_predictions", 0) + 1
            coaches[name] = info
            save_coaches(coaches)
            return


def update_coach_matchday_goals(telegram_id: int, goals_to_add: int) -> None:
    """
    Add prediction goals (2 exact / 1 correct GD / 0 other) to a coach's
    matchday_goals tally.  Separate from player goals and from coach rating.
    """
    if goals_to_add <= 0:
        return
    tid = str(telegram_id)
    coaches = load_coaches()
    for name, info in coaches.items():
        if info.get("telegram_id") == tid:
            info["matchday_goals"] = info.get("matchday_goals", 0) + goals_to_add
            coaches[name] = info
            save_coaches(coaches)
            return


# ── player goals ──────────────────────────────────────────────────────────────

def update_player_goals(team_name: str, player_name: str, goals_to_add: int) -> None:
    """Add goals_to_add (0, 1, or 2) to the named player on the given team."""
    if goals_to_add <= 0 or not player_name:
        return
    teams = load_teams()
    team = teams.get(team_name)
    if not team:
        return
    for player in team.get("players", []):
        if isinstance(player, dict) and player.get("name") == player_name:
            player["goals"] = player.get("goals", 0) + goals_to_add
            break
    teams[team_name] = team
    save_teams(teams)


# ── coach lookup helpers ──────────────────────────────────────────────────────

def get_coach_name_by_tid(telegram_id: int) -> str | None:
    name, _ = _find_coach_by_tid(str(telegram_id))
    return name


def get_coach_team_name_by_tid(telegram_id: int) -> str | None:
    _, info = _find_coach_by_tid(str(telegram_id))
    return info.get("team") if info else None


# ── per-round stats computation ───────────────────────────────────────────────

def compute_round_stats(round_no: int) -> tuple[dict, dict, dict]:
    """
    Walk every processed fixture in round_no and derive per-round stats.

    Returns
    -------
    team_perf   : {team_name: total_perf_score}   — for Team of the Round
    coach_exacts: {tid_str: exact_count}           — for Coach of the Round
    player_goals: {(player_name, team_name): goals} — for Player/Dream Team
    """
    from bot.data.db import get_fixtures, get_result, get_all_predictions_for_match

    team_perf: dict[str, int] = {}
    coach_exacts: dict[str, int] = {}
    player_goals: dict[tuple[str, str], int] = {}

    round_fixtures = [f for f in get_fixtures() if f["round"] == round_no]

    for fixture in round_fixtures:
        fid = fixture["id"]
        result = get_result(fid)
        if not result or not result.get("processed"):
            continue
        real_score = result["score"]
        preds = get_all_predictions_for_match(fid)

        for tid_str, pred in preds.items():
            predicted = pred.get("score", "")
            player_name = pred.get("player", "")
            if not predicted:
                continue

            try:
                tid_int = int(tid_str)
            except ValueError:
                continue

            perf_score, is_exact, _, goals = score_prediction(predicted, real_score)
            team_name = get_coach_team_name_by_tid(tid_int)

            if is_exact:
                coach_exacts[tid_str] = coach_exacts.get(tid_str, 0) + 1

            if goals > 0 and player_name and team_name:
                key = (player_name, team_name)
                player_goals[key] = player_goals.get(key, 0) + goals

            if team_name:
                team_perf[team_name] = team_perf.get(team_name, 0) + perf_score

    return team_perf, coach_exacts, player_goals


# ── matchup club-point calculation ────────────────────────────────────────────

def compute_matchup_club_pts(
    fixture_ids: list[str],
    coach_a_tid: str,
    coach_b_tid: str,
) -> tuple[int, int, int, int]:
    """
    Sum perf_scores for each coach across all fixtures in a matchup.

    Returns (score_a, score_b, pts_a, pts_b) where pts are 3/1/0.
    """
    from bot.data.db import get_all_predictions_for_match, get_result

    total_a = 0
    total_b = 0

    for fid in fixture_ids:
        result = get_result(fid)
        if not result or not result.get("score"):
            continue
        real_score = result["score"]
        preds = get_all_predictions_for_match(fid)

        for tid, pred in ((coach_a_tid, preds.get(coach_a_tid)),
                          (coach_b_tid, preds.get(coach_b_tid))):
            if not pred:
                continue
            predicted = pred.get("score", "")
            if not predicted:
                continue
            perf_score, _, _, _ = score_prediction(predicted, real_score)
            if tid == coach_a_tid:
                total_a += perf_score
            else:
                total_b += perf_score

    if total_a > total_b:
        return total_a, total_b, 3, 0
    elif total_a < total_b:
        return total_a, total_b, 0, 3
    else:
        return total_a, total_b, 1, 1
