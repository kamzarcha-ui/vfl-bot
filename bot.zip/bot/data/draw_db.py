"""
Draw engine for VFL Champions League.

Home/away is assigned *structurally* during fixture generation to guarantee
exact 4-home / 4-away per club with zero retries:

  Within-pot 9-cycle  : orient clockwise → each club home once, away once.
  Cross-pot pair (i,j): matching-1 → pot-i club is HOME
                        matching-2 → pot-j club is HOME

Proof of balance for a pot-i club (0-indexed):
  - appears as LEFT  in (i, j>i)  pairs: home in m1, away in m2  → (3-i) each
  - appears as RIGHT in (k<i, i)  pairs: away in m1, home in m2  → i each
  - within-pot cycle                                              → 1 home, 1 away
  Total home  = (3-i) + i + 1 = 4  ✓
  Total away  = (3-i) + i + 1 = 4  ✓
"""

import json
import os
import random
from collections import Counter, defaultdict

DRAW_FILE = os.path.join(os.path.dirname(__file__), "draw.json")

# ── Season 1 fixed pots ────────────────────────────────────────────────────────

SEASON1_POTS: dict[str, list[str]] = {
    "1": [
        "Real Madrid", "Manchester City", "Bayern Munich", "Liverpool",
        "Paris Saint-Germain", "Inter", "Barcelona", "Arsenal", "Chelsea",
    ],
    "2": [
        "Juventus", "AC Milan", "Atletico Madrid", "Bayer Leverkusen",
        "Borussia Dortmund", "Napoli", "Benfica", "Porto", "Ajax",
    ],
    "3": [
        "Celtic", "PSV Eindhoven", "Roma", "Monaco", "Galatasaray",
        "Fenerbahce", "Marseille", "Lyon", "RB Leipzig",
    ],
    "4": [
        "Newcastle United", "Rangers", "Valencia", "Villarreal", "Atalanta BC",
        "Sporting CP", "Manchester United", "Aston Villa", "Athletic Club",
    ],
}

ALL_CLUBS: list[str] = [c for clubs in SEASON1_POTS.values() for c in clubs]
CLUB_TO_POT: dict[str, str] = {
    c: p for p, clubs in SEASON1_POTS.items() for c in clubs
}

TOTAL_CLUBS        = 36
TOTAL_FIXTURES     = 144
TOTAL_ROUNDS       = 8
FIXTURES_PER_ROUND = 18


# ── Persistence ────────────────────────────────────────────────────────────────

def _load() -> dict:
    if not os.path.exists(DRAW_FILE):
        return {"draw_complete": False}
    with open(DRAW_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(DRAW_FILE, "w") as f:
        json.dump(data, f, indent=2)


def draw_exists() -> bool:
    return bool(_load().get("draw_complete"))


def load_draw() -> dict:
    return _load()


def reset_draw() -> None:
    _save({"draw_complete": False})


def get_round_fixtures(round_no: int) -> list[dict]:
    data = _load()
    if not data.get("draw_complete"):
        return []
    return [f for f in data.get("fixtures", []) if f.get("round") == round_no]


# ── Fixture + home/away generation (deterministic balance) ────────────────────

def _generate_fixtures() -> list[dict] | None:
    """
    Build all 144 fixtures with home/away already assigned to guarantee
    exactly 4 home and 4 away per club.  Returns None only if a derangement
    cannot be found within the retry budget (extremely rare).
    """
    pot_lists = [SEASON1_POTS[str(p)] for p in range(1, 5)]
    fixtures: list[dict] = []
    pair_set: set[frozenset] = set()

    # ── Within-pot: orient a random 9-cycle clockwise ─────────────────────────
    # Each club is home exactly once (→ next in cycle) and away exactly once
    for pot in pot_lists:
        s = pot.copy()
        random.shuffle(s)
        for i in range(9):
            home = s[i]
            away = s[(i + 1) % 9]
            key  = frozenset((home, away))
            if key in pair_set:
                return None          # duplicate within a pot (impossible, but guard)
            pair_set.add(key)
            fixtures.append({"home": home, "away": away})

    # ── Cross-pot: two random perfect matchings per pot-pair ──────────────────
    # matching-1: left (pot_i) is HOME
    # matching-2: right (pot_j) is HOME  →  left is AWAY
    for i in range(4):
        for j in range(i + 1, 4):
            left  = pot_lists[i].copy()
            right = pot_lists[j].copy()
            random.shuffle(left)

            # Matching 1
            random.shuffle(right)
            perm1 = right.copy()

            # Matching 2 must differ from perm1 at every position (derangement)
            found = False
            for _ in range(500):
                random.shuffle(right)
                perm2 = right.copy()
                if all(perm2[k] != perm1[k] for k in range(9)):
                    found = True
                    break
            if not found:
                return None

            for k in range(9):
                k1 = frozenset((left[k], perm1[k]))
                k2 = frozenset((left[k], perm2[k]))
                if k1 in pair_set or k2 in pair_set:
                    return None     # duplicate pair (very rare with 36 distinct names)
                pair_set.add(k1)
                pair_set.add(k2)

                # matching-1: left[k] HOME
                fixtures.append({"home": left[k],  "away": perm1[k]})
                # matching-2: perm2[k] (right/pot-j side) HOME
                fixtures.append({"home": perm2[k], "away": left[k]})

    return fixtures if len(fixtures) == TOTAL_FIXTURES else None


# ── Round scheduling (most-constrained-first) ─────────────────────────────────

def _schedule_rounds(fixtures: list[dict]) -> bool:
    """
    Assign a round number (1-8) to each fixture in-place.
    Uses most-constrained-first: always schedules the fixture that has
    the fewest valid rounds next, breaking ties by smallest round size.
    Returns True on success, False if no valid assignment exists for some fixture.
    """
    club_rounds: dict[str, set[int]] = {c: set() for c in ALL_CLUBS}
    round_size = Counter()

    pending = list(range(len(fixtures)))
    random.shuffle(pending)   # randomise order for tie-breaking between equal-constraint fixtures

    while pending:
        # Pick the most constrained unscheduled fixture
        best_pos   = 0
        best_score = float("inf")
        best_cands: list[int] = []

        for pos, idx in enumerate(pending):
            h    = fixtures[idx]["home"]
            a    = fixtures[idx]["away"]
            busy = club_rounds[h] | club_rounds[a]
            cands = [r for r in range(1, TOTAL_ROUNDS + 1)
                     if r not in busy and round_size[r] < FIXTURES_PER_ROUND]
            score = len(cands)
            if score < best_score:
                best_score = score
                best_pos   = pos
                best_cands = cands

        if best_score == 0:
            return False

        idx = pending.pop(best_pos)
        # Among valid rounds pick the one with the fewest fixtures (most space)
        r = min(best_cands, key=lambda x: round_size[x])
        fixtures[idx]["round"] = r
        club_rounds[fixtures[idx]["home"]].add(r)
        club_rounds[fixtures[idx]["away"]].add(r)
        round_size[r] += 1

    return True


# ── Public draw runner ─────────────────────────────────────────────────────────

def run_draw(max_outer: int = 100, max_inner: int = 50) -> dict:
    """
    Generate a complete, validated draw.
    Outer loop regenerates fixture pairs; inner loop retries scheduling only.
    Raises RuntimeError if all attempts fail.
    """
    for _outer in range(max_outer):
        fixtures = _generate_fixtures()
        if fixtures is None:
            continue

        for _inner in range(max_inner):
            fcopy = [f.copy() for f in fixtures]
            if not _schedule_rounds(fcopy):
                continue

            # Stamp IDs
            for i, f in enumerate(fcopy):
                f["id"] = f"r{f['round']}_f{i:03d}"

            # Build opponents index
            opponents: dict[str, list[str]] = defaultdict(list)
            for f in fcopy:
                opponents[f["home"]].append(f["away"])
                opponents[f["away"]].append(f["home"])

            data = {
                "draw_complete": True,
                "pots":      SEASON1_POTS,
                "opponents": dict(opponents),
                "fixtures":  fcopy,
            }

            errors = validate_draw(data)
            if not errors:
                return data
            # Validation failed despite scheduling succeeding — retry inner
            continue

    raise RuntimeError(
        f"Valid draw not found after {max_outer} × {max_inner} attempts"
    )


def save_draw(data: dict) -> None:
    _save(data)


# ── Diagnostics (used by /drawdebug) ─────────────────────────────────────────

def run_draw_diagnostic() -> dict:
    """
    Run each step once and return a detailed diagnostic report dict.
    Does NOT save anything.
    """
    report: dict = {}

    # Step 1: fixture generation
    fixtures = _generate_fixtures()
    if fixtures is None:
        report["fixtures_ok"]    = False
        report["fixtures_count"] = 0
        report["fixtures_error"] = "Fixture/home-away generation returned None"
        report["ha_ok"]          = False
        report["round_ok"]       = False
        report["validation_errors"] = ["Generation failed before home/away step"]
        return report

    report["fixtures_ok"]    = True
    report["fixtures_count"] = len(fixtures)

    # Step 2: verify home/away balance
    home_cnt  = Counter(f["home"] for f in fixtures)
    away_cnt  = Counter(f["away"] for f in fixtures)
    ha_errors = []
    for club in ALL_CLUBS:
        h = home_cnt[club]
        a = away_cnt[club]
        if h != 4:
            ha_errors.append(f"{club}: {h} home (expected 4)")
        if a != 4:
            ha_errors.append(f"{club}: {a} away (expected 4)")
    report["ha_ok"]     = len(ha_errors) == 0
    report["ha_errors"] = ha_errors[:10]   # cap output

    # Step 3: attempt round scheduling
    fcopy = [f.copy() for f in fixtures]
    sched_ok = _schedule_rounds(fcopy)
    report["round_ok"] = sched_ok

    if sched_ok:
        # Count any clubs scheduled more than once per round
        round_clubs: dict[int, list] = defaultdict(list)
        for f in fcopy:
            r = f["round"]
            round_clubs[r] += [f["home"], f["away"]]
        sched_errors = []
        for r, clubs in round_clubs.items():
            if len(clubs) != len(set(clubs)):
                dupes = [c for c, n in Counter(clubs).items() if n > 1]
                sched_errors.append(f"Round {r}: duplicate clubs {dupes}")
        report["sched_errors"] = sched_errors
    else:
        report["sched_errors"] = ["Scheduling returned False — deadlock encountered"]

    # Step 4: full validation on the scheduled copy
    if sched_ok:
        for i, f in enumerate(fcopy):
            f["id"] = f"r{f['round']}_f{i:03d}"
        opponents: dict[str, list[str]] = defaultdict(list)
        for f in fcopy:
            opponents[f["home"]].append(f["away"])
            opponents[f["away"]].append(f["home"])
        data = {
            "draw_complete": True,
            "pots":      SEASON1_POTS,
            "opponents": dict(opponents),
            "fixtures":  fcopy,
        }
        errors = validate_draw(data)
        report["validation_errors"] = errors
    else:
        report["validation_errors"] = ["Skipped — scheduling failed"]

    return report


# ── Validation ────────────────────────────────────────────────────────────────

def validate_draw(data: dict) -> list[str]:
    """Validate a draw dict.  Returns a list of error strings (empty = valid)."""
    errors: list[str] = []
    fixtures = data.get("fixtures", [])

    # Fixture count
    if len(fixtures) != TOTAL_FIXTURES:
        errors.append(
            f"❌ Учрашувлар сони: {len(fixtures)} (кутилган: {TOTAL_FIXTURES})"
        )

    # Unique fixtures
    pair_set: set[frozenset] = set()
    for f in fixtures:
        k = frozenset((f["home"], f["away"]))
        if k in pair_set:
            errors.append(f"❌ Такрорий учрашув: {f['home']} — {f['away']}")
        pair_set.add(k)

    # Total clubs
    clubs_seen = {f["home"] for f in fixtures} | {f["away"] for f in fixtures}
    if len(clubs_seen) != TOTAL_CLUBS:
        errors.append(
            f"❌ Жамоалар сони: {len(clubs_seen)} (кутилган: {TOTAL_CLUBS})"
        )

    # Per-club home/away/total
    home_cnt  = Counter(f["home"] for f in fixtures)
    away_cnt  = Counter(f["away"] for f in fixtures)
    total_cnt = Counter()
    for f in fixtures:
        total_cnt[f["home"]] += 1
        total_cnt[f["away"]] += 1

    for club in ALL_CLUBS:
        h = home_cnt[club]
        a = away_cnt[club]
        t = total_cnt[club]
        if h != 4:
            errors.append(f"❌ {club}: {h} та уй ўйини (кутилган: 4)")
        if a != 4:
            errors.append(f"❌ {club}: {a} та меҳмон ўйини (кутилган: 4)")
        if t != 8:
            errors.append(f"❌ {club}: {t} та ўйин жами (кутилган: 8)")

    # Opponent count (288 = 36 × 8)
    opponents  = data.get("opponents", {})
    total_opp  = sum(len(v) for v in opponents.values())
    if total_opp != 288:
        errors.append(
            f"❌ Клуб-рақиб алоқалари: {total_opp} (кутилган: 288)"
        )

    # Round structure
    by_round: dict[int, list] = defaultdict(list)
    for f in fixtures:
        r = f.get("round")
        if r is not None:
            by_round[r].append(f)

    round_nos = sorted(by_round.keys())
    if round_nos != list(range(1, TOTAL_ROUNDS + 1)):
        errors.append(f"❌ Тур рақамлари нотўғри: {round_nos}")

    for r, rf in by_round.items():
        if len(rf) != FIXTURES_PER_ROUND:
            errors.append(
                f"❌ {r}-тур: {len(rf)} та учрашув (кутилган: {FIXTURES_PER_ROUND})"
            )
        round_clubs = [c for f in rf for c in (f["home"], f["away"])]
        if len(round_clubs) != len(set(round_clubs)):
            dupes = [c for c, n in Counter(round_clubs).items() if n > 1]
            errors.append(f"❌ {r}-турда такрорий жамоа: {', '.join(dupes)}")

    return errors
