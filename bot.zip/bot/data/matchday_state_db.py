"""
Matchday active/inactive flag — matchday_state.json

Controls whether prediction submissions are open.
Independent of the deadline (deadline closes by time; this opens/closes manually).
"""

import json
import os

STATE_FILE = os.path.join(os.path.dirname(__file__), "matchday_state.json")


def _load() -> dict:
    if not os.path.exists(STATE_FILE):
        return {"active": False}
    with open(STATE_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(STATE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def is_matchday_active() -> bool:
    return bool(_load().get("active", False))


def set_matchday_active(active: bool) -> None:
    _save({"active": active})
