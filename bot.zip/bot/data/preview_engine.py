8у"""
Preview Engine — generates Match Day Preview and Review articles from existing data.

No AI. No external calls. Purely data-driven using:
  • build_standings_from_club_stats() — current league table
  • get_duel_results(md)             — recent form / match results
  • get_playoff_bracket()            — playoff round pairs
  • get_stage_bracket(stage)         — r16 / qf / sf / final pairs
  • load_sensations()                — reuses already-detected sensations

Public API:
  generate_preview(match_day, fixtures, season) -> tuple[str, dict]
  generate_review(match_day, standings_before, completed_stage, season) -> tuple[str, dict]
    Both return (broadcast_text, commentary_json_item)
"""

from datetime import datetime, timezone

_PLAYOFF_STAGE_MAP: dict[int, tuple[str, int]] = {
    9:  ("playoff", 1),
    10: ("playoff", 2),
    11: ("r16",     1),
    12: ("r16",     2),
    13: ("qf",      1),
    14: ("qf",      2),
    15: ("sf",      1),
    16: ("sf",      2),
    17: ("final",   1),
}

_STAGE_LABEL: dict[str, str] = {
    "playoff": "🔥 Плей-офф",
    "r16":     "🎟 1/8 Финал",
    "qf":      "🏅 1/4 Финал",
    "sf":      "🥉 1/2 Финал",
    "final":   "👑 Финал",
}

_LEG_LABEL = {1: "Биринчи ўйин", 2: "Иккинчи ўйин"}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M")


def _form_icons(form: list[str]) -> str:
    icons = {"W": "✅", "D": "🟡", "L": "❌"}
    return " ".join(icons.get(r, "⬜") for r in form) or "—"


def _get_form(team: str, n: int = 3) -> list[str]:
    """Return the last n W/D/L results for a team from duel history."""
    from bot.data.db import get_duel_results
    form: list[str] = []
    for md in range(1, 18):
        for d in get_duel_results(md):
            if d["home"] != team and d["away"] != team:
                continue
            gh, ga   = d["goals_home"], d["goals_away"]
            is_home  = d["home"] == team
            tg       = gh if is_home else ga
            og       = ga if is_home else gh
            form.append("W" if tg > og else ("L" if tg < og else "D"))
    return form[-n:]


def _zone(pos: int) -> str:
    if pos <= 8:
        return "top8"
    if pos <= 24:
        return "playoff"
    return "elimination"


# ── Derby detection ───────────────────────────────────────────────────────────
# Each entry: (frozenset of two lowercase keywords, derby name in Uzbek)
# Matching: both keywords must appear (as substrings) in the two team names.

_DERBY_PAIRS: list[tuple[frozenset, str]] = [
    (frozenset({"интер",    "ювентус"}),      "Дерби д'Италия"),
    (frozenset({"inter",    "juventus"}),      "Derby d'Italia"),
    (frozenset({"милан",    "интер"}),         "Мадоннина Дербиси"),
    (frozenset({"milan",    "inter"}),         "Derby della Madonnina"),
    (frozenset({"рома",     "лацио"}),         "Рим Дербиси"),
    (frozenset({"roma",     "lazio"}),         "Derby della Capitale"),
    (frozenset({"реал",     "барселона"}),     "Эль Класико"),
    (frozenset({"real",     "barcelona"}),     "El Clásico"),
    (frozenset({"реал",     "атлетико"}),      "Мадрид Дербиси"),
    (frozenset({"real",     "atletico"}),      "Madrid Derby"),
    (frozenset({"арсенал",  "тоттенхэм"}),    "Шимолий Лондон Дербиси"),
    (frozenset({"arsenal",  "tottenham"}),     "North London Derby"),
    (frozenset({"арсенал",  "челси"}),         "Лондон Дербиси"),
    (frozenset({"arsenal",  "chelsea"}),       "London Derby"),
    (frozenset({"ливерпуль","эвертон"}),       "Мерсисайд Дербиси"),
    (frozenset({"liverpool","everton"}),       "Merseyside Derby"),
    (frozenset({"мю",       "ливерпуль"}),     "Шимолий-Ғарб Дербиси"),
    (frozenset({"united",   "liverpool"}),     "Northwest Derby"),
    (frozenset({"мю",       "сити"}),          "Манчестер Дербиси"),
    (frozenset({"united",   "city"}),          "Manchester Derby"),
    (frozenset({"бавария",  "боруссия"}),      "Дер Классикер"),
    (frozenset({"bayern",   "dortmund"}),      "Der Klassiker"),
    (frozenset({"сельтик",  "рейнджерс"}),    "Олд Фёрм"),
    (frozenset({"celtic",   "rangers"}),       "Old Firm"),
    (frozenset({"порту",    "бенфика"}),       "О Класико"),
    (frozenset({"porto",    "benfica"}),       "O Clásico"),
    (frozenset({"псж",      "марсель"}),       "Ле Классик"),
    (frozenset({"psg",      "marseille"}),     "Le Classique"),
    (frozenset({"галатасарай","фенербахче"}),  "Истанбул Дербиси"),
    (frozenset({"galatasaray","fenerbahce"}),  "Istanbul Derby"),
    (frozenset({"аякс",     "фейеноорд"}),     "Де Класикер"),
    (frozenset({"ajax",     "feyenoord"}),     "De Klassieker"),
    (frozenset({"атлетик",  "реал сосьедад"}), "Баск Дербиси"),
    (frozenset({"athletic", "sociedad"}),      "Basque Derby"),
    (frozenset({"боруссия д","боруссия м"}),   "Рур Дербиси"),
    (frozenset({"dortmund", "monchengladbach"}), "Revierderby"),
]


def _find_derby(home: str, away: str) -> str | None:
    """
    Return derby name if home vs away is a known rivalry, else None.
    Uses substring matching on lowercased names.
    """
    h = home.lower()
    a = away.lower()
    for pair, name in _DERBY_PAIRS:
        kws = list(pair)
        k1, k2 = kws[0], kws[1]
        if (k1 in h and k2 in a) or (k2 in h and k1 in a):
            return name
    return None


# ── Central match description pools ───────────────────────────────────────────

_CENTRAL_DESCS: list[str] = [
    "Жадвал тепасидаги икки қудратли жамоа ўртасидаги бош баҳс — бу ўйин рейтинг манзарасини бутунлай ўзгартириши мумкин.",
    "Лига тепасидаги ўрин учун рамзий тўқнашув — бу ўйин кучлар нисбатини белгилайди.",
    "Тур бошидаги асосий жанг. Жадвалдаги мавқеи учун ҳар икки жамоа ҳам ортга чекинмайди.",
    "Жадвалдаги таянч баҳс. Икки кучли рақиб ўртасидаги рамзий жанг — ҳар бир очко муҳим.",
]

_DERBY_DESCS: list[str] = [
    "Тарихий рақиблар яна учрашмоқда — бу дерби ҳар доим алоҳида жанг.",
    "Дерби — жадвал эмас, ифтихор учун ўйналади. Статистика ортда қолади.",
    "Азалий рақиблик яна майдонга чиқади — дербида ҳеч нарса олдиндан аниқ эмас.",
]

_IMPORTANT_DESCS: list[str] = [
    "Жадвал жойлашувлари нозик фарқ билан ажралиб турадиган муҳим учрашув.",
    "Бу ўйиннинг натижаси жадвал манзарасини ўзгартириши мумкин.",
    "Жадвалнинг ўрта қисмидаги тегиш баҳс — кимнинг формаси ҳал қилувчи рол ўйнайди.",
]


# ── League stage preview ──────────────────────────────────────────────────────

def _generate_league_preview(
    match_day: int,
    fixtures: list[dict],
    season: int,
) -> tuple[str, dict]:
    from bot.data.league_stage_db import build_standings_from_club_stats

    standings = build_standings_from_club_stats()
    has_data  = any(s.get("played", 0) > 0 for s in standings)

    pos_map: dict[str, int] = {s["team"]: s["pos"] for s in standings}
    pts_map: dict[str, int] = {s["team"]: s["pts"] for s in standings}
    # Bug fix: use actual max position as fallback, not the magic number 99
    _fallback_pos = max(pos_map.values(), default=36) + 1

    def _pos(t: str) -> int:
        return pos_map.get(t, _fallback_pos)

    def _pts(t: str) -> int:
        return pts_map.get(t, 0)

    title = f"Match Day {match_day} Preview"
    date  = _ts()
    _S    = "━" * 22

    lines: list[str] = [
        "🎙 <b>VFL MATCH DAY PREVIEW</b>",
        f"🏆 <b>Match Day #{match_day}</b>",
    ]

    # ── Opening round: no standings yet ───────────────────────────────────────
    if not has_data or not standings:
        lines += [f"\n{_S}", "🌟 <b>VFL мавсум бошланди!</b>",
                  "Жадвал ҳали шаклланмаган — барча жамоалар бир хил имкониятга эга."]
        lines += [f"\n{_S}", "📋 <b>ТУР ЎЙИНЛАРИ</b>\n"]
        _nums = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"]
        for i, fx in enumerate(fixtures):
            lines.append(f"{_nums[i] if i < 5 else str(i+1)+'.'} "
                         f"<b>{fx['home']}</b> 🆚 <b>{fx['away']}</b>")
        lines += [f"\n{_S}", "🎯 <b>ТУР САВОЛИ</b>\n",
                  "Биринчи тур кимни жадвал тепасига олиб чиқади?"]
        text = "\n".join(lines)
        return text, {"date": date, "season": season, "match_day": match_day,
                      "type": "preview", "title": title, "text": text}

    # ── Rank all 5 fixtures by combined standing position ─────────────────────
    ranked = sorted(
        enumerate(fixtures),
        key=lambda xi: _pos(xi[1]["home"]) + _pos(xi[1]["away"]),
    )

    # ── 1. Central match: best combined rank ──────────────────────────────────
    central_idx, central_fx = ranked[0]

    # ── 2. Derby: scan all fixtures for a known rivalry ───────────────────────
    derby_fx: dict | None = None
    derby_name: str | None = None
    derby_idx: int = -1
    for idx, fx in enumerate(fixtures):
        name = _find_derby(fx["home"], fx["away"])
        if name:
            derby_fx   = fx
            derby_name = name
            derby_idx  = idx
            break

    # ── 3. Important matches: top-3 by combined rank, excluding central & derby
    excluded = {central_idx}
    if derby_idx >= 0:
        excluded.add(derby_idx)

    important: list[tuple[int, dict]] = []
    for idx, fx in ranked:
        if idx in excluded:
            continue
        important.append((idx, fx))
        if len(important) == 3:
            break

    # If fewer than 3, fill from derby/central as last resort
    if len(important) < 3 and derby_idx >= 0 and derby_idx != central_idx:
        important.append((derby_idx, derby_fx))  # type: ignore[arg-type]
    if len(important) < 3:
        important.append((central_idx, central_fx))

    important = important[:3]

    # ── Standing display helper ─
    TEAM_ALIASES = {
    "Милан": "AC Milan",
    "Интер": "Inter",
    "Барселона": "Barcelona",
    "Реал": "Real Madrid",
    "Бавария": "Bayern Munich",
    "Боруссия": "Borussia Dortmund",
    "ПСЖ": "Paris Saint-Germain",
    "МЮ": "Manchester United",
    "МС": "Manchester City",
    }
    def _standing(t: str) -> str:
    team = TEAM_ALIASES.get(t, t)

    if team not in pos_map:
        return "📊 Ҳали рейтинг шаклланмаган"

    return f"📊 {_pos(team)}-ўрин • {_pts(team)} очко"

    # ── Build output ──────────────────────────────────────────────────────────

    # Section 1 — Central match
    lines.append(f"\n{_S}")
    lines.append("🔥 <b>ТУР МАРКАЗИЙ ЎЙИНИ</b>\n")
    ch, ca = central_fx["home"], central_fx["away"]
    lines.append(f"<b>{ch}</b> 🆚 <b>{ca}</b>\n")
    lines.append(_standing(ch))
    lines.append("🆚")
    lines.append(_standing(ca))
    combined = _pos(ch) + _pos(ca)
    lines.append(f"\n{_CENTRAL_DESCS[min(combined // 4, len(_CENTRAL_DESCS) - 1)]}")

    # Section 2 — Derby (skip if same as central)
    if derby_fx and derby_idx != central_idx:
        lines.append(f"\n{_S}")
        lines.append("🔥 <b>ТУР ДЕРБИСИ</b>\n")
        dh, da = derby_fx["home"], derby_fx["away"]
        lines.append(f"<b>{dh}</b> 🆚 <b>{da}</b>\n")
        if derby_name:
            lines.append(f"🏟 <i>{derby_name}</i>\n")
        lines.append(_standing(dh))
        lines.append("🆚")
        lines.append(_standing(da))
        _d_idx = derby_idx % len(_DERBY_DESCS)
        lines.append(f"\n{_DERBY_DESCS[_d_idx]}")

    # Section 3 — Top-3 important matches
    if important:
        lines.append(f"\n{_S}")
        lines.append("⭐ <b>ТУРНИНГ МУҲИМ ЎЙИНЛАРИ</b>\n")
        _nums = ["1️⃣", "2️⃣", "3️⃣"]
        for rank_i, (_, fx) in enumerate(important):
            ih, ia = fx["home"], fx["away"]
            num = _nums[rank_i] if rank_i < 3 else f"{rank_i + 1}."
            lines.append(f"{num} <b>{ih}</b> 🆚 <b>{ia}</b>")
            lines.append(_standing(ih))
            lines.append("🆚")
            lines.append(_standing(ia))
            if rank_i < len(important) - 1:
                lines.append("")

    # Section 4 — Question of the round
    lines.append(f"\n{_S}")
    lines.append("🎯 <b>ТУР САВОЛИ</b>\n")
    h0_pos, a0_pos = _pos(ch), _pos(ca)
    if h0_pos == 1 or a0_pos == 1:
        leader = ch if h0_pos == 1 else ca
        question = f"{leader} жадвал тепасидаги мавқеини сақлаб қола оладими?"
    elif h0_pos <= 3 or a0_pos <= 3:
        contender = ch if h0_pos <= a0_pos else ca
        question = f"{contender} бу турда ғалаба қозониб, лидерга яқинлаша оладими?"
    else:
        question = (f"<b>{ch}</b> 🆚 <b>{ca}</b> — "
                    f"бу турнинг бош жанги кимга ҳал қилувчи ўрин беради?")
    lines.append(question)

    text = "\n".join(lines)
    item = {
        "date":      date,
        "season":    season,
        "match_day": match_day,
        "type":      "preview",
        "title":     title,
        "text":      text,
    }
    return text, item


# ── Playoff preview ───────────────────────────────────────────────────────────

def _generate_playoff_preview(
    match_day: int,
    season: int,
) -> tuple[str, dict]:
    from bot.data.league_stage_db import (
        get_playoff_bracket, get_stage_bracket,
    )
    from bot.data.db import get_duel_results

    stage, leg = _PLAYOFF_STAGE_MAP[match_day]
    stage_lbl  = _STAGE_LABEL.get(stage, stage)
    leg_lbl    = _LEG_LABEL.get(leg, "")
    title      = f"{stage_lbl} — {leg_lbl} Preview"
    date       = _ts()

    # Get pairings
    if stage == "playoff":
        bracket = get_playoff_bracket() or []
        pairs   = [{"home": p["team1"], "away": p["team2"]} for p in bracket]
    else:
        pairs = get_stage_bracket(stage) or []

    # For leg 2, get leg 1 results to show first-leg score
    leg1_scores: dict[frozenset, tuple[int, int]] = {}
    if leg == 2:
        for d in get_duel_results(match_day - 1):
            key = frozenset([d["home"], d["away"]])
            leg1_scores[key] = (d["goals_home"], d["goals_away"])

    lines: list[str] = [
        "🎙 <b>VFL PLAYOFF STUDIO</b>",
        f"{stage_lbl}",
        f"<i>{leg_lbl}</i>",
    ]

    if not pairs:
        lines.append("\nБошқич жадвали ҳали шаклланмаган.")
    else:
        for i, pair in enumerate(pairs):
            # Pairs can be dict {home, away} or {team1, team2}
            home = pair.get("home") or pair.get("team1", "?")
            away = pair.get("away") or pair.get("team2", "?")

            lines.append("\n━━━━━━━━━━━━━━━━━━━━")
            lines.append(f"<b>{home}</b> 🆚 <b>{away}</b>")

            # Show leg 1 result if this is leg 2
            if leg == 2:
                key  = frozenset([home, away])
                leg1 = leg1_scores.get(key)
                if leg1:
                    # leg1 was stored with home/away flipped for leg2
                    # leg1 first leg: away (current) was home, home (current) was away
                    # Actually leg 1 has away as home in leg 2
                    lines.append(
                        f"📋 1-ўйин натижаси: {leg1[0]}–{leg1[1]}"
                    )

            # Playoff descriptions
            if stage == "playoff":
                desc = _pick_playoff_desc(i)
            elif stage == "r16":
                desc = "1/8 финал учрашуви — ғолиб чорак финалга чиқади."
            elif stage == "qf":
                desc = "Чорак финал — 4 та ўрин учун кескин жанг."
            elif stage == "sf":
                desc = "Ярим финал — финалга чиқиш учун рамзий тўқнашув."
            elif stage == "final":
                desc = "👑 VFL Champions League чемпионлиги учун ФИНАЛ!"
            else:
                desc = ""

            if desc:
                lines.append(desc)

    # Closing line
    if stage == "final":
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🎯 <b>Тур савол:</b> Бугун VFL тарихига ким ном ёзади?")
    elif pairs:
        first_home = (pairs[0].get("home") or pairs[0].get("team1", ""))
        first_away = (pairs[0].get("away") or pairs[0].get("team2", ""))
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(
            f"🎯 <b>Тур савол:</b> <b>{first_home}</b> 🆚 <b>{first_away}</b> "
            f"— кейинги босқичга ким ўтади?"
        )

    text = "\n".join(lines)
    item = {
        "date":      date,
        "season":    season,
        "match_day": match_day,
        "type":      "preview",
        "title":     title,
        "text":      text,
    }
    return text, item


def _pick_playoff_desc(idx: int) -> str:
    pool = [
        "Плей-офф учрашуви — агрегат ҳисоб ҳал қилади.",
        "Икки жамоа ҳам тайёр. Майдон кимни кўпроқ хоҳлайди?",
        "Плей-оффда фаворитлик йўқ — ҳар бир гол олтиндек баҳоли.",
        "Бу учрашув рақибларни яхши танийдиган икки жамоани бир-биriga юзлаштиради.",
    ]
    return pool[idx % len(pool)]


# ── Public entry point: Preview ───────────────────────────────────────────────

def generate_preview(
    match_day: int,
    fixtures: list[dict],
    season: int,
) -> tuple[str, dict]:
    """
    Generate a preview article for the given match day.

    League stage (MD 1-8):  selects 5-6 key fixtures by category.
    Playoff stage (MD 9-17): shows ALL bracket pairings (Playoff Studio).

    Returns (broadcast_text, commentary_json_item).
    """
    if match_day in _PLAYOFF_STAGE_MAP:
        return _generate_playoff_preview(match_day, season)
    return _generate_league_preview(match_day, fixtures, season)


# ═════════════════════════════════════════════════════════════════════════════
# MATCH DAY REVIEW
# ═════════════════════════════════════════════════════════════════════════════

_MOVE_ICON = {True: "📈", False: "📉", None: "➡️"}


def _move(pos_before: int, pos_after: int) -> str:
    """Return movement indicator relative to previous MD standings."""
    if pos_before == 99 or pos_after == 99:
        return ""
    diff = pos_before - pos_after   # positive = moved up
    if diff > 0:
        return f" ↑{diff}"
    if diff < 0:
        return f" ↓{abs(diff)}"
    return ""


# ── League stage review ───────────────────────────────────────────────────────

def _generate_league_review(
    match_day: int,
    standings_before: list[dict],
    season: int,
) -> tuple[str, dict]:
    from bot.data.db import get_duel_results
    from bot.data.league_stage_db import build_standings_from_club_stats
    from bot.data.sensations_db import load_sensations

    standings_after = build_standings_from_club_stats()
    duels           = get_duel_results(match_day)

    pos_before: dict[str, int] = {s["team"]: s.get("pos", 99) for s in standings_before}
    pos_after:  dict[str, int] = {s["team"]: s.get("pos", 99) for s in standings_after}
    pts_after:  dict[str, int] = {s["team"]: s.get("pts", 0)  for s in standings_after}

    title = f"Match Day {match_day} Review"
    date  = _ts()

    lines: list[str] = [
        "🎙 <b>VFL MATCH DAY REVIEW</b>",
        f"🏆 <b>Match Day #{match_day}</b>",
    ]

    # ── Section 1: Leaders ───────────────────────────────────────────────────
    top3 = standings_after[:3]
    if top3:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("📈 <b>Лидерлар</b>\n")
        for s in top3:
            team  = s["team"]
            pts   = s["pts"]
            pos_a = s["pos"]
            pos_b = pos_before.get(team, 99)
            mv    = _move(pos_b, pos_a)
            medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(pos_a, "")
            lines.append(f"{medal} <b>{team}</b> ({pts} очко){mv}")

    # ── Section 2: Top-8 Battle ──────────────────────────────────────────────
    top8_b   = {s["team"] for s in standings_before if s.get("pos", 99) <= 8}
    top8_a   = {s["team"] for s in standings_after  if s.get("pos", 99) <= 8}
    entered  = sorted(top8_a - top8_b, key=lambda t: pos_after.get(t, 99))
    dropped  = sorted(top8_b - top8_a, key=lambda t: pos_after.get(t, 99))

    if entered or dropped:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("⚔️ <b>ТОП-8 Жанги</b>\n")
        for team in entered:
            lines.append(f"✅ <b>{team}</b> ТОП-8 га кирди ({pos_after.get(team, '?')}-ўрин)")
        for team in dropped:
            lines.append(f"❌ <b>{team}</b> ТОП-8 дан чиқди ({pos_after.get(team, '?')}-ўрин)")
    elif top8_a:
        # No change — report current top-8 holders briefly
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("⚔️ <b>ТОП-8 Жанги</b>\n")
        holder = sorted(top8_a, key=lambda t: pos_after.get(t, 99))[:3]
        lines.append("ТОП-8 таркиби ўзгармади.")
        lines.append(", ".join(holder) + " — юқори зонада давом этмоқда.")

    # ── Section 3: Playoff Zone (9-24) ───────────────────────────────────────
    pz_b = {s["team"] for s in standings_before if 8 < s.get("pos", 99) <= 24}
    pz_a = {s["team"] for s in standings_after  if 8 < s.get("pos", 99) <= 24}
    pz_entered = sorted(pz_a - pz_b - top8_b, key=lambda t: pos_after.get(t, 99))
    pz_dropped = sorted(pz_b - pz_a - top8_a, key=lambda t: pos_after.get(t, 99))

    if pz_entered or pz_dropped:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🔥 <b>Плей-офф Зонаси</b>\n")
        for team in pz_entered[:3]:
            lines.append(f"↑ <b>{team}</b> плей-офф зонасига кирди ({pos_after.get(team, '?')}-ўрин)")
        for team in pz_dropped[:3]:
            lines.append(f"↓ <b>{team}</b> плей-офф зонасидан чиқди")

    # ── Section 4: Elimination Zone (25+) ────────────────────────────────────
    elim_b  = {s["team"] for s in standings_before if s.get("pos", 99) >= 25}
    elim_a  = {s["team"] for s in standings_after  if s.get("pos", 99) >= 25}
    new_elim = sorted(elim_a - elim_b, key=lambda t: pos_after.get(t, 99))

    if new_elim:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("⚠️ <b>Элиминация Зонаси</b>\n")
        for team in new_elim[:4]:
            lines.append(
                f"📉 <b>{team}</b> {pos_after.get(team, '?')}-ўринга тушди — хавфли зона!"
            )

    # ── Section 5: Match Day Hero ─────────────────────────────────────────────
    if duels:
        best_margin, best_d = 0, None
        best_total,  best_t = 0, None
        for d in duels:
            gh, ga = d["goals_home"], d["goals_away"]
            if abs(gh - ga) > best_margin:
                best_margin = abs(gh - ga)
                best_d      = d
            if gh + ga > best_total:
                best_total = gh + ga
                best_t     = d

        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("⭐ <b>Тур Қаҳрамони</b>\n")

        if best_d and best_margin >= 2:
            gh, ga   = best_d["goals_home"], best_d["goals_away"]
            winner   = best_d["home"] if gh > ga else best_d["away"]
            loser    = best_d["away"] if gh > ga else best_d["home"]
            w_goals  = max(gh, ga)
            l_goals  = min(gh, ga)
            lines.append(
                f"<b>{winner}</b> {w_goals}–{l_goals} <b>{loser}</b>"
            )
            if best_margin >= 5:
                lines.append("💥 Улкан ғалаба — турнинг энг йирик натижаси!")
            elif best_margin >= 3:
                lines.append("🔥 Тур бўйича энг йирик ғалаба.")
            else:
                lines.append("Тур бўйича энг яхши натижа.")

            if (
                best_t
                and best_t is not best_d
                and best_total >= 6
            ):
                gh2, ga2 = best_t["goals_home"], best_t["goals_away"]
                lines.append(
                    f"\n⚽ Энг сергол ўйин: <b>{best_t['home']}</b> {gh2}–{ga2}"
                    f" <b>{best_t['away']}</b> ({best_total} гол)"
                )
        elif best_t and best_total >= 5:
            gh, ga = best_t["goals_home"], best_t["goals_away"]
            lines.append(
                f"⚽ <b>{best_t['home']}</b> {gh}–{ga} <b>{best_t['away']}</b>"
            )
            lines.append(f"Энг сергол ўйин — жами {best_total} гол.")
        else:
            lines.append("Тур ягона голлар билан якунланди.")

    # ── Section 6: Sensation ──────────────────────────────────────────────────
    all_sens   = load_sensations()
    md_sens    = [s for s in all_sens if s.get("match_day") == match_day]
    # Prefer upset over huge_win for the review headline
    sens_order = {"upset": 0, "huge_win": 1, "unexpected_elimination": 2,
                  "unexpected_r16_direct": 2, "playoff_underdog": 2}
    md_sens.sort(key=lambda s: sens_order.get(s.get("type", ""), 9))

    if md_sens:
        s = md_sens[0]
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"🔥 <b>Тур Сенсацияси</b>\n")
        lines.append(f"{s.get('icon', '🔥')} <b>{s['headline']}</b>")
        lines.append(s["body"])

    # ── Section 7: Conclusion ─────────────────────────────────────────────────
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🎙 <b>Хулоса</b>\n")

    if match_day == 8:
        lines.append(
            "Лига босқичи якунланди — плей-офф учрашувлари ва тўғридан-тўғри "
            "1/8 финал иштирокчилари аниқланди. VFL кубоги учун кураш давом этади!"
        )
    elif entered and top3:
        leader = top3[0]["team"]
        lines.append(
            f"ТОП-8 да ўзгаришлар бўлди — {', '.join(entered[:2])} янги ўринлар "
            f"эгаллади. Жадвал тепасида <b>{leader}</b> мавқеини мустаҳкамлаши керак."
        )
    elif new_elim:
        lines.append(
            f"{len(new_elim)} жамоа хавфли зонага тушди. "
            "Кейинги тур уларнинг тақдирини ҳал қилади."
        )
    elif top3:
        leader = top3[0]["team"]
        pts_l  = top3[0]["pts"]
        lines.append(
            f"<b>{leader}</b> {pts_l} очко билан лидерликни давом эттирмоқда. "
            "Кейинги турда янги баҳслар бошланади!"
        )
    else:
        lines.append(
            f"Match Day #{match_day} якунланди. "
            "Жадвал манзараси аниқлашиб бормоқда."
        )

    text = "\n".join(lines)
    item = {
        "date":      date,
        "season":    season,
        "match_day": match_day,
        "type":      "review",
        "title":     title,
        "text":      text,
    }
    return text, item


# ── Playoff review ────────────────────────────────────────────────────────────

def _generate_playoff_review(
    match_day: int,
    completed_stage: str | None,
    season: int,
) -> tuple[str, dict]:
    from bot.data.db import get_duel_results
    from bot.data.league_stage_db import get_stage_winners
    from bot.data.sensations_db import load_sensations

    stage, leg = _PLAYOFF_STAGE_MAP[match_day]
    stage_lbl  = _STAGE_LABEL.get(stage, stage)
    leg_lbl    = _LEG_LABEL.get(leg, "")
    title      = f"{stage_lbl} — {leg_lbl} Review"
    date       = _ts()

    duels = get_duel_results(match_day)

    lines: list[str] = [
        "🎙 <b>VFL PLAYOFF STUDIO — ШАРҲ</b>",
        f"{stage_lbl}",
        f"<i>{leg_lbl} якунланди</i>",
    ]

    # ── Match results ─────────────────────────────────────────────────────────
    if duels:
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("📊 <b>Тур натижалари</b>\n")
        for d in duels:
            gh, ga  = d["goals_home"], d["goals_away"]
            icon    = "🏆" if gh != ga else "🤝"
            lines.append(
                f"{icon} <b>{d['home']}</b> {gh}–{ga} <b>{d['away']}</b>"
            )

    # ── Hero ──────────────────────────────────────────────────────────────────
    if duels:
        best_d, best_margin = None, 0
        for d in duels:
            gh, ga = d["goals_home"], d["goals_away"]
            if abs(gh - ga) > best_margin:
                best_margin = abs(gh - ga)
                best_d      = d
        if best_d and best_margin >= 2:
            gh, ga  = best_d["goals_home"], best_d["goals_away"]
            winner  = best_d["home"] if gh > ga else best_d["away"]
            loser   = best_d["away"] if gh > ga else best_d["home"]
            lines.append("\n━━━━━━━━━━━━━━━━━━━━")
            lines.append("⭐ <b>Тур Қаҳрамони</b>\n")
            lines.append(
                f"<b>{winner}</b> {max(gh,ga)}–{min(gh,ga)} <b>{loser}</b>"
            )
            lines.append("Турнинг энг яхши натижаси.")

    # ── Sensation ─────────────────────────────────────────────────────────────
    all_sens = load_sensations()
    md_sens  = [s for s in all_sens if s.get("match_day") == match_day]
    if md_sens:
        s = md_sens[0]
        lines.append("\n━━━━━━━━━━━━━━━━━━━━")
        lines.append("🔥 <b>Тур Сенсацияси</b>\n")
        lines.append(f"{s.get('icon', '🔥')} <b>{s['headline']}</b>")
        lines.append(s["body"])

    # ── Advancement (after second leg / final) ────────────────────────────────
    if completed_stage:
        winners = get_stage_winners(completed_stage) or []
        next_lbl_map = {
            "playoff": "1/8 Финал",
            "r16":     "1/4 Финал",
            "qf":      "1/2 Финал",
            "sf":      "Финал",
        }
        if completed_stage == "final" and winners:
            lines.append("\n━━━━━━━━━━━━━━━━━━━━")
            lines.append("👑 <b>VFL Champions League Чемпиони!</b>\n")
            lines.append(f"🏆 <b>{winners[0]}</b>")
            lines.append(
                f"Табриклаймиз! {winners[0]} VFL Champions League чемпиони бўлди!"
            )
        elif winners:
            next_lbl = next_lbl_map.get(completed_stage, "")
            lines.append("\n━━━━━━━━━━━━━━━━━━━━")
            lines.append(f"🎟 <b>Кейинги босқичга ўтганлар</b> → {next_lbl}\n")
            for w in winners:
                lines.append(f"  ✅ {w}")

    # ── Conclusion ────────────────────────────────────────────────────────────
    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("🎙 <b>Хулоса</b>\n")
    if completed_stage == "final":
        lines.append("VFL Champions League мавсуми якунланди. Ишtirokчиларга раҳмат!")
    elif completed_stage:
        nl = next_lbl_map.get(completed_stage, "кейинги босқич")
        lines.append(
            f"{stage_lbl} якунланди. {nl} учрашувлари жадвали кутилмоқда!"
        )
    else:
        lines.append(
            f"{stage_lbl} — {leg_lbl} якунланди. "
            "Иккинчи ўйин якуни умумий ҳисобни белгилайди."
        )

    text = "\n".join(lines)
    item = {
        "date":      date,
        "season":    season,
        "match_day": match_day,
        "type":      "review",
        "title":     title,
        "text":      text,
    }
    return text, item


# ── Public entry point: Review ────────────────────────────────────────────────

def generate_review(
    match_day: int,
    standings_before: list[dict],
    completed_stage: str | None,
    season: int,
) -> tuple[str, dict]:
    """
    Generate a review article after a Match Day is closed.

    League stage (MD 1-8):  leaders, zone changes, hero, sensation, conclusion.
    Playoff stage (MD 9-17): match results, hero, sensation, advancement.

    Must be called AFTER:
      • duels are processed (standings updated)
      • detect_and_store_sensations() has run (sensations available)

    Returns (broadcast_text, commentary_json_item).
    """
    if match_day in _PLAYOFF_STAGE_MAP:
        return _generate_playoff_review(match_day, completed_stage, season)
    return _generate_league_review(match_day, standings_before, season)
