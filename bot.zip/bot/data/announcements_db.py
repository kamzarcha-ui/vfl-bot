"""
Announcements DB — manual admin broadcast history.
Storage: bot/data/announcements.json  (max 100, newest first)

Public API:
  load_announcements()                    -> list[dict]
  save_announcement(text, season) -> dict
"""

import json
import os
from datetime import datetime, timezone

_DIR  = os.path.dirname(__file__)
_FILE = os.path.join(_DIR, "announcements.json")
_MAX  = 100


def load_announcements() -> list:
    if not os.path.exists(_FILE):
        return []
    with open(_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_announcement(text: str, season: int) -> dict:
    """Prepend a new announcement and persist. Returns the saved item."""
    item = {
        "date":   datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M"),
        "season": season,
        "author": "admin",
        "text":   text,
    }
    items = load_announcements()
    items.insert(0, item)
    with open(_FILE, "w", encoding="utf-8") as f:
        json.dump(items[:_MAX], f, indent=2, ensure_ascii=False)
    return item
