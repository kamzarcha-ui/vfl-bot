"""
Season DB — multi-season archive, club/coach rankings, and season reset.

Storage (bot/data/):
  history.json         — per-season full archive
  champions.json       — champions list
  awards.json          — per-season awards
  club_ranking.json    — cumulative club ranking
  coach_ranking.json   — cumulative coach ranking
  season_settings.json — current_season, status

Public API:
  get_current_season() → int
  archive_season(season) → dict        (save history, champions, awards, rankings)
  reset_season_data()                  (clear season data, increment counter)
  load_history / load_champions / load_awards / load_club_ranking / load_coach_ranking
"""

import json
import os
from datetime import datetime, timezone
from typing import Any

_DIR = os.path.dirname(__file__)

_HISTORY_FILE       = os.path.join(_DIR, "history.json")
_CHAMPIONS_FILE     = os.path.join(_DIR, "champions.json")
_AWARDS_FILE        = os.path.join(_DIR, "awards.json")
_CLUB_RANKING_FILE  = os.path.join(_DIR, "club_ranking.json")
_COACH_RANKING_FILE = os.path.join(_DIR, "coach_ranking.json")
_SETTINGS_FILE      = os.path.join(_DIR, "season_settings.json")

# Points awarded per furthest stage reached (mutually exclusive)
STAGE_POINTS: dict[str, int] = {
    "champion":      30,
    "runner_up":     24,
    "semi_final":    18,
    "quarter_final": 12,
    "r16":            6,
    "playoff":        3,
    "eliminated":     0,
}

STAGE_LABELS: dict[str, str] = {
    "champion":      "🏆 Чемпион",
    "runner_up":     "🥈 Финалист",
    "semi_final":    "🥉 Ярим финал",
    "quarter_final": "🏅 Чорак финал",
    "r16":           "🎟 1/8 финал",
    "playoff":       "🔥 Плей-офф",
    "eliminated":    "⬇️ Лига",
}


# ── Storage I/O ───────────────────────────────────────────────────────────────

def _load(path: str, default: Any = None) -> Any:
    if not os.path.exists(path):
        return default if default is not None else {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(path: str, data: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_history() -> list:
    return _load(_HISTORY_FILE, [])


def save_history(data: list) -> None:
    _save(_HISTORY_FILE, data)


def load_champions() -> list:
    return _load(_CHAMPIONS_FILE, [])


def save_champions(data: list) -> None:
    _save(_CHAMPIONS_FILE, data)


def load_awards() -> list:
    return _load(_AWARDS_FILE, [])


def save_awards(data: list) -> None:
    _save(_AWARDS_FILE, data)


def load_club_ranking() -> dict:
    return _load(_CLUB_RANKING_FILE, {})


def save_club_ranking(data: dict) -> None:
    _save(_CLUB_RANKING_FILE, data)


def load_coach_ranking() -> dict:
    return _load(_COACH_RANKING_FILE, {})


def save_coach_ranking(data: dict) -> None:
    _save(_COACH_RANKING_FILE, data)


def get_season_settings() -> dict:
    data = _load(_SETTINGS_FILE, {})
    data.setdefault("current_season", 1)
    data.setdefault("status", "active")
    return data


def save_season_settings(data: dict) -> None:
    _save(_SETTINGS_FILE, data)


def get_current_season() -> int:
    return get_season_settings().get("current_season", 1)


# ── Award determination ────────────────────────────────────────────────────────

def _determine_awards() -> dict:
    """
    Auto-compute season awards from live data:
      golden_boot      — player with most goals
      golden_predictor — coach with most exact_predictions
      best_player      — same as golden_boot (auto proxy)
      dream_team       — top 11 players by goals (min 1 goal)
    """
    from bot.data.teams_db import load_teams, load_coaches

    teams   = load_teams()
    coaches = load_coaches()

    # Golden Boot
    all_players: list[dict] = []
    for team_name, info in teams.items():
        for p in info.get("players", []):
            if isinstance(p, dict) and p.get("name"):
                all_players.append({
                    "name":  p["name"],
                    "goals": p.get("goals", 0),
                    "team":  team_name,
                })
    all_players.sort(key=lambda x: x["goals"], reverse=True)
    golden_boot = all_players[0] if all_players and all_players[0]["goals"] > 0 else None

    # Golden Predictor
    golden_predictor = None
    best_exact = -1
    for coach_name, info in coaches.items():
        ex = info.get("exact_predictions", 0)
        if ex > best_exact:
            best_exact       = ex
            golden_predictor = {
                "name":  coach_name,
                "exact": ex,
                "team":  info.get("team", ""),
            }
    if best_exact <= 0:
        golden_predictor = None

    # Dream Team: top 11 players with at least 1 goal
    dream_team = [p["name"] for p in all_players[:11] if p["goals"] > 0]

    return {
        "golden_boot":      golden_boot,
        "golden_predictor": golden_predictor,
        "best_player":      golden_boot,
        "dream_team":       dream_team,
    }


# ── Ranking helpers ───────────────────────────────────────────────────────────

def _build_team_stage_map(
    champion: str | None,
    runner_up: str | None,
    sf_losers: list[str],
    qf_losers: list[str],
    r16_losers: list[str],
    playoff_losers: list[str],
    eliminated: list[str],
) -> dict[str, str]:
    """Map each team → their best achieved stage key."""
    m: dict[str, str] = {}
    for t in eliminated:
        m[t] = "eliminated"
    for t in playoff_losers:
        m[t] = "playoff"
    for t in r16_losers:
        m[t] = "r16"
    for t in qf_losers:
        m[t] = "quarter_final"
    for t in sf_losers:
        m[t] = "semi_final"
    if runner_up:
        m[runner_up] = "runner_up"
    if champion:
        m[champion] = "champion"
    return m


def _update_ranking(ranking_file: str, season: int, entity_stages: dict[str, str]) -> None:
    """
    Append season result to club or coach ranking file.
    entity_stages: {entity_name: stage_key}
    """
    ranking = _load(ranking_file, {})
    for entity, stage_key in entity_stages.items():
        pts   = STAGE_POINTS.get(stage_key, 0)
        label = STAGE_LABELS.get(stage_key, "")
        entry = ranking.setdefault(entity, {"total_points": 0, "seasons": []})
        # Avoid double-counting if finishseason is run twice for same season
        if any(s["season"] == season for s in entry["seasons"]):
            continue
        entry["total_points"] = entry.get("total_points", 0) + pts
        entry["seasons"].append({
            "season": season,
            "stage":  stage_key,
            "label":  label,
            "pts":    pts,
        })
    _save(ranking_file, ranking)


# ── Main archive function ─────────────────────────────────────────────────────

def archive_season(season: int) -> dict:
    """
    Archive the completed season:
      1. Read bracket/stage data from league_stage_db
      2. Determine awards automatically
      3. Save to history, champions, awards
      4. Update club and coach rankings
      5. Return the history entry dict
    """
    from bot.data.league_stage_db import (
        get_stage_winners, get_classification, get_stage_bracket,
        build_standings_from_club_stats,
    )
    from bot.data.teams_db import load_teams

    # ── Bracket participants per stage ────────────────────────────────────────
    def _bracket_teams(stage: str) -> list[str]:
        out: list[str] = []
        for pair in get_stage_bracket(stage):
            for k in ("home", "away"):
                v = pair.get(k)
                if v:
                    out.append(v)
        return out

    final_teams = _bracket_teams("final")   # 2
    sf_teams    = _bracket_teams("sf")      # 4
    qf_teams    = _bracket_teams("qf")      # 8
    r16_teams   = _bracket_teams("r16")     # 16

    final_winners   = get_stage_winners("final")
    sf_winners      = get_stage_winners("sf")
    qf_winners      = get_stage_winners("qf")
    r16_winners     = get_stage_winners("r16")
    playoff_winners = get_stage_winners("playoff")

    clf          = get_classification()
    eliminated   = clf.get("eliminated", []) if clf else []
    playoff_zone = clf.get("playoff_zone", []) if clf else []

    # Champion and runner-up
    champion  = final_winners[0] if final_winners else (final_teams[0] if final_teams else None)
    runner_up = next((t for t in final_teams if t != champion), None)

    # Stage losers (the ones who get those stage points, not higher ones)
    sf_losers      = [t for t in sf_teams   if t not in (sf_winners      or [])]
    qf_losers      = [t for t in qf_teams   if t not in (qf_winners      or [])]
    r16_losers     = [t for t in r16_teams  if t not in (r16_winners     or [])]
    playoff_losers = [t for t in playoff_zone if t not in (playoff_winners or [])]

    # ── Awards ────────────────────────────────────────────────────────────────
    awards = _determine_awards()

    # ── League table snapshot ─────────────────────────────────────────────────
    league_table = build_standings_from_club_stats()

    # ── History entry ─────────────────────────────────────────────────────────
    history_entry: dict = {
        "season":            season,
        "date_archived":     datetime.now(timezone.utc).strftime("%d.%m.%Y"),
        "champion":          champion,
        "runner_up":         runner_up,
        "sf_all":            sf_teams,
        "semi_finalists":    sf_losers,
        "quarter_finalists": qf_losers,
        "r16_participants":  r16_losers,
        "playoff_teams":     playoff_losers,
        "eliminated":        eliminated,
        "top_scorer":        awards.get("golden_boot"),
        "golden_predictor":  awards.get("golden_predictor"),
        "best_player":       awards.get("best_player"),
        "dream_team":        awards.get("dream_team", []),
        "league_table":      league_table[:8],
    }

    history = load_history()
    history = [h for h in history if h.get("season") != season]
    history.append(history_entry)
    save_history(history)

    # ── Champions archive ─────────────────────────────────────────────────────
    champions = load_champions()
    champions = [c for c in champions if c.get("season") != season]
    if champion:
        champions.append({
            "season":    season,
            "champion":  champion,
            "runner_up": runner_up or "",
        })
    save_champions(champions)

    # ── Awards archive ────────────────────────────────────────────────────────
    all_awards = load_awards()
    all_awards = [a for a in all_awards if a.get("season") != season]
    all_awards.append({
        "season":           season,
        "golden_boot":      awards.get("golden_boot"),
        "golden_predictor": awards.get("golden_predictor"),
        "best_player":      awards.get("best_player"),
        "dream_team":       awards.get("dream_team", []),
    })
    save_awards(all_awards)

    # ── Rankings ──────────────────────────────────────────────────────────────
    team_stage_map = _build_team_stage_map(
        champion, runner_up, sf_losers, qf_losers,
        r16_losers, playoff_losers, eliminated,
    )
    _update_ranking(_CLUB_RANKING_FILE, season, team_stage_map)

    # Coach ranking: map coach → same stage as their team
    teams_data   = load_teams()
    team_to_coach: dict[str, str] = {
        team: info["coach"]
        for team, info in teams_data.items()
        if info.get("coach")
    }
    coach_stage_map: dict[str, str] = {
        team_to_coach[team]: stage
        for team, stage in team_stage_map.items()
        if team in team_to_coach
    }
    _update_ranking(_COACH_RANKING_FILE, season, coach_stage_map)

    return history_entry


# ── Season reset ──────────────────────────────────────────────────────────────

def reset_season_data() -> None:
    """
    Clear all season-specific data after archiving.

    CLEARED:
      db.json — predictions, fixtures, results, duel_results, playoff_results,
                club_stats, matchups, matchup_club_scored, current_matchday
      league_stage.json — removed entirely
      Player goals → 0
      Coach exact_predictions / matchday_goals → 0

    PRESERVED:
      teams, coaches structure, licenses, telegram_ids, registrations
      history, champions, awards, rankings, hall of fame, season settings
    """
    import bot.data.db as _db
    from bot.data.teams_db import load_teams, save_teams, load_coaches, save_coaches

    # Clear db.json season data
    db_path = os.path.join(_DIR, "db.json")
    if os.path.exists(db_path):
        data = _db._load()
        for key in (
            "predictions", "fixtures", "results", "duel_results",
            "playoff_results", "club_stats", "matchups", "matchup_club_scored",
        ):
            data.pop(key, None)
        data["current_matchday"] = 0
        _db._save(data)

    # Remove league_stage.json entirely
    league_path = os.path.join(_DIR, "league_stage.json")
    if os.path.exists(league_path):
        os.remove(league_path)

    # Reset player goals
    teams = load_teams()
    for info in teams.values():
        for p in info.get("players", []):
            if isinstance(p, dict):
                p["goals"] = 0
    save_teams(teams)

    # Reset coach season stats
    coaches = load_coaches()
    for info in coaches.values():
        info["exact_predictions"] = 0
        info["matchday_goals"]    = 0
    save_coaches(coaches)

    # Increment season counter
    settings = get_season_settings()
    settings["current_season"]    = settings.get("current_season", 1) + 1
    settings["status"]            = "active"
    settings["season_start_date"] = None
    settings["season_end_date"]   = None
    save_season_settings(settings)
