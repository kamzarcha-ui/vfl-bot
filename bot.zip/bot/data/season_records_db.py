"""
Season Records DB — current-season records computed live from existing data.

NO separate storage file is needed for reading:
  compute_season_records() pulls directly from club_stats, duel_results,
  coaches, and teams — the same data the rest of the bot uses.

Archive (before season reset):
  archive_season_records(season) → appends snapshot to season_records_archive.json

Public API:
  compute_season_records(season) → dict
  archive_season_records(season) → None
"""

import json
import os

_DIR          = os.path.dirname(__file__)
_ARCHIVE_FILE = os.path.join(_DIR, "season_records_archive.json")


# ── Archive I/O ───────────────────────────────────────────────────────────────

def _load_archive() -> list:
    if not os.path.exists(_ARCHIVE_FILE):
        return []
    with open(_ARCHIVE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_archive(data: list) -> None:
    with open(_ARCHIVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def archive_season_records(season: int) -> None:
    """Call this before reset_season_data() to preserve the season snapshot."""
    snap = compute_season_records(season)
    archive = _load_archive()
    archive = [a for a in archive if a.get("season") != season]
    archive.append(snap)
    _save_archive(archive)


# ── Streak helpers ────────────────────────────────────────────────────────────

def _build_sequences() -> dict[str, list[str]]:
    """Return {team: [W/D/L, ...]} from all played duel results."""
    from bot.data.db import get_duel_results

    seqs: dict[str, list[str]] = {}
    for md in range(1, 18):
        for d in get_duel_results(md):
            home, away = d["home"], d["away"]
            gh, ga     = d["goals_home"], d["goals_away"]
            if gh > ga:
                rh, ra = "W", "L"
            elif gh < ga:
                rh, ra = "L", "W"
            else:
                rh, ra = "D", "D"
            seqs.setdefault(home, []).append(rh)
            seqs.setdefault(away, []).append(ra)
    return seqs


def _max_run(seq: list[str], targets: set[str]) -> int:
    best = cur = 0
    for r in seq:
        if r in targets:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


# ── Main computation ──────────────────────────────────────────────────────────

def compute_season_records(season: int) -> dict:
    """
    Compute all current-season records from live data.

    Returns a structured dict:
    {
      "season": int,
      "team":   { key: {"holder": str, "value": int/float, "detail": str} },
      "coach":  { ... },
      "player": { ... },
      "match":  { ... },
    }
    """
    from bot.data.db import get_club_stats, get_duel_results
    from bot.data.teams_db import load_coaches, load_teams

    team_rec:  dict = {}
    coach_rec: dict = {}
    player_rec: dict = {}
    match_rec: dict = {}

    # ── Club stats ────────────────────────────────────────────────────────────
    club_stats = get_club_stats()
    played = {t: s for t, s in club_stats.items() if s.get("played", 0) > 0}

    if played:
        def _best(key: str, stat: str, reverse: bool = True):
            ranked = sorted(played.items(), key=lambda x: x[1].get(stat, 0), reverse=reverse)
            if not ranked:
                return None, 0
            team, stats = ranked[0]
            return team, stats.get(stat, 0)

        # Points
        t, v = _best("pts", "pts")
        if t and v > 0:
            team_rec["most_points"] = {"holder": t, "value": v,
                                       "detail": f"{v} очко"}

        # Wins
        t, v = _best("wins", "w")
        if t and v > 0:
            team_rec["most_wins"] = {"holder": t, "value": v,
                                     "detail": f"{v} ғалаба"}

        # Goals scored
        t, v = _best("most_goals", "gf")
        if t and v > 0:
            team_rec["most_goals"] = {"holder": t, "value": v,
                                      "detail": f"{v} гол забити"}

        # Fewest goals conceded (min 5 played)
        eligible = {t: s for t, s in played.items() if s.get("played", 0) >= 5}
        if eligible:
            t, info = min(eligible.items(), key=lambda x: x[1].get("ga", 9999))
            ga = info.get("ga", 0)
            team_rec["fewest_conceded"] = {"holder": t, "value": ga,
                                           "detail": f"{ga} гол ўтказди"}

        # Most defeats
        t, v = _best("most_defeats", "l")
        if t and v > 0:
            team_rec["most_defeats"] = {"holder": t, "value": v,
                                        "detail": f"{v} мағлубият"}

    # ── Streaks (from duel sequences) ─────────────────────────────────────────
    seqs = _build_sequences()
    if seqs:
        # Win streak
        best_ws_team, best_ws = "", 0
        for team, seq in seqs.items():
            run = _max_run(seq, {"W"})
            if run > best_ws:
                best_ws, best_ws_team = run, team
        if best_ws_team and best_ws > 0:
            team_rec["win_streak"] = {"holder": best_ws_team, "value": best_ws,
                                      "detail": f"{best_ws} кетма-кет ғалаба"}

        # Losing streak
        best_ls_team, best_ls = "", 0
        for team, seq in seqs.items():
            run = _max_run(seq, {"L"})
            if run > best_ls:
                best_ls, best_ls_team = run, team
        if best_ls_team and best_ls > 0:
            team_rec["lose_streak"] = {"holder": best_ls_team, "value": best_ls,
                                       "detail": f"{best_ls} кетма-кет мағлубият"}

        # Winless run (D+L)
        best_wl_team, best_wl = "", 0
        for team, seq in seqs.items():
            run = _max_run(seq, {"D", "L"})
            if run > best_wl:
                best_wl, best_wl_team = run, team
        if best_wl_team and best_wl > 1:
            team_rec["winless_run"] = {"holder": best_wl_team, "value": best_wl,
                                       "detail": f"{best_wl} ўйин ғалабасиз"}

    # ── Per-match records (biggest win, biggest defeat, highest scoring) ───────
    best_margin  = 0
    best_winner  = ""
    best_w_score = ""
    worst_margin = 0
    worst_loser  = ""
    worst_l_score = ""
    best_total   = 0
    best_t_label = ""
    best_t_score = ""

    for md in range(1, 18):
        for d in get_duel_results(md):
            gh, ga = d["goals_home"], d["goals_away"]
            margin = abs(gh - ga)
            total  = gh + ga
            home, away = d["home"], d["away"]

            if margin > best_margin:
                best_margin  = margin
                if gh > ga:
                    best_winner  = home
                    best_w_score = f"{gh}–{ga} ({home} 🆚 {away})"
                else:
                    best_winner  = away
                    best_w_score = f"{ga}–{gh} ({away} 🆚 {home})"

            if margin > worst_margin:
                worst_margin = margin
                if gh > ga:
                    worst_loser  = away
                    worst_l_score = f"{gh}–{ga} ({home} 🆚 {away})"
                else:
                    worst_loser  = home
                    worst_l_score = f"{ga}–{gh} ({away} 🆚 {home})"

            if total > best_total:
                best_total   = total
                best_t_label = f"{home} 🆚 {away}"
                best_t_score = f"{gh}–{ga}"

    if best_winner and best_margin > 0:
        match_rec["biggest_win"] = {
            "holder": best_winner, "value": best_margin,
            "detail": best_w_score,
        }
    if worst_loser and worst_margin > 0:
        match_rec["biggest_defeat"] = {
            "holder": worst_loser, "value": worst_margin,
            "detail": worst_l_score,
        }
    if best_t_label and best_total > 0:
        match_rec["highest_scoring"] = {
            "holder": best_t_label, "value": best_total,
            "detail": f"{best_t_score} — жами {best_total} гол",
        }

    # ── Coach records ─────────────────────────────────────────────────────────
    coaches = load_coaches()
    if coaches:
        # Most exact predictions
        top_exact = max(coaches.items(),
                        key=lambda x: x[1].get("exact_predictions", 0),
                        default=None)
        if top_exact:
            name, info = top_exact
            v = info.get("exact_predictions", 0)
            if v > 0:
                coach_rec["most_exact"] = {
                    "holder": name, "value": v,
                    "detail": f"{v} аниқ ҳисоб",
                }

        # Most prediction goals (matchday_goals)
        top_goals = max(coaches.items(),
                        key=lambda x: x[1].get("matchday_goals", 0),
                        default=None)
        if top_goals:
            name, info = top_goals
            v = info.get("matchday_goals", 0)
            if v > 0:
                coach_rec["most_goals"] = {
                    "holder": name, "value": v,
                    "detail": f"{v} гол (башорат)",
                }

    # ── Player records ────────────────────────────────────────────────────────
    teams = load_teams()
    top_scorer_name  = ""
    top_scorer_team  = ""
    top_scorer_goals = 0

    for team_name, team_info in teams.items():
        for player in team_info.get("players", []):
            if not isinstance(player, dict):
                continue
            g = player.get("goals", 0)
            if g > top_scorer_goals:
                top_scorer_goals = g
                top_scorer_name  = player.get("name", "")
                top_scorer_team  = team_name

    if top_scorer_name and top_scorer_goals > 0:
        player_rec["top_scorer"] = {
            "holder": top_scorer_name,
            "value":  top_scorer_goals,
            "detail": f"{top_scorer_goals} гол ({top_scorer_team})",
        }

    return {
        "season": season,
        "team":   team_rec,
        "coach":  coach_rec,
        "player": player_rec,
        "match":  match_rec,
    }
