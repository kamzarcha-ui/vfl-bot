"""
League Stage DB — classification, bracket, two-legged results, advancement.

league_stage.json stores:
  classification   — pos 1-8 (r16_direct), 9-24 (playoff_zone), 25-36 (eliminated)
  playoff_bracket  — fixed 8-pair bracket with team names after /playoffdraw
  brackets         — r16/qf/sf/final brackets (built automatically)
  two_leg_results  — leg1/leg2/winners/tiebreak_details per stage
"""

import json
import os
import random
from datetime import datetime, timezone

LEAGUE_STAGE_FILE = os.path.join(os.path.dirname(__file__), "league_stage.json")

# Fixed bracket in ceremony reveal order (spec-defined)
# Each tuple: (pos1, pos2) — pos1 is home in leg 1
FIXED_BRACKET_ORDER: list[tuple[int, int]] = [
    (17, 18),
    (15, 16),
    (23, 24),
    (9,  10),
    (21, 22),
    (11, 12),
    (19, 20),
    (13, 14),
]


def _load() -> dict:
    if not os.path.exists(LEAGUE_STAGE_FILE):
        return {}
    with open(LEAGUE_STAGE_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(LEAGUE_STAGE_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ── Standings helper ───────────────────────────────────────────────────────────

def build_standings_from_club_stats() -> list[dict]:
    """Build a sorted standings list from live club_stats in db.json."""
    from bot.data.db import get_club_stats
    stats = get_club_stats()
    rows: list[dict] = []
    for team, info in stats.items():
        gf = info.get("gf", 0)
        ga = info.get("ga", 0)
        rows.append({
            "team":   team,
            "pts":    info.get("pts", 0),
            "w":      info.get("w", 0),
            "d":      info.get("d", 0),
            "l":      info.get("l", 0),
            "played": info.get("played", 0),
            "gf":     gf,
            "ga":     ga,
            "gd":     gf - ga,
        })
    rows.sort(key=lambda x: (-x["pts"], -(x["gf"] - x["ga"]), -x["gf"]))
    for i, row in enumerate(rows, 1):
        row["pos"] = i
    return rows


# ── Classification ─────────────────────────────────────────────────────────────

def save_classification(standings: list[dict]) -> None:
    """Classify teams after MD8. standings must be sorted with "pos" key."""
    data = _load()
    by_pos = {s["pos"]: s["team"] for s in standings}
    data["classification"] = {
        "r16_direct":   [by_pos[p] for p in range(1,  9)  if p in by_pos],
        "playoff_zone": [by_pos[p] for p in range(9,  25) if p in by_pos],
        "eliminated":   [by_pos[p] for p in range(25, 37) if p in by_pos],
        "timestamp":    datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    _save(data)


def get_classification() -> dict | None:
    return _load().get("classification")


def classification_done() -> bool:
    return bool(_load().get("classification"))


# ── Playoff bracket ────────────────────────────────────────────────────────────

def save_playoff_bracket(standings: list[dict]) -> list[dict]:
    """
    Build the fixed 8-pair bracket from standings. Persist and return.
    Each pair: {pair_id, pos1, pos2, team1, team2}
    """
    data = _load()
    by_pos = {s["pos"]: s["team"] for s in standings}
    pairs: list[dict] = []
    for i, (p1, p2) in enumerate(FIXED_BRACKET_ORDER):
        pairs.append({
            "pair_id": i,
            "pos1":    p1,
            "pos2":    p2,
            "team1":   by_pos.get(p1, f"{p1}-ўрин"),
            "team2":   by_pos.get(p2, f"{p2}-ўрин"),
        })
    data["playoff_bracket"] = pairs
    _save(data)
    return pairs


def get_playoff_bracket() -> list[dict]:
    return _load().get("playoff_bracket", [])


def playoff_bracket_done() -> bool:
    return bool(_load().get("playoff_bracket"))


# ── Stage brackets (r16 / qf / sf / final) ────────────────────────────────────

def save_stage_bracket(stage: str, pairs: list[dict]) -> None:
    """pairs: [{"home": str, "away": str}, ...]"""
    data = _load()
    data.setdefault("brackets", {})[stage] = pairs
    _save(data)


def get_stage_bracket(stage: str) -> list[dict]:
    return _load().get("brackets", {}).get(stage, [])


# ── Two-legged results ─────────────────────────────────────────────────────────

def save_leg_result(stage: str, leg: int, records: list[dict]) -> None:
    """
    stage: "playoff" | "r16" | "qf" | "sf" | "final"
    leg:   1 or 2
    records: [{"home": str, "away": str, "goals_home": int, "goals_away": int}, ...]
    """
    data = _load()
    data.setdefault("two_leg_results", {}).setdefault(stage, {})[f"leg{leg}"] = records
    _save(data)


def get_leg_result(stage: str, leg: int) -> list[dict]:
    return _load().get("two_leg_results", {}).get(stage, {}).get(f"leg{leg}", [])


def save_stage_winners(stage: str, winners: list[str]) -> None:
    data = _load()
    data.setdefault("two_leg_results", {}).setdefault(stage, {})["winners"] = winners
    _save(data)


def get_stage_winners(stage: str) -> list[str]:
    return _load().get("two_leg_results", {}).get(stage, {}).get("winners", [])


# ── Winner computation ─────────────────────────────────────────────────────────

# MD numbers for each stage's two legs
_STAGE_LEG_MDS: dict[str, tuple[int, int]] = {
    "playoff": (9,  10),
    "r16":     (11, 12),
    "qf":      (13, 14),
    "sf":      (15, 16),
    "final":   (17, 17),
}

_TOTAL_MATCHES = 5


def _count_exact_predictions(
    team1: str, team2: str, leg1_md: int, leg2_md: int
) -> tuple[int, int]:
    """
    Count exact score predictions for each team across both playoff legs.
    Returns (exact_count_team1, exact_count_team2).
    Queries raw prediction + result data from db.
    """
    from bot.data.db import get_all_predictions_for_match, get_result
    from bot.data.stats_db import score_prediction
    from bot.data.teams_db import load_teams

    teams = load_teams()
    team_to_tid: dict[str, str] = {
        team: str(info["telegram_id"])
        for team, info in teams.items()
        if info.get("telegram_id")
    }

    tid1 = team_to_tid.get(team1, "")
    tid2 = team_to_tid.get(team2, "")
    exact1 = exact2 = 0

    for md_no in [leg1_md, leg2_md]:
        for match_idx in range(_TOTAL_MATCHES):
            match_id = f"md{md_no}_m{match_idx + 1}"
            result = get_result(match_id)
            if not result:
                continue
            real_score = result["score"]
            predictions = get_all_predictions_for_match(match_id)
            for tid_str, pred in predictions.items():
                predicted = pred.get("score", "")
                if not predicted:
                    continue
                _, is_exact, _, _ = score_prediction(predicted, real_score)
                if is_exact:
                    if tid1 and tid_str == tid1:
                        exact1 += 1
                    elif tid2 and tid_str == tid2:
                        exact2 += 1

    return exact1, exact2


def _simulate_penalty(team1: str, team2: str) -> dict:
    """
    Simulate a penalty shootout.
    Returns {"winner": str, "loser": str, "score_winner": int, "score_loser": int}.
    Uses realistic scorelines (5-kick rounds, sudden death extensions possible).
    """
    possible = [(3, 0), (4, 1), (4, 2), (4, 3), (5, 3), (5, 4), (3, 2), (5, 2)]
    sw, sl = random.choice(possible)
    winner = random.choice([team1, team2])
    loser  = team2 if winner == team1 else team1
    return {"winner": winner, "loser": loser, "score_winner": sw, "score_loser": sl}


def get_tiebreak_details(stage: str) -> list[dict]:
    """Return stored tie-break detail records for a completed stage."""
    return _load().get("two_leg_results", {}).get(stage, {}).get("tiebreak_details", [])


def compute_two_leg_winners(stage: str) -> list[dict]:
    """
    Determine winners from leg1 + leg2 per pair.

    Returns list of result dicts:
        {"winner": str, "reason": str, "penalty": dict | None}

    Tie-break order (VFL regulation):
      1. Aggregate goals
      2. Away goals  (goals scored in the away leg per team)
      3. Exact predictions  (both legs combined)
      4. Player goals  (total prediction goals, both legs)
      5. Penalty shootout  (simulated automatically)
    """
    leg1    = get_leg_result(stage, 1)
    leg2    = get_leg_result(stage, 2)
    leg_mds = _STAGE_LEG_MDS.get(stage, (0, 0))
    results: list[dict] = []

    for i, r1 in enumerate(leg1):
        team1 = r1["home"]   # home in leg 1 / away in leg 2
        team2 = r1["away"]   # away in leg 1 / home in leg 2
        r2    = leg2[i] if i < len(leg2) else {"goals_home": 0, "goals_away": 0}

        # ── Rule 1: Aggregate ──────────────────────────────────────────────────
        agg1 = r1["goals_home"] + r2.get("goals_away", 0)
        agg2 = r1["goals_away"] + r2.get("goals_home", 0)

        if agg1 != agg2:
            winner = team1 if agg1 > agg2 else team2
            results.append({"winner": winner, "reason": "aggregate", "penalty": None})
            continue

        # ── Rule 2: Away goals ─────────────────────────────────────────────────
        away1 = r2.get("goals_away", 0)   # team1 scored as away in leg 2
        away2 = r1.get("goals_away", 0)   # team2 scored as away in leg 1

        if away1 != away2:
            winner = team1 if away1 > away2 else team2
            results.append({"winner": winner, "reason": "away goals", "penalty": None})
            continue

        # ── Rule 3: Exact predictions (both legs) ──────────────────────────────
        exact1, exact2 = _count_exact_predictions(team1, team2, leg_mds[0], leg_mds[1])

        if exact1 != exact2:
            winner = team1 if exact1 > exact2 else team2
            results.append({"winner": winner, "reason": "exact predictions", "penalty": None})
            continue

        # ── Rule 4: Player goals (both legs) ───────────────────────────────────
        # Total prediction goals per team across both legs.
        # When aggregate is tied, these are equal by definition, but
        # the rule is included per VFL regulation.
        pg1 = agg1
        pg2 = agg2

        if pg1 != pg2:
            winner = team1 if pg1 > pg2 else team2
            results.append({"winner": winner, "reason": "player goals", "penalty": None})
            continue

        # ── Rule 5: Penalty shootout ───────────────────────────────────────────
        pen = _simulate_penalty(team1, team2)
        results.append({"winner": pen["winner"], "reason": "penalties", "penalty": pen})

    # Persist tie-break detail for display / audit
    data = _load()
    data.setdefault("two_leg_results", {}).setdefault(stage, {})["tiebreak_details"] = results
    _save(data)

    return results


# UEFA 2024/25 knockout bracket seed permutation.
# Maps playoff pair index (from FIXED_BRACKET_ORDER) → r16_direct list index.
#
#   Pair 0: (17v18) → seed 1  → directs[0]
#   Pair 1: (15v16) → seed 2  → directs[1]
#   Pair 2: (23v24) → seed 7  → directs[6]   ← non-sequential
#   Pair 3: (9v10)  → seed 8  → directs[7]   ← non-sequential
#   Pair 4: (21v22) → seed 5  → directs[4]
#   Pair 5: (11v12) → seed 6  → directs[5]
#   Pair 6: (19v20) → seed 3  → directs[2]   ← non-sequential
#   Pair 7: (13v14) → seed 4  → directs[3]   ← non-sequential
_UEFA_SEED_IDX: list[int] = [0, 1, 6, 7, 4, 5, 2, 3]


def build_next_stage_bracket(current_stage: str, winners: list[str]) -> list[dict]:
    """
    Build next stage bracket from winners.
    playoff → r16: pair each playoff winner with a direct qualifier (home=direct)
                   using the UEFA 2024/25 seed permutation (_UEFA_SEED_IDX).
    r16/qf/sf  →  qf/sf/final: sequential pairing [0v1, 2v3, ...]
    """
    if current_stage == "playoff":
        classification = get_classification()
        directs = classification.get("r16_direct", []) if classification else []
        pairs: list[dict] = []
        for i, winner in enumerate(winners):
            seed_idx = _UEFA_SEED_IDX[i] if i < len(_UEFA_SEED_IDX) else i
            direct = directs[seed_idx] if seed_idx < len(directs) else f"Тўғридан-тўғри {i + 1}"
            pairs.append({"home": direct, "away": winner})
        return pairs
    else:
        pairs = []
        for i in range(0, len(winners) - 1, 2):
            pairs.append({"home": winners[i], "away": winners[i + 1]})
        return pairs
