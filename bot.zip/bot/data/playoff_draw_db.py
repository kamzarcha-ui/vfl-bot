"""
Playoff draw storage for the VFL Champions League.

Fixed bracket: pairs are fixed adjacent position numbers per spec.
The /playoffdraw ceremony reveals team names — no randomness.
"""

import json
import os
from datetime import datetime, timezone

PLAYOFF_DRAW_FILE = os.path.join(os.path.dirname(__file__), "playoff_draw.json")

# Fixed bracket in ceremony reveal order (spec-defined)
# Each tuple: (pos1, pos2) — pos1 is home in leg 1
FIXED_BRACKET_ORDER: list[tuple[int, int]] = [
    (17, 18),
    (15, 16),
    (23, 24),
    (9,  10),
    (21, 22),
    (11, 12),
    (19, 20),
    (13, 14),
]


def _load() -> dict:
    if not os.path.exists(PLAYOFF_DRAW_FILE):
        return {}
    with open(PLAYOFF_DRAW_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(PLAYOFF_DRAW_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def draw_exists() -> bool:
    return bool(_load().get("pairings"))


def get_playoff_draw() -> dict | None:
    data = _load()
    return data if data.get("pairings") else None


def reset_playoff_draw() -> None:
    _save({})


def run_draw(standings: list[dict]) -> list[dict]:
    """
    Execute the fixed playoff draw.
    standings: list of {"pos": int, "team": str, ...}
    Returns list of pairing dicts stored with legacy upper/lower keys.
    Raises ValueError if any required position is missing.
    """
    by_pos: dict[int, str] = {s["pos"]: s["team"] for s in standings}

    pairings: list[dict] = []
    for p1, p2 in FIXED_BRACKET_ORDER:
        if p1 not in by_pos:
            raise ValueError(f"{p1}-ўрин турнир жадвалида топилмади.")
        if p2 not in by_pos:
            raise ValueError(f"{p2}-ўрин турнир жадвалида топилмади.")
        pairings.append({
            "upper_pos":  p1,
            "upper_team": by_pos[p1],
            "lower_pos":  p2,
            "lower_team": by_pos[p2],
        })

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    _save({"pairings": pairings, "timestamp": timestamp})
    return pairings
