import json
import os

TEAMS_FILE = os.path.join(os.path.dirname(__file__), "teams.json")
COACHES_FILE = os.path.join(os.path.dirname(__file__), "coaches.json")


# ── teams.json ────────────────────────────────────────────────────────────────

def load_teams() -> dict:
    if not os.path.exists(TEAMS_FILE):
        return {}
    with open(TEAMS_FILE, "r") as f:
        return json.load(f)


def save_teams(data: dict) -> None:
    with open(TEAMS_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── coaches.json ──────────────────────────────────────────────────────────────

def load_coaches() -> dict:
    if not os.path.exists(COACHES_FILE):
        return {}
    with open(COACHES_FILE, "r") as f:
        return json.load(f)


def save_coaches(data: dict) -> None:
    with open(COACHES_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── helpers ───────────────────────────────────────────────────────────────────

def get_available_teams() -> list[str]:
    """Return team names whose coach field is null (not yet taken)."""
    teams = load_teams()
    return [name for name, info in teams.items() if info.get("coach") is None]


def is_registered(telegram_id: int) -> bool:
    """
    Return True if this Telegram user is currently bound to a team.

    Checks teams.json (the authoritative binding), not coaches.json.
    This means a released coach whose profile is still in coaches.json
    is NOT considered registered and can pick a new club.
    """
    teams = load_teams()
    tid   = str(telegram_id)
    return any(str(info.get("telegram_id", "")) == tid for info in teams.values())


def next_license() -> str:
    """Generate the next sequential license number (VFL0001, VFL0002, …)."""
    teams = load_teams()
    coaches = load_coaches()

    existing: list[int] = []
    for info in teams.values():
        lic = info.get("license")
        if lic and lic.startswith("VFL"):
            try:
                existing.append(int(lic[3:]))
            except ValueError:
                pass
    for info in coaches.values():
        lic = info.get("license")
        if lic and lic.startswith("VFL"):
            try:
                existing.append(int(lic[3:]))
            except ValueError:
                pass

    number = max(existing, default=0) + 1
    return f"VFL{number:04d}"


def save_players(team_name: str, player_names: list[str]) -> None:
    """Persist a list of player names for a team. Each gets {name, goals: 0}."""
    teams = load_teams()
    if team_name not in teams:
        raise ValueError(f"Team '{team_name}' not found.")
    teams[team_name]["players"] = [{"name": p, "goals": 0} for p in player_names]
    save_teams(teams)


def get_coach_team(telegram_id: int) -> dict | None:
    """
    Return {"team": str, "players": list[str]} for the registered coach,
    or None if the user is not registered.

    Uses teams.json as the authoritative telegram_id binding (same source as
    is_registered) to guarantee both functions agree.  coaches.json is only
    consulted for player data and is never used for the tid lookup.
    """
    tid   = str(telegram_id)
    teams = load_teams()
    for team_name, info in teams.items():
        if str(info.get("telegram_id", "")) == tid:
            raw_players  = info.get("players", [])
            player_names = [p["name"] for p in raw_players if isinstance(p, dict)]
            return {"team": team_name, "players": player_names}
    return None


def get_all_player_names_lower(exclude_team: str | None = None) -> set[str]:
    """
    Return a set of all player names (lowercased) currently saved across every
    team, optionally excluding the players of one team (useful when validating
    a squad that is being built — the team's own in-progress names are checked
    separately against the session list).
    """
    teams = load_teams()
    names: set[str] = set()
    for team_name, info in teams.items():
        if exclude_team and team_name == exclude_team:
            continue
        for player in info.get("players", []):
            if isinstance(player, dict) and player.get("name"):
                names.add(player["name"].lower())
    return names


def get_team_players(team_name: str) -> list:
    """Return the players list for a team."""
    teams = load_teams()
    return teams.get(team_name, {}).get("players", [])


def get_all_registered() -> list[dict]:
    """Return all teams that have a coach assigned, sorted by team name."""
    teams = load_teams()
    result = []
    for team_name, info in sorted(teams.items()):
        if info.get("coach"):
            result.append({
                "team": team_name,
                "coach": info["coach"],
                "license": info.get("license") or "—",
                "players": [
                    p["name"] for p in info.get("players", [])
                    if isinstance(p, dict) and p.get("name")
                ],
            })
    return result


def remove_participant(team_name: str) -> bool:
    """
    Remove a coach from a team:
    - Resets team entry (coach/telegram_id/license → null, players → [])
    - Removes coach entry from coaches.json
    Returns True on success, False if team not found or already empty.
    """
    teams = load_teams()
    if team_name not in teams or not teams[team_name].get("coach"):
        return False

    coach_name = teams[team_name]["coach"]

    teams[team_name]["coach"] = None
    teams[team_name]["telegram_id"] = None
    teams[team_name]["license"] = None
    teams[team_name]["players"] = []
    save_teams(teams)

    coaches = load_coaches()
    if coach_name in coaches:
        del coaches[coach_name]
        save_coaches(coaches)

    return True


def register_coach(telegram_id: int, coach_name: str, team_name: str) -> str:
    """
    Assign a coach to a team and persist to both files.
    Returns the license string (reuses existing one for released coaches).
    Raises ValueError if the team is already taken or doesn't exist.
    """
    teams = load_teams()

    if team_name not in teams:
        raise ValueError(f"Team '{team_name}' not found.")
    if teams[team_name].get("coach") is not None:
        raise ValueError(f"Team '{team_name}' is already taken.")

    tid     = str(telegram_id)
    coaches = load_coaches()

    # Released coach re-registering: reuse their existing license and history.
    # Only update the binding fields (telegram_id, team); all stats/HOF preserved.
    if coach_name in coaches:
        license_no = coaches[coach_name].get("license") or next_license()
        coaches[coach_name]["telegram_id"] = tid
        coaches[coach_name]["team"]        = team_name
        coaches[coach_name]["license"]     = license_no
    else:
        license_no = next_license()
        coaches[coach_name] = {
            "telegram_id": tid,
            "team":        team_name,
            "license":     license_no,
        }

    # Update teams.json
    teams[team_name]["coach"]       = coach_name
    teams[team_name]["telegram_id"] = tid
    teams[team_name]["license"]     = license_no
    save_teams(teams)
    save_coaches(coaches)

    return license_no
