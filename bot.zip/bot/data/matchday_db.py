"""
Match Day storage: fixtures.json

Stores the current Match Day number, 5 fixtures, deadline, and timestamp.
Completely separate from the draw-based db.json fixtures.
"""

import json
import os
from datetime import datetime, timezone

MATCHDAY_FILE = os.path.join(os.path.dirname(__file__), "fixtures.json")


def _load() -> dict:
    if not os.path.exists(MATCHDAY_FILE):
        return {}
    with open(MATCHDAY_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(MATCHDAY_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


# ── Public API ────────────────────────────────────────────────────────────────

def matchday_exists() -> bool:
    return bool(_load().get("fixtures"))


def get_matchday() -> dict | None:
    data = _load()
    return data if data.get("fixtures") else None


def save_matchday(
    fixtures: list[dict],
    deadline_date: str,
    deadline_time: str,
) -> dict:
    """
    Persist a new Match Day.  Auto-increments match_day number.
    fixtures: list of {"home": str, "away": str}
    Returns the saved data dict.
    """
    prev = _load()
    prev_number = prev.get("match_day", 0)
    match_day = prev_number + 1 if prev.get("fixtures") else max(prev_number, 1)

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    data = {
        "match_day":     match_day,
        "fixtures":      fixtures,
        "deadline_date": deadline_date,
        "deadline_time": deadline_time,
        "timestamp":     timestamp,
    }
    _save(data)
    return data


def get_current_match_day_number() -> int:
    """Return the current match day counter (works even when no fixtures are set)."""
    return int(_load().get("match_day", 0))


def is_matchday_closed() -> bool:
    """True if /closematchday has been run and calculations are done."""
    return bool(_load().get("closed", False))


def set_matchday_closed() -> None:
    data = _load()
    data["closed"] = True
    _save(data)


def advance_matchday() -> int:
    """
    Called automatically after /closematchday succeeds.
    Pre-increments the match_day counter and clears all temporary state
    (fixtures, deadline, results, closed flag) so /setfixtures is immediately
    available for the next Match Day — no manual /resetfixtures required.
    Returns the new match_day number.
    """
    prev = _load()
    new_number = prev.get("match_day", 0) + 1
    _save({"match_day": new_number})
    return new_number


def reset_matchday() -> None:
    """Wipe the current Match Day (preserves match_day counter for next draw)."""
    prev = _load()
    _save({"match_day": prev.get("match_day", 0)})


def update_fixture(idx: int, home: str, away: str) -> None:
    """Replace one fixture in the current Match Day (0-indexed)."""
    data = _load()
    if not data.get("fixtures"):
        return
    data["fixtures"][idx] = {"home": home, "away": away}
    _save(data)


def update_date(new_date: str) -> None:
    """Update deadline_date in the current Match Day."""
    data = _load()
    data["deadline_date"] = new_date
    _save(data)


def update_time(new_time: str) -> None:
    """Update deadline_time in the current Match Day."""
    data = _load()
    data["deadline_time"] = new_time
    _save(data)


def parse_fixture_line(text: str) -> tuple[str, str] | None:
    """
    Parse "Team A vs Team B" → ("Team A", "Team B").
    Returns None if format is invalid.
    """
    lower = text.lower()
    if " vs " not in lower:
        return None
    idx = lower.index(" vs ")
    home = text[:idx].strip()
    away = text[idx + 4:].strip()
    if not home or not away:
        return None
    return home, away
