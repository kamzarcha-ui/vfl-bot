"""
News DB — auto-generated competition news.
Storage: bot/data/news.json  (max 50 items, newest first)

Public API:
  load_news()
  generate_and_store_news(match_day, standings_before, completed_stage=None)
"""

import json
import os
from datetime import datetime, timezone

_DIR       = os.path.dirname(__file__)
_NEWS_FILE = os.path.join(_DIR, "news.json")
_MAX       = 50


def load_news() -> list:
    if not os.path.exists(_NEWS_FILE):
        return []
    with open(_NEWS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data: list) -> None:
    with open(_NEWS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _prepend(items: list[dict]) -> None:
    """Add new items at the front, keep at most _MAX."""
    if not items:
        return
    news = load_news()
    _save((items + news)[:_MAX])


def prepend_news_items(items: list[dict]) -> None:
    """Public wrapper: prepend pre-built news items to news.json."""
    _prepend(items)


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M")


# ── Stage labels ──────────────────────────────────────────────────────────────

_MD_LABEL: dict[int, str] = {
    9:  "Плей-офф 1-тур",
    10: "Плей-офф 2-тур",
    11: "1/8 Финал 1-тур",
    12: "1/8 Финал 2-тур",
    13: "1/4 Финал 1-тур",
    14: "1/4 Финал 2-тур",
    15: "1/2 Финал 1-тур",
    16: "1/2 Финал 2-тур",
    17: "Финал",
}

_STAGE_NAME: dict[str, str] = {
    "playoff": "Плей-офф",
    "r16":     "1/8 Финал",
    "qf":      "1/4 Финал",
    "sf":      "1/2 Финал",
    "final":   "Финал",
}

_NEXT_STAGE_NAME: dict[str, str] = {
    "playoff": "1/8 Финал",
    "r16":     "1/4 Финал",
    "qf":      "1/2 Финал",
    "sf":      "Финал",
}


def _md_label(match_day: int) -> str:
    return _MD_LABEL.get(match_day, f"Лига босқичи {match_day}-тур")


# ── Main generation function ──────────────────────────────────────────────────

def generate_and_store_news(
    match_day: int,
    standings_before: list[dict],
    completed_stage: str | None = None,
) -> None:
    """
    Build and store news items after every MD closure.

    standings_before  — sorted standings list captured BEFORE duels were applied.
    completed_stage   — playoff stage just completed (leg 2 / final), or None.
    """
    from bot.data.db import get_duel_results
    from bot.data.league_stage_db import (
        build_standings_from_club_stats,
        get_classification,
        get_stage_winners,
    )

    items: list[dict] = []
    now = _ts()

    def _item(icon: str, itype: str, headline: str, body: str) -> dict:
        return {
            "date":      now,
            "match_day": match_day,
            "type":      itype,
            "icon":      icon,
            "headline":  headline,
            "body":      body,
        }

    # ── 1. Match Day completed (always) ───────────────────────────────────────
    items.append(_item(
        "✅", "md_completed",
        f"Match Day #{match_day} якунланди",
        f"{_md_label(match_day)} — барча ўйинлар ҳисобланди.",
    ))

    # ── 2. Biggest win / highest scoring ─────────────────────────────────────
    duels = get_duel_results(match_day)
    if duels:
        best_margin = 0
        best_duel: dict | None = None
        best_total  = 0
        best_total_duel: dict | None = None

        for d in duels:
            gh, ga = d["goals_home"], d["goals_away"]
            margin = abs(gh - ga)
            total  = gh + ga
            if margin > best_margin:
                best_margin = margin
                best_duel   = d
            if total > best_total:
                best_total      = total
                best_total_duel = d

        if best_duel and best_margin >= 3:
            gh, ga   = best_duel["goals_home"], best_duel["goals_away"]
            winner   = best_duel["home"] if gh > ga else best_duel["away"]
            loser    = best_duel["away"] if gh > ga else best_duel["home"]
            items.append(_item(
                "🔥", "biggest_win",
                f"Турнинг энг йирик ғалабаси: {max(gh,ga)}–{min(gh,ga)}",
                f"{winner} рақиби {loser} ни {best_margin} гол фарқ билан мағлуб этди.",
            ))

        if best_total_duel and best_total >= 6:
            gh, ga = best_total_duel["goals_home"], best_total_duel["goals_away"]
            home, away = best_total_duel["home"], best_total_duel["away"]
            items.append(_item(
                "⚽", "highest_scoring",
                f"Энг сергол ўйин: {gh}–{ga}",
                f"{home} 🆚 {away} — жами {best_total} гол.",
            ))

    # ── 3. League stage positional changes (MDs 1–8) ─────────────────────────
    if match_day <= 8 and standings_before:
        standings_after = build_standings_from_club_stats()

        pos_before: dict[str, int] = {s["team"]: s.get("pos", 99) for s in standings_before}
        pos_after:  dict[str, int] = {s["team"]: s.get("pos", 99) for s in standings_after}

        # New league leader
        leader_b = standings_before[0]["team"] if standings_before else ""
        leader_a = standings_after[0]["team"]  if standings_after  else ""
        if leader_a and leader_a != leader_b:
            items.append(_item(
                "📈", "new_leader",
                f"Янги лига лидери: {leader_a}!",
                f"{leader_a}, {leader_b or '...'} ўрнига жадвал бошига кўтарилди.",
            ))

        # Teams newly in top 8
        top8_b = {s["team"] for s in standings_before if s.get("pos", 99) <= 8}
        top8_a = {s["team"] for s in standings_after  if s.get("pos", 99) <= 8}
        for team in sorted(top8_a - top8_b):
            pos = pos_after.get(team, "?")
            items.append(_item(
                "🏅", "enters_top8",
                f"{team} ТОП-8 га кирди!",
                f"{team} {pos}-ўринга кўтарилди — тўғридан-тўғри 1/8 финал зонасида.",
            ))

        # Teams newly in playoff zone (9–24)
        po_b = {s["team"] for s in standings_before if 8 < s.get("pos", 99) <= 24}
        po_a = {s["team"] for s in standings_after  if 8 < s.get("pos", 99) <= 24}
        for team in sorted((po_a - po_b) - top8_b):
            if team not in top8_a:
                pos = pos_after.get(team, "?")
                items.append(_item(
                    "🔥", "enters_playoff",
                    f"{team} плей-офф зонасига кирди!",
                    f"{team} {pos}-ўрин билан плей-офф ўйнашga ҳақ қозонди.",
                ))

        # Teams newly in eliminated zone (25+)
        elim_b = {s["team"] for s in standings_before if s.get("pos", 99) >= 25}
        elim_a = {s["team"] for s in standings_after  if s.get("pos", 99) >= 25}
        for team in sorted(elim_a - elim_b):
            pos = pos_after.get(team, "?")
            items.append(_item(
                "📉", "relegated_zone",
                f"{team} тугаш зонасига тушди",
                f"{team} {pos}-ўринда — лига босқичини тугатиш хавфи бор.",
            ))

    # ── 4. MD8 final classification ───────────────────────────────────────────
    if match_day == 8:
        clf = get_classification()
        if clf:
            r16_direct = clf.get("r16_direct", [])
            po_zone    = clf.get("playoff_zone", [])
            eliminated = clf.get("eliminated", [])

            if r16_direct:
                items.append(_item(
                    "🎟", "r16_direct_confirmed",
                    f"8 жамоа тўғридан-тўғри 1/8 финалга чиқди!",
                    ", ".join(r16_direct[:8]) + " — ТОП-8 ўринлар.",
                ))
            if po_zone:
                items.append(_item(
                    "🔥", "playoff_zone_set",
                    f"{len(po_zone)} жамоа плей-офф ўйнайди",
                    "9–24 ўринлар плей-офф учрашувига чиқди.",
                ))
            if eliminated:
                elim_str = ", ".join(eliminated[:5]) + ("…" if len(eliminated) > 5 else "")
                items.append(_item(
                    "😢", "eliminated_confirmed",
                    f"{len(eliminated)} жамоа турнирдан чиқди",
                    f"{elim_str} — лига босқичини якунлади.",
                ))

    # ── 5. Playoff stage completion ───────────────────────────────────────────
    if completed_stage:
        winners = get_stage_winners(completed_stage)
        winners_str = ", ".join(winners) if winners else "—"

        if completed_stage == "final" and winners:
            items.append(_item(
                "👑", "champion_confirmed",
                f"VFL чемпиони: {winners[0]}! 🎉",
                f"{winners[0]} VFL Champions League чемпиони бўлди. Табриклаймиз!",
            ))
        else:
            stage_lbl    = _STAGE_NAME.get(completed_stage, completed_stage)
            next_lbl     = _NEXT_STAGE_NAME.get(completed_stage, "")
            next_part    = f" — {next_lbl} учрашувлари аниқланди." if next_lbl else "."
            items.append(_item(
                "🏆", f"{completed_stage}_completed",
                f"{stage_lbl} якунланди!",
                f"Кейинги босқичга ўтганлар: {winners_str}{next_part}",
            ))

    _prepend(items)
