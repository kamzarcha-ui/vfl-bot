"""
Persistent edit history for Match Day changes.
Stored in bot/data/edit_history.json — survives bot restarts.
"""

import json
import os
from datetime import datetime, timezone

HISTORY_FILE = os.path.join(os.path.dirname(__file__), "edit_history.json")


def _load() -> list:
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE) as f:
        return json.load(f)


def _save(data: list) -> None:
    with open(HISTORY_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def log_edit(
    admin_id:    int,
    change_type: str,          # "date" | "time" | "match"
    old_value:   str,
    new_value:   str,
    match_idx:   int | None = None,
) -> None:
    """Append one edit record to the history file."""
    entry: dict = {
        "admin_id":    admin_id,
        "timestamp":   datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "change_type": change_type,
        "old_value":   old_value,
        "new_value":   new_value,
    }
    if match_idx is not None:
        entry["match_idx"] = match_idx
    history = _load()
    history.append(entry)
    _save(history)


def get_history() -> list:
    """Return all edit history entries (oldest first)."""
    return _load()
