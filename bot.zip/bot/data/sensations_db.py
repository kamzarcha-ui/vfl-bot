"""
Sensations DB — detect and store sensational competition events.
Storage: bot/data/sensations.json  (max 50 items, newest first)

Public API:
  load_sensations()
  detect_and_store_sensations(match_day, standings_before, completed_stage=None)
"""

import json
import os
from datetime import datetime, timezone

_DIR             = os.path.dirname(__file__)
_SENS_FILE       = os.path.join(_DIR, "sensations.json")
_MAX             = 50
_UPSET_GAP       = 15   # minimum rank difference to call it an upset
_HUGE_MARGIN     = 5    # goal difference for "huge win"


def load_sensations() -> list:
    if not os.path.exists(_SENS_FILE):
        return []
    with open(_SENS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data: list) -> None:
    with open(_SENS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _prepend(items: list[dict]) -> None:
    if not items:
        return
    sens = load_sensations()
    _save((items + sens)[:_MAX])


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M")


def detect_and_store_sensations(
    match_day: int,
    standings_before: list[dict],
    completed_stage: str | None = None,
) -> None:
    """
    Detect sensational events after a MD closure.

    Detects:
      • Huge upsets (underdog beats favourite by ≥15 rank positions)
      • Huge win margins (≥5 goal difference)
      • Unexpected elimination of high-ranked teams (MD8)
      • Unexpected qualification of low-ranked teams (MD8)
      • Playoff underdogs reaching advanced stages
    """
    from bot.data.db import get_duel_results
    from bot.data.league_stage_db import get_classification, get_stage_winners

    items: list[dict] = []
    now = _ts()

    def _item(icon: str, itype: str, headline: str, body: str) -> dict:
        return {
            "date":      now,
            "match_day": match_day,
            "type":      itype,
            "icon":      icon,
            "headline":  headline,
            "body":      body,
        }

    # Build rank lookup (lower pos number = better rank)
    rank_before: dict[str, int] = {s["team"]: s.get("pos", 99) for s in standings_before}

    duels = get_duel_results(match_day)

    for d in duels:
        home, away = d["home"], d["away"]
        gh, ga     = d["goals_home"], d["goals_away"]
        margin     = abs(gh - ga)

        if gh == ga:
            winner = loser = None
        elif gh > ga:
            winner, loser = home, away
        else:
            winner, loser = away, home

        # ── Upset: winner is ranked WORSE (higher number) than loser ─────────
        if winner and loser:
            rank_w = rank_before.get(winner, 99)
            rank_l = rank_before.get(loser,  99)
            gap    = rank_w - rank_l   # positive → underdog won
            if gap >= _UPSET_GAP:
                w_goals = max(gh, ga)
                l_goals = min(gh, ga)
                items.append(_item(
                    "😱", "upset",
                    f"Сенсация! {winner} ({rank_w}-ўрин) фаворитни мағлуб этди!",
                    (
                        f"{rank_l}-ўрин {loser} устидан {winner} ({rank_w}-ўрин) "
                        f"{w_goals}–{l_goals} ҳисобида ғалаба қозонди. "
                        f"Рейтинг фарқи: {gap} поғона!"
                    ),
                ))

        # ── Huge win: goal margin ≥ _HUGE_MARGIN ─────────────────────────────
        if margin >= _HUGE_MARGIN and winner and loser:
            w_goals = max(gh, ga)
            l_goals = min(gh, ga)
            items.append(_item(
                "💥", "huge_win",
                f"Улкан ғалаба! {winner} {w_goals}–{l_goals}",
                f"{winner} рақиби {loser} ни {margin} гол фарқ билан мағлуб этди!",
            ))

    # ── MD8: unexpected eliminations and qualifications ───────────────────────
    if match_day == 8:
        clf = get_classification() or {}
        eliminated = clf.get("eliminated", [])
        r16_direct = clf.get("r16_direct", [])

        # High-ranked team eliminated
        for team in eliminated:
            pre = rank_before.get(team, 99)
            if pre <= 10:
                items.append(_item(
                    "😮", "unexpected_elimination",
                    f"Сенсация! {team} турнирдан чиқди",
                    (
                        f"Лига бошида {pre}-ўринда бўлган {team} "
                        f"элиминация зонасида мавсумни якунлади."
                    ),
                ))

        # Low-ranked team reaches direct R16
        for team in r16_direct:
            pre = rank_before.get(team, 99)
            if pre >= 20:
                items.append(_item(
                    "🚀", "unexpected_r16_direct",
                    f"Сенсация! {team} тўғридан-тўғри 1/8 финалга чиқди!",
                    (
                        f"Лига бошида {pre}-ўринда бўлган {team} "
                        f"ТОП-8 да мавсумни якунлади!"
                    ),
                ))

    # ── Playoff underdog advancing through advanced stages ────────────────────
    if completed_stage and completed_stage in ("qf", "sf", "final"):
        clf         = get_classification() or {}
        direct_r16  = set(clf.get("r16_direct", []))
        winners     = get_stage_winners(completed_stage)

        stage_labels = {
            "qf":    "1/4 финал",
            "sf":    "1/2 финал",
            "final": "Финал",
        }
        lbl = stage_labels.get(completed_stage, completed_stage)

        for winner in (winners or []):
            if winner not in direct_r16:
                items.append(_item(
                    "🚀", "playoff_underdog",
                    f"Сенсация! {winner} {lbl} га ўтди!",
                    (
                        f"Лигани тўғридан-тўғри квалификацияда якунламаган {winner} "
                        f"плей-офф орқали {lbl} га йўл олди!"
                    ),
                ))

    _prepend(items)
