"""
Hall of Fame data layer.

Storage:
  hall_of_fame_records.json  — current record holder per category
  hall_of_fame_history.json  — append-only log of every broken record

Main public entry point:
  check_and_update_records(season, bot, completed_stage=None)
    → computes snapshot, detects new records, saves, appends history, broadcasts
    → returns list[dict] of newly broken records
"""

import json
import os
from datetime import datetime, timezone
from typing import Any

_DIR = os.path.dirname(__file__)
_RECORDS_FILE = os.path.join(_DIR, "hall_of_fame_records.json")
_HISTORY_FILE = os.path.join(_DIR, "hall_of_fame_history.json")

# ── Storage I/O ───────────────────────────────────────────────────────────────

def _load_records() -> dict:
    if not os.path.exists(_RECORDS_FILE):
        return {}
    with open(_RECORDS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_records(data: dict) -> None:
    with open(_RECORDS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _load_history() -> list:
    if not os.path.exists(_HISTORY_FILE):
        return []
    with open(_HISTORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _append_history(entry: dict) -> None:
    history = _load_history()
    history.append(entry)
    with open(_HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)


def get_hof_history() -> list:
    """Return full record history list."""
    return _load_history()


def get_hof_records() -> dict:
    """Return current record holders dict."""
    return _load_records()


# ── Record metadata ───────────────────────────────────────────────────────────

# (label_uz, record_type, lower_is_better)
_META: dict[str, tuple[str, str, bool]] = {
    # Team — records
    "team_most_wins":           ("Энг кўп ғалаба — Жамоа",              "record",       False),
    "team_most_goals":          ("Энг кўп гол — Жамоа",                 "record",       False),
    "team_most_points":         ("Энг кўп очко — Жамоа",                "record",       False),
    "team_highest_pts_season":  ("Бир мавсумдаги энг кўп очко",         "record",       False),
    "team_win_streak":          ("Энг узун ғалабалар серияси",           "record",       False),
    "team_best_defensive":      ("Энг кам гол ўтказган мавсум",         "record",       True),
    "team_biggest_win":         ("Энг йирик ғалаба",                     "record",       False),
    "team_highest_scoring":     ("Энг сергол ўйин",                      "record",       False),
    "team_most_champions":      ("Энг кўп чемпион",                     "record",       False),
    "team_most_finals":         ("Энг кўп финал",                       "record",       False),
    "team_most_semis":          ("Энг кўп ярим финал",                  "record",       False),
    "team_most_quarters":       ("Энг кўп чорак финал",                 "record",       False),
    "team_most_r16":            ("Энг кўп 1/8 финал",                   "record",       False),
    "team_most_playoff":        ("Энг кўп плей-офф",                    "record",       False),
    # Team — anti-records
    "team_most_defeats":        ("Энг кўп мағлубият",                   "anti-record",  False),
    "team_worst_pts":           ("Энг ёмон мавсум (кам очко)",          "anti-record",  True),
    "team_lose_streak":         ("Энг узун мағлубиятлар серияси",       "anti-record",  False),
    "team_winless_run":         ("Энг узун ғалабасиз серия",            "anti-record",  False),
    "team_most_failed_league":  ("Лига босқичидан чиқа олмаган",        "anti-record",  False),
    "team_most_lost_finals":    ("Энг кўп финалда мағлуб бўлган",      "anti-record",  False),
    "team_most_last_place":     ("Энг кўп охирги ўрин",                 "anti-record",  False),
    "team_biggest_loss":        ("Энг йирик мағлубият",                  "anti-record",  False),
    # Coach — records
    "coach_most_exact":         ("Энг кўп аниқ ҳисоб — Мураббий",     "record",       False),
    "coach_most_golden_predictor": ("Энг кўп Golden Predictor — Мураббий", "record",   False),
    "coach_most_goals":         ("Энг кўп гол — Мураббий",             "record",       False),
    "coach_best_season":        ("Энг яхши мавсум — Мураббий",         "record",       False),
    "coach_most_champions":     ("Энг кўп чемпионлик — Мураббий",      "record",       False),
    "coach_most_finals":        ("Энг кўп финал — Мураббий",           "record",       False),
    "coach_most_participations":("Энг кўп иштирок — Мураббий",         "record",       False),
    "coach_unbeaten_streak":    ("Энг узун мағлубиятсиз серия — Мураббий", "record",   False),
    "coach_most_exact_per_md":  ("Бир Match Day даги энг кўп аниқ ҳисоб — Мураббий", "record", False),
    # Coach — anti-records
    "coach_least_exact":        ("Энг кам аниқ ҳисоб — Мураббий",     "anti-record",  False),
    "coach_most_lost_finals":   ("Энг кўп финал ютқазган — Мураббий", "anti-record",  False),
    "coach_most_failed_league": ("Лига босқичидан чиқа олмаган — Мураббий", "anti-record", False),
    "coach_worst_season":       ("Энг ёмон мавсум — Мураббий",         "anti-record",  True),
    # Player — records
    "player_most_goals":        ("Энг кўп гол — Ўйинчи",              "record",       False),
    "player_most_goals_season": ("Бир мавсумдаги энг кўп гол — Ўйинчи", "record",     False),
    "player_most_golden_boot":  ("Энг кўп Golden Boot — Ўйинчи",      "record",       False),
    "player_most_dream_team":   ("Энг кўп Dream Team — Ўйинчи",       "record",       False),
    "player_best_player_awards":("Энг яхши футболчи — Ўйинчи",        "record",       False),
    "player_most_goals_per_md": ("Бир Match Day даги энг кўп гол — Ўйинчи", "record",  False),
    # Player — anti-records
    "player_goalless_count":    ("Голсиз ўйинчилар сони",              "anti-record",  False),
    "player_goalless_seasons":  ("Энг кўп голсиз мавсум — Ўйинчи",    "anti-record",  False),
    "player_goal_drought":      ("Энг узун голсиз серия — Ўйинчи",     "anti-record",  False),
    "player_most_second_place": ("Энг кўп иккинчи ўринда қолган тўпурар", "anti-record", False),
}


# ── Streak helpers ────────────────────────────────────────────────────────────

def _walk_team_sequences() -> dict[str, list[str]]:
    """
    Walk duel_results for MDs 1-17 and return {team: [W/D/L, ...]} sequences.
    """
    from bot.data.db import get_duel_results

    seqs: dict[str, list[str]] = {}
    for md in range(1, 18):
        for d in get_duel_results(md):
            home, away = d["home"], d["away"]
            gh, ga = d["goals_home"], d["goals_away"]
            if gh > ga:
                rh, ra = "W", "L"
            elif gh < ga:
                rh, ra = "L", "W"
            else:
                rh, ra = "D", "D"
            seqs.setdefault(home, []).append(rh)
            seqs.setdefault(away, []).append(ra)
    return seqs


def _max_run(seq: list[str], targets: set[str]) -> int:
    best = cur = 0
    for r in seq:
        if r in targets:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


# ── Snapshot ─────────────────────────────────────────────────────────────────

def compute_snapshot(season: int) -> dict[str, dict[str, Any]]:
    """
    Read all live data and return {record_key: {"holder": str, "value": int/float, "season": int}}.
    Only entries with value > 0 are included (or < infinity for lower-is-better).
    """
    from bot.data.db import get_club_stats, get_duel_results
    from bot.data.teams_db import load_coaches, load_teams
    from bot.data.league_stage_db import get_stage_winners, get_classification

    snap: dict[str, dict] = {}

    def _put(key: str, holder: str, value: int | float) -> None:
        if holder:
            snap[key] = {"holder": holder, "value": value, "season": season}

    def _put_if_positive(key: str, holder: str, value: int | float) -> None:
        if holder and value > 0:
            snap[key] = {"holder": holder, "value": value, "season": season}

    # ── Club stats ────────────────────────────────────────────────────────────
    club_stats = get_club_stats()

    if club_stats:
        played_filter = {t: s for t, s in club_stats.items() if s.get("played", 0) > 0}

        if played_filter:
            top_wins  = max(played_filter.items(), key=lambda x: x[1].get("w", 0))
            top_goals = max(played_filter.items(), key=lambda x: x[1].get("gf", 0))
            top_pts   = max(played_filter.items(), key=lambda x: x[1].get("pts", 0))
            top_def   = min(
                [i for i in played_filter.items() if i[1].get("played", 0) >= 5],
                key=lambda x: x[1].get("ga", 9999),
                default=None,
            )
            top_def5  = min(
                [i for i in played_filter.items() if i[1].get("played", 0) >= 5],
                key=lambda x: x[1].get("pts", 9999),
                default=None,
            )
            top_defeats = max(played_filter.items(), key=lambda x: x[1].get("l", 0))

            _put_if_positive("team_most_wins",          top_wins[0],    top_wins[1].get("w", 0))
            _put_if_positive("team_most_goals",         top_goals[0],   top_goals[1].get("gf", 0))
            _put_if_positive("team_most_points",        top_pts[0],     top_pts[1].get("pts", 0))
            _put_if_positive("team_highest_pts_season", top_pts[0],     top_pts[1].get("pts", 0))
            _put_if_positive("team_most_defeats",       top_defeats[0], top_defeats[1].get("l", 0))

            # lower-is-better records stored with actual low value
            if top_def:
                _put("team_best_defensive", top_def[0], top_def[1].get("ga", 9999))
            if top_def5:
                _put("team_worst_pts", top_def5[0], top_def5[1].get("pts", 9999))

    # ── Per-match biggest win / highest scoring ───────────────────────────────
    biggest_margin = 0
    biggest_winner = ""
    highest_total  = 0
    highest_label  = ""

    for md in range(1, 18):
        for d in get_duel_results(md):
            gh, ga = d["goals_home"], d["goals_away"]
            margin = abs(gh - ga)
            total  = gh + ga
            if margin > biggest_margin:
                biggest_margin = margin
                biggest_winner = d["home"] if gh > ga else d["away"]
            if total > highest_total:
                highest_total = total
                highest_label = f"{d['home']} 🆚 {d['away']}"

    _put_if_positive("team_biggest_win",     biggest_winner, biggest_margin)
    _put_if_positive("team_highest_scoring", highest_label,  highest_total)

    # biggest loss: biggest margin suffered by the losing team
    worst_margin = 0
    worst_loser  = ""
    for md in range(1, 18):
        for d in get_duel_results(md):
            gh, ga = d["goals_home"], d["goals_away"]
            margin = abs(gh - ga)
            if margin > worst_margin:
                worst_margin = margin
                worst_loser  = d["away"] if gh > ga else d["home"]
    _put_if_positive("team_biggest_loss", worst_loser, worst_margin)

    # ── Team streaks ──────────────────────────────────────────────────────────
    seqs = _walk_team_sequences()
    if seqs:
        best_ws = max(seqs.items(), key=lambda x: _max_run(x[1], {"W"}),      default=None)
        best_ls = max(seqs.items(), key=lambda x: _max_run(x[1], {"L"}),      default=None)
        best_wl = max(seqs.items(), key=lambda x: _max_run(x[1], {"D", "L"}), default=None)

        if best_ws:
            v = _max_run(best_ws[1], {"W"})
            _put_if_positive("team_win_streak",   best_ws[0], v)
        if best_ls:
            v = _max_run(best_ls[1], {"L"})
            _put_if_positive("team_lose_streak",  best_ls[0], v)
        if best_wl:
            v = _max_run(best_wl[1], {"D", "L"})
            _put_if_positive("team_winless_run",  best_wl[0], v)

    # ── Playoff advancement (cumulative counts from stored records) ───────────
    # We build cumulative counters by adding 1 for the current season's achievers
    # on top of what was previously stored (handled in _update_cumulative).
    # Here we simply read the existing stored cumulative data to form the snapshot.
    stored = _load_records()
    for cum_key in (
        "team_most_champions", "team_most_finals", "team_most_semis",
        "team_most_quarters", "team_most_r16", "team_most_playoff",
        "team_most_failed_league", "team_most_lost_finals",
        "coach_most_champions", "coach_most_finals",
        "coach_most_lost_finals", "coach_most_failed_league",
        "coach_most_participations",
    ):
        if cum_key in stored:
            e = stored[cum_key]
            snap[cum_key] = e  # keep as-is; updated via _update_cumulative

    # ── Coach stats ───────────────────────────────────────────────────────────
    coaches = load_coaches()
    if coaches:
        by_exact = max(coaches.items(), key=lambda x: x[1].get("exact_predictions", 0))
        by_goals = max(coaches.items(), key=lambda x: x[1].get("matchday_goals", 0))
        by_least = min(coaches.items(), key=lambda x: x[1].get("exact_predictions", 9999))

        _put_if_positive("coach_most_exact",  by_exact[0], by_exact[1].get("exact_predictions", 0))
        _put_if_positive("coach_most_goals",  by_goals[0], by_goals[1].get("matchday_goals", 0))
        _put_if_positive("coach_best_season", by_goals[0], by_goals[1].get("matchday_goals", 0))

        # least exact: anti-record — store raw value; lower value = new anti-record
        least_val = by_least[1].get("exact_predictions", 0)
        _put("coach_least_exact", by_least[0], least_val)

        # worst season: coach with fewest matchday_goals (lower = worse, lower-is-better key)
        by_worst = min(coaches.items(), key=lambda x: x[1].get("matchday_goals", 9999))
        _put("coach_worst_season", by_worst[0], by_worst[1].get("matchday_goals", 9999))

        # participations: every registered coach counts as 1 for Season 1 baseline
        if "coach_most_participations" not in snap:
            top_p = list(coaches.keys())[0]
            snap["coach_most_participations"] = {"holder": top_p, "value": 1, "season": season}

    # ── Coach unbeaten streak ─────────────────────────────────────────────────
    if coaches and seqs:
        team_to_coach = {
            info.get("team", ""): name
            for name, info in coaches.items()
            if info.get("team")
        }
        best_ub: tuple[str, int] | None = None
        for team, seq in seqs.items():
            coach = team_to_coach.get(team)
            if not coach:
                continue
            ub = _max_run(seq, {"W", "D"})
            if ub > 0 and (best_ub is None or ub > best_ub[1]):
                best_ub = (coach, ub)
        if best_ub:
            _put_if_positive("coach_unbeaten_streak", best_ub[0], best_ub[1])

    # ── Player stats ──────────────────────────────────────────────────────────
    teams = load_teams()
    max_g   = 0
    top_p   = ""
    goalless = 0

    for team_name, team_info in teams.items():
        for pl in team_info.get("players", []):
            if not isinstance(pl, dict):
                continue
            g    = pl.get("goals", 0)
            name = pl.get("name", "")
            if not name:
                continue
            if g > max_g:
                max_g = g
                top_p = f"{name} ({team_name})"
            if g == 0:
                goalless += 1

    _put_if_positive("player_most_goals",        top_p, max_g)
    _put_if_positive("player_most_goals_season", top_p, max_g)
    _put_if_positive("player_goalless_count",    "—",   goalless)

    return snap


# ── Cumulative updater (called on stage completion) ───────────────────────────

def update_cumulative_on_stage(stage: str, season: int) -> None:
    """
    Increment cumulative counters for teams/coaches that advanced through a stage.
    Called after each second-leg completion and after the final.
    """
    from bot.data.teams_db import load_coaches
    from bot.data.league_stage_db import get_stage_winners, get_classification

    stored = _load_records()

    def _inc(key: str, names: list[str]) -> None:
        if not names:
            return
        # Build/update per-name tally
        tally_key = f"_tally_{key}"
        tally: dict[str, int] = stored.get(tally_key, {})
        for name in names:
            tally[name] = tally.get(name, 0) + 1
        stored[tally_key] = tally
        # Record holder = name with highest count
        best_name = max(tally.items(), key=lambda x: x[1])
        stored[key] = {"holder": best_name[0], "value": best_name[1], "season": season}

    coaches = load_coaches()
    team_to_coach: dict[str, str] = {
        info.get("team", ""): name
        for name, info in coaches.items()
        if info.get("team")
    }

    if stage == "final":
        winners = get_stage_winners("final")
        if winners:
            _inc("team_most_champions", [winners[0]])
            coach = team_to_coach.get(winners[0])
            if coach:
                _inc("coach_most_champions", [coach])

        # Final losers: all sf_winners who are NOT in final_winners
        sf_winners = get_stage_winners("sf")
        if sf_winners and winners:
            losers = [t for t in sf_winners if t != winners[0]]
            _inc("team_most_lost_finals", losers)
            for t in losers:
                c = team_to_coach.get(t)
                if c:
                    _inc("coach_most_lost_finals", [c])

    if stage in ("final", "sf"):
        sf_winners = get_stage_winners("sf")
        _inc("team_most_finals", sf_winners or [])
        for t in (sf_winners or []):
            c = team_to_coach.get(t)
            if c:
                _inc("coach_most_finals", [c])

    if stage in ("final", "sf", "qf"):
        qf_winners = get_stage_winners("qf")
        _inc("team_most_semis", qf_winners or [])

    if stage in ("final", "sf", "qf", "r16"):
        r16_winners = get_stage_winners("r16")
        _inc("team_most_quarters", r16_winners or [])

    if stage in ("final", "sf", "qf", "r16", "playoff"):
        po_winners = get_stage_winners("playoff")
        _inc("team_most_r16", po_winners or [])

    if stage == "playoff":
        clf = get_classification()
        if clf:
            po_zone = clf.get("playoff_zone", [])
            _inc("team_most_playoff", po_zone)
            elim = clf.get("eliminated", [])
            _inc("team_most_failed_league", elim)
            for t in elim:
                c = team_to_coach.get(t)
                if c:
                    _inc("coach_most_failed_league", [c])

    # Participations: increment for all registered coaches each season
    tally_p: dict[str, int] = stored.get("_tally_coach_most_participations", {})
    for coach_name in coaches:
        tally_p[coach_name] = tally_p.get(coach_name, 0) + 1
    stored["_tally_coach_most_participations"] = tally_p
    if tally_p:
        best_p = max(tally_p.items(), key=lambda x: x[1])
        stored["coach_most_participations"] = {
            "holder": best_p[0], "value": best_p[1], "season": season
        }

    _save_records(stored)


# ── Comparison ────────────────────────────────────────────────────────────────

def _is_new_record(key: str, new_val: Any, stored_entry: dict | None) -> bool:
    """Return True if new_val represents a broken record vs stored_entry."""
    _, _, lower_is_better = _META.get(key, ("", "record", False))

    if stored_entry is None:
        # First time: set the record if value is non-trivial
        if lower_is_better:
            return isinstance(new_val, (int, float)) and new_val < 9999
        return isinstance(new_val, (int, float)) and new_val > 0

    old_val = stored_entry.get("value", 0)

    if lower_is_better:
        return isinstance(new_val, (int, float)) and new_val < old_val
    return isinstance(new_val, (int, float)) and new_val > old_val


# ── Combined report builder ───────────────────────────────────────────────────

def _build_combined_report(broken: list[dict], match_day: int) -> str:
    """
    Build one combined Hall of Fame broadcast message for all broken records.
    Returns empty string when broken is empty.
    """
    if not broken:
        return ""

    lines: list[str] = [
        "🏛 <b>VFL HALL OF FAME</b>\n",
        f"📊 <b>Match Day #{match_day} якунланди</b>",
    ]

    for entry in broken:
        rec_type = entry.get("type", "record")
        holder   = entry["new_holder"]
        value    = entry["new_value"]
        label    = entry["category_label"]

        lines.append("\n━━━━━━━━━━━━━━━━━━━━")

        if rec_type == "record":
            lines.append(f"\n🔥 <b>ЯНГИ РЕКОРД</b>\n")
            lines.append(f"🏆 <b>{holder}</b>")
            lines.append(f"<b>{value}</b>")
            lines.append(f"<i>{label} рекорди янгиланди!</i>")
        else:
            lines.append(f"\n😂 <b>ЯНГИ АНТИРЕКОРД</b>\n")
            lines.append(f"💔 <b>{holder}</b>")
            lines.append(f"<b>{value}</b>")
            lines.append(f"<i>{label}</i>")

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")
    lines.append("\n🏛 Hall of Fame янгиланди.")
    return "\n".join(lines)


async def _broadcast_combined(bot, text: str) -> None:
    """Send text to GROUP_ID (if set) and all registered participants."""
    import os
    from bot.data.teams_db import load_teams

    group_id = os.environ.get("GROUP_ID")
    if group_id:
        try:
            await bot.send_message(int(group_id), text, parse_mode="HTML")
        except Exception:
            pass

    for info in load_teams().values():
        tid = info.get("telegram_id")
        if not tid:
            continue
        try:
            await bot.send_message(int(tid), text, parse_mode="HTML")
        except Exception:
            pass


# ── Main trigger ──────────────────────────────────────────────────────────────

async def check_and_update_records(
    season: int,
    bot,
    match_day: int = 0,
    completed_stage: str | None = None,
) -> list[dict]:
    """
    1. If completed_stage given, update cumulative counters first.
    2. Compute full snapshot.
    3. Compare against stored records.
    4. Persist new records + history entries.
    5. If any records broken: send ONE combined report to GROUP_ID + all participants.
    6. Return list of newly broken records.
    """
    if completed_stage:
        update_cumulative_on_stage(completed_stage, season)

    snapshot = compute_snapshot(season)
    stored   = _load_records()
    broken:  list[dict] = []
    now      = datetime.now(timezone.utc).strftime("%d.%m.%Y")

    for key, current in snapshot.items():
        if key.startswith("_tally_"):
            continue
        label, rec_type, _ = _META.get(key, (key, "record", False))
        old_entry = stored.get(key)

        if not _is_new_record(key, current.get("value"), old_entry):
            continue

        entry = {
            "date":            now,
            "season":          season,
            "category":        key,
            "category_label":  label,
            "old_holder":      old_entry.get("holder") if old_entry else None,
            "old_value":       old_entry.get("value", 0) if old_entry else 0,
            "new_holder":      current["holder"],
            "new_value":       current["value"],
            "type":            rec_type,
        }
        _append_history(entry)
        stored[key] = current
        broken.append(entry)

    _save_records(stored)

    # Broadcast removed: HOF records are only shown via the Hall of Fame button.
    # Records are still saved to file and history above.

    return broken
