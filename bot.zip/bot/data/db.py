import json
import os

DB_FILE = os.path.join(os.path.dirname(__file__), "db.json")


def _load() -> dict:
    if not os.path.exists(DB_FILE):
        return {"predictions": {}, "fixtures": [], "standings": [], "matchups": []}
    with open(DB_FILE, "r") as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=2)


def get_fixtures() -> list:
    return _load().get("fixtures", [])


def get_fixtures_by_ids(fixture_ids: list[str]) -> list:
    """Return fixture dicts for the given IDs, preserving order."""
    all_fixtures = {f["id"]: f for f in _load().get("fixtures", [])}
    return [all_fixtures[fid] for fid in fixture_ids if fid in all_fixtures]


def get_standings() -> list:
    return _load().get("standings", [])


def get_predictions(user_id: int) -> dict:
    """
    Returns a dict keyed by match_id.
    Each value is {"score": str, "player": str}.
    Legacy string values are normalised on read.
    """
    raw = _load().get("predictions", {}).get(str(user_id), {})
    normalised: dict = {}
    for match_id, val in raw.items():
        if isinstance(val, dict):
            normalised[match_id] = val
        else:
            normalised[match_id] = {"score": str(val), "player": ""}
    return normalised


def save_prediction(user_id: int, match_id: str, score: str, player: str) -> None:
    data = _load()
    if "predictions" not in data:
        data["predictions"] = {}
    uid = str(user_id)
    if uid not in data["predictions"]:
        data["predictions"][uid] = {}
    data["predictions"][uid][match_id] = {"score": score, "player": player}
    _save(data)


# ── matchup helpers ───────────────────────────────────────────────────────────

def get_matchup_for_coach(telegram_id: int, round_no: int) -> dict | None:
    """
    Return the matchup dict for a coach in the given round, or None.
    Structure: {"round": int, "fixture_ids": [...], "coach_a": "tid", "coach_b": "tid"}
    """
    tid = str(telegram_id)
    for m in _load().get("matchups", []):
        if m.get("round") == round_no and tid in (m.get("coach_a", ""), m.get("coach_b", "")):
            return m
    return None


def get_opponent_scorelines(matchup: dict, user_id: int) -> dict[str, str]:
    """
    Return {fixture_id: score} for every fixture where the opponent has
    already submitted a prediction.  The caller must check the score for
    the specific fixture being entered — not across all fixtures globally.
    """
    tid = str(user_id)
    coach_a = matchup.get("coach_a", "")
    coach_b = matchup.get("coach_b", "")
    opponent_tid = coach_b if tid == coach_a else coach_a

    if not opponent_tid:
        return {}

    try:
        opponent_preds = get_predictions(int(opponent_tid))
    except (ValueError, TypeError):
        return {}

    fixture_ids: set[str] = set(matchup.get("fixture_ids", []))
    return {
        match_id: pred["score"]
        for match_id, pred in opponent_preds.items()
        if match_id in fixture_ids and pred.get("score")
    }


# ── seed ──────────────────────────────────────────────────────────────────────

# ── results ───────────────────────────────────────────────────────────────────

def get_result(match_id: str) -> dict | None:
    """Return {"score": str, "processed": bool} or None."""
    return _load().get("results", {}).get(match_id)


def save_result(match_id: str, score: str) -> None:
    """Persist the real result for a fixture (marks unprocessed until scored)."""
    data = _load()
    data.setdefault("results", {})[match_id] = {"score": score, "processed": False}
    _save(data)


def mark_result_processed(match_id: str) -> None:
    data = _load()
    results = data.setdefault("results", {})
    if match_id in results:
        results[match_id]["processed"] = True
    _save(data)


def update_result_score(match_id: str, score: str) -> None:
    """Update only the score string of an existing result, keeping processed flag."""
    data = _load()
    results = data.setdefault("results", {})
    if match_id in results:
        results[match_id]["score"] = score
    else:
        results[match_id] = {"score": score, "processed": True}
    _save(data)


def get_all_predictions_for_match(match_id: str) -> dict[str, dict]:
    """
    Return {telegram_id_str: {"score": str, "player": str}} for every coach
    who submitted a prediction for this fixture.
    """
    all_preds = _load().get("predictions", {})
    out: dict[str, dict] = {}
    for tid, matches in all_preds.items():
        pred = matches.get(match_id)
        if pred:
            if isinstance(pred, dict):
                out[tid] = pred
            else:
                out[tid] = {"score": str(pred), "player": ""}
    return out


# ── duel results ─────────────────────────────────────────────────────────────

def save_duel_results(match_day: int, duels: list[dict]) -> None:
    """
    Persist duel results for a match day.
    Each duel: {"home": str, "away": str, "goals_home": int, "goals_away": int}
    """
    data = _load()
    data.setdefault("duel_results", {})[str(match_day)] = duels
    _save(data)


def get_duel_results(match_day: int) -> list[dict]:
    """Return stored duel results for a match day, or empty list."""
    return _load().get("duel_results", {}).get(str(match_day), [])


def get_completed_match_days() -> list[int]:
    """
    Return sorted list of match day numbers that have been closed via
    /closematchday (i.e. have entries in duel_results).
    """
    dr = _load().get("duel_results", {})
    return sorted(int(k) for k in dr if dr[k])


def get_processed_result_ids(match_day: int) -> list[str]:
    """
    Return all result IDs for a given match day that have been marked
    processed (e.g. 'md1_m1', 'md1_m2', ...).
    """
    results = _load().get("results", {})
    prefix = f"md{match_day}_"
    return [k for k, v in results.items() if k.startswith(prefix) and v.get("processed")]


# ── playoff results ───────────────────────────────────────────────────────────

PLAYOFF_STAGES = ("r16", "qf", "sf", "f")


def save_playoff_results(stage: str, records: list[dict]) -> None:
    """
    Persist playoff results for a stage (r16 / qf / sf / f).
    Each record: {"home": str, "away": str, "goals_home": int, "goals_away": int}
    """
    data = _load()
    data.setdefault("playoff_results", {})[stage] = records
    _save(data)


def get_playoff_results(stage: str) -> list[dict]:
    """Return stored playoff results for a stage, or empty list."""
    return _load().get("playoff_results", {}).get(stage, [])


# ── club stats ────────────────────────────────────────────────────────────────

def get_club_stats() -> dict:
    """Return dict keyed by team name: {pts, w, d, l, played}."""
    return _load().get("club_stats", {})


def update_club_pts(team_name: str, pts_to_add: int, gf: int = 0, ga: int = 0) -> None:
    """Add prediction-league points to a club and update their W/D/L and goals record."""
    data = _load()
    club_stats = data.setdefault("club_stats", {})
    entry = club_stats.setdefault(
        team_name, {"pts": 0, "w": 0, "d": 0, "l": 0, "played": 0, "gf": 0, "ga": 0}
    )
    entry["pts"] += pts_to_add
    entry["played"] += 1
    entry.setdefault("gf", 0)
    entry.setdefault("ga", 0)
    entry["gf"] += gf
    entry["ga"] += ga
    if pts_to_add == 3:
        entry["w"] += 1
    elif pts_to_add == 1:
        entry["d"] += 1
    else:
        entry["l"] += 1
    _save(data)


def get_matchups_for_round(round_no: int) -> list:
    return [m for m in _load().get("matchups", []) if m.get("round") == round_no]


def save_matchup(matchup: dict) -> None:
    """Append a new matchup entry to db.json."""
    data = _load()
    data.setdefault("matchups", []).append(matchup)
    _save(data)


def is_matchup_club_scored(round_no: int, coach_a: str, coach_b: str) -> bool:
    key = f"{round_no}_{min(coach_a, coach_b)}_{max(coach_a, coach_b)}"
    return key in _load().get("matchup_club_scored", [])


def mark_matchup_club_scored(round_no: int, coach_a: str, coach_b: str) -> None:
    data = _load()
    scored = data.setdefault("matchup_club_scored", [])
    key = f"{round_no}_{min(coach_a, coach_b)}_{max(coach_a, coach_b)}"
    if key not in scored:
        scored.append(key)
    _save(data)


def seed_default_data() -> None:
    data = _load()

    if not data.get("standings"):
        data["standings"] = [
            {"pos": 1, "team": "FC Thunder",    "p": 6, "w": 2, "d": 0, "l": 0, "gd": "+5", "pts": 6},
            {"pos": 2, "team": "Red Lions",     "p": 6, "w": 1, "d": 2, "l": 0, "gd": "+2", "pts": 5},
            {"pos": 3, "team": "Blue Sharks",   "p": 6, "w": 1, "d": 1, "l": 1, "gd": "+1", "pts": 4},
            {"pos": 4, "team": "Golden Eagles", "p": 6, "w": 1, "d": 0, "l": 2, "gd": "-2", "pts": 3},
            {"pos": 5, "team": "Iron Wolves",   "p": 6, "w": 0, "d": 1, "l": 2, "gd": "-3", "pts": 1},
            {"pos": 6, "team": "Silver Stars",  "p": 6, "w": 0, "d": 0, "l": 3, "gd": "-3", "pts": 0},
        ]

    if not data.get("fixtures"):
        data["fixtures"] = [
            {"id": "r3_m1", "round": 3, "home": "FC Thunder",    "away": "Red Lions",     "date": "Sat 14 Jun, 15:00"},
            {"id": "r3_m2", "round": 3, "home": "Blue Sharks",   "away": "Iron Wolves",   "date": "Sat 14 Jun, 17:30"},
            {"id": "r3_m3", "round": 3, "home": "Golden Eagles", "away": "Silver Stars",  "date": "Sun 15 Jun, 14:00"},
            {"id": "r3_m4", "round": 3, "home": "Red Lions",     "away": "Blue Sharks",   "date": "Sat 14 Jun, 16:00"},
            {"id": "r3_m5", "round": 3, "home": "Iron Wolves",   "away": "FC Thunder",    "date": "Sat 14 Jun, 18:30"},
        ]

    if "matchups" not in data:
        data["matchups"] = []

    if "club_stats" not in data:
        data["club_stats"] = {}

    if "matchup_club_scored" not in data:
        data["matchup_club_scored"] = []

    _save(data)
