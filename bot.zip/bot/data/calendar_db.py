import json
import os

CALENDAR_FILE = os.path.join(os.path.dirname(__file__), "calendar.json")
DB_FILE       = os.path.join(os.path.dirname(__file__), "db.json")

TOTAL_ROUNDS = 8


# ── internal helpers ──────────────────────────────────────────────────────────

def _default() -> dict:
    return {
        "draw": None,
        "round_dates": {str(r): None for r in range(1, TOTAL_ROUNDS + 1)},
        "playoffs": {
            "playoff":    None,
            "round_of_16": None,
            "quarter":    None,
            "semi":       None,
        },
        "final": None,
    }


def _load() -> dict:
    if not os.path.exists(CALENDAR_FILE):
        return _default()
    with open(CALENDAR_FILE, "r") as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(CALENDAR_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── public API ────────────────────────────────────────────────────────────────

def load_calendar() -> dict:
    """Return calendar data, back-filling any missing keys."""
    data  = _load()
    defs  = _default()
    for key, val in defs.items():
        data.setdefault(key, val)
    data.setdefault("round_dates", defs["round_dates"])
    data["playoffs"] = {**defs["playoffs"], **data.get("playoffs", {})}
    return data


def get_round_date(round_no: int) -> str | None:
    """Return the stored date string for a league round, or None."""
    return load_calendar()["round_dates"].get(str(round_no))


def get_current_stage() -> str:
    """
    Determine the current active stage.

    Returns one of:
      "none"           — season not started
      "league:N"       — league round N is active (1-8)
      "playoff"        — playoff round active
      "round_of_16"    — Round of 16 active
      "quarter"        — quarter final active
      "semi"           — semi final active
      "final"          — final active
    """
    cal = load_calendar()

    if cal.get("final"):
        return "final"

    playoffs = cal.get("playoffs", {})
    for stage in ("semi", "quarter", "round_of_16", "playoff"):
        if playoffs.get(stage):
            return stage

    # Fall back to highest league round that has matchups
    try:
        if os.path.exists(DB_FILE):
            with open(DB_FILE, "r") as f:
                db = json.load(f)
            matchups = db.get("matchups", [])
            if matchups:
                current_round = max(m.get("round", 0) for m in matchups)
                if current_round > 0:
                    return f"league:{current_round}"
    except (json.JSONDecodeError, KeyError, TypeError, ValueError):
        pass

    return "none"
