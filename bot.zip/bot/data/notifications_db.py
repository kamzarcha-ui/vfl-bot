"""
Notification flag storage.

Flags are keyed by deadline_iso so they survive bot restarts and
reset correctly when a new deadline is set (different iso key).
"""

import json
import os

NOTIFICATIONS_FILE = os.path.join(os.path.dirname(__file__), "notifications.json")


def _load() -> dict:
    if not os.path.exists(NOTIFICATIONS_FILE):
        return {}
    with open(NOTIFICATIONS_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(NOTIFICATIONS_FILE, "w") as f:
        json.dump(data, f, indent=2)


def is_sent(key: str) -> bool:
    return bool(_load().get(key, False))


def mark_sent(key: str) -> None:
    data = _load()
    data[key] = True
    _save(data)
