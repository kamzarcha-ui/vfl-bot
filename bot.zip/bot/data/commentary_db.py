"""
Commentary DB — stores VFL preview articles and future commentary.
Storage: bot/data/commentary.json  (max 50 items, newest first)

Public API:
  load_commentary() -> list
  store_commentary(item: dict) -> None
"""

import json
import os

_DIR  = os.path.dirname(__file__)
_FILE = os.path.join(_DIR, "commentary.json")
_MAX  = 50


def load_commentary() -> list:
    if not os.path.exists(_FILE):
        return []
    with open(_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def store_commentary(item: dict) -> None:
    """Prepend item (newest first), keep at most _MAX entries."""
    data = load_commentary()
    data.insert(0, item)
    with open(_FILE, "w", encoding="utf-8") as f:
        json.dump(data[:_MAX], f, indent=2, ensure_ascii=False)
