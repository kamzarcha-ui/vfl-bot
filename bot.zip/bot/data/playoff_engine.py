"""
Playoff Engine — content generation for playoff stage events.

Pure data functions — no async, no handlers, no broadcasts.
Generates text + commentary/news items using existing stored data only.

Public API:
  generate_playoff_studio(match_day, season)           → (str, dict)
  generate_leg_review(match_day, stage, season)        → (str, dict)
  generate_qualification_drama(stage)                  → (str, dict, dict)
  generate_final_countdown(season)                     → (str, dict, dict)
  generate_champion_ceremony(season)                   → (str, dict, dict)
  generate_draw_news_item(pairings)                    → dict
"""

from datetime import datetime, timezone
import hashlib


# ── Constants ─────────────────────────────────────────────────────────────────

_STAGE_LABEL: dict[str, str] = {
    "playoff": "🔥 Плей-офф",
    "r16":     "🎟 1/8 Финал",
    "qf":      "🏅 1/4 Финал",
    "sf":      "🥉 1/2 Финал",
    "final":   "👑 Финал",
}

# first-leg MD → (stage_key, stage_label)
_STUDIO_MD_MAP: dict[int, tuple[str, str]] = {
    9:  ("playoff", "🔥 Плей-офф"),
    11: ("r16",     "🎟 1/8 Финал"),
    13: ("qf",      "🏅 1/4 Финал"),
    15: ("sf",      "🥉 1/2 Финал"),
    17: ("final",   "👑 Финал"),
}

_CLASH_DESCS: list[str] = [
    "Бу учрашув бутун мавсумнинг энг кўп кутилган жанги бўлиши мумкин.",
    "Иккала жамоа ҳам ортга чекинмайди. Ким зафарни қўлга олади?",
    "Натижа олдиндан айтиб бўлмайди — иккала жамоа ҳам тенг кучга эга.",
    "Мураббийлар орасидаги рақобат бу учрашувда асосий омил бўлади.",
    "Кутилмаган натижа мумкин — кучлилар мусобақасида ҳеч нарса аниқ эмас.",
    "Тажрибали жамоалар орасидаги жанг. Ҳар бир тахмин кимёни ҳал қилади.",
]


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%d.%m.%Y %H:%M")


def _clash_desc(home: str, away: str) -> str:
    h = int(hashlib.md5(f"{home}{away}".encode()).hexdigest(), 16)
    return _CLASH_DESCS[h % len(_CLASH_DESCS)]


def _top_scorer() -> tuple[str, str, int]:
    """Return (player_name, team_name, goals). Empty strings if no data."""
    from bot.data.teams_db import load_teams
    best = 0
    p_name = t_name = ""
    for team, info in load_teams().items():
        for p in info.get("players", []):
            if isinstance(p, dict) and p.get("goals", 0) > best:
                best   = p["goals"]
                p_name = p.get("name", "")
                t_name = team
    return p_name, t_name, best


def _golden_predictor() -> tuple[str, int, int]:
    """Return (coach_name, matchday_goals, exact_predictions)."""
    from bot.data.teams_db import load_coaches
    best_mg = best_ep = 0
    best_name = ""
    for cname, cinfo in load_coaches().items():
        mg = cinfo.get("matchday_goals", 0)
        ep = cinfo.get("exact_predictions", 0)
        if mg > best_mg or (mg == best_mg and ep > best_ep):
            best_mg   = mg
            best_ep   = ep
            best_name = cname
    return best_name, best_mg, best_ep


def _get_bracket_pairs(stage: str) -> list[dict]:
    """Return [{home, away}] for any stage, normalising playoff bracket format."""
    from bot.data.league_stage_db import get_stage_bracket, get_playoff_bracket
    if stage == "playoff":
        raw = get_playoff_bracket() or []
        return [{"home": p.get("team1", ""), "away": p.get("team2", "")} for p in raw]
    return get_stage_bracket(stage) or []


# ── Stage 1 (draw) ────────────────────────────────────────────────────────────

def generate_draw_news_item(pairings: list[dict]) -> dict:
    """Create a news.json item for the playoff draw completion."""
    sample = [
        f"{p.get('upper_team','?')} 🆚 {p.get('lower_team','?')}"
        for p in pairings[:3]
    ]
    rest = len(pairings) - 3
    body = "Плей-офф жуфтликлари: " + ", ".join(sample)
    if rest > 0:
        body += f" ва яна {rest} та жуфтлик."
    else:
        body += "."

    return {
        "date":      _ts(),
        "match_day": None,
        "type":      "playoff_draw",
        "icon":      "📰",
        "headline":  "Плей-офф Қуръаси якунланди!",
        "body":      body,
    }


# ── Stage 2 (first-leg preview) ───────────────────────────────────────────────

def generate_playoff_studio(match_day: int, season: int) -> tuple[str, dict]:
    """
    Special preview for playoff first-leg MDs (9/11/13/15/17).
    Returns (broadcast_text, commentary_item).
    """
    stage_key, stage_label = _STUDIO_MD_MAP.get(match_day, ("playoff", "🔥 Плей-офф"))
    pairs = _get_bracket_pairs(stage_key)

    p_name, p_team, p_goals = _top_scorer()
    c_name, c_mg,   c_ep    = _golden_predictor()

    lines: list[str] = [
        "🎙 <b>VFL PLAYOFF STUDIO</b>\n",
        f"🏆 <b>{stage_label} — {season}-мавсум</b>",
        f"📊 <b>Match Day #{match_day}</b>\n",
        "━━━━━━━━━━━━━━━━━━━━",
        "⚔️ <b>УЧРАШУВЛАР</b>\n",
    ]

    for i, pair in enumerate(pairs, 1):
        h = pair.get("home", pair.get("team1", "—"))
        a = pair.get("away", pair.get("team2", "—"))
        lines.append(f"{i}. <b>{h}</b> 🆚 <b>{a}</b>")

    if pairs:
        main = pairs[0]
        mh = main.get("home", main.get("team1", "—"))
        ma = main.get("away", main.get("team2", "—"))
        lines += [
            f"\n🔥 <b>АСОСИЙ ЖАНГ:</b>",
            f"<b>{mh}</b> 🆚 <b>{ma}</b>",
            f"<i>{_clash_desc(mh, ma)}</i>",
        ]

    lines += [
        "\n━━━━━━━━━━━━━━━━━━━━",
        "⚽ <b>ТОП БОМБАРДИР ПОЙГАСИ</b>\n",
        (f"<b>{p_name}</b> ({p_team}) — {p_goals} гол" if p_name and p_goals > 0
         else "Ҳали ҳисобланмаган"),
        "\n━━━━━━━━━━━━━━━━━━━━",
        "🎯 <b>GOLDEN PREDICTOR ПОЙГАСИ</b>\n",
        (f"<b>{c_name}</b> — {c_mg} гол • {c_ep} аниқ тахмин" if c_name and c_mg > 0
         else "Ҳали ҳисобланмаган"),
        "\n━━━━━━━━━━━━━━━━━━━━",
        "🎯 Тахминлар: /predict",
    ]

    text = "\n".join(lines)
    item = {
        "date":      _ts(),
        "match_day": match_day,
        "season":    season,
        "type":      "playoff_studio",
        "title":     f"VFL Playoff Studio — {stage_label}",
        "body":      text,
    }
    return text, item


# ── Stage 3 (second-leg review) ───────────────────────────────────────────────

def generate_leg_review(match_day: int, stage: str, season: int) -> tuple[str, dict]:
    """
    Two-leg stage review called after the second leg closes.
    match_day: 10 (playoff), 12 (r16), 14 (qf), 16 (sf)
    """
    from bot.data.db import get_duel_results
    from bot.data.league_stage_db import get_stage_winners

    leg1_md = match_day - 1
    leg1    = get_duel_results(leg1_md)
    leg2    = get_duel_results(match_day)

    if not leg1 or not leg2:
        return "", {}

    stage_label = _STAGE_LABEL.get(stage, stage)
    winners     = get_stage_winners(stage) or []

    # Build aggregate data (leg 2 has home/away swapped)
    pairs: list[dict] = []
    for l1, l2 in zip(leg1, leg2):
        team_a = l1["home"]          # team_a was home in leg 1
        team_b = l1["away"]          # team_b was away in leg 1, home in leg 2
        agg_a  = l1["goals_home"] + l2["goals_away"]
        agg_b  = l1["goals_away"] + l2["goals_home"]
        winner = team_a if team_a in winners else (team_b if team_b in winners else None)
        pairs.append({
            "team_a": team_a, "team_b": team_b,
            "agg_a":  agg_a,  "agg_b":  agg_b,
            # leg 1: team_a (home) vs team_b (away)
            "l1_ga": l1["goals_home"], "l1_gb": l1["goals_away"],
            # leg 2: team_b (home) vs team_a (away)
            "l2_gb": l2["goals_home"], "l2_ga": l2["goals_away"],
            "winner": winner,
        })

    biggest = max(pairs, key=lambda p: abs(p["agg_a"] - p["agg_b"]), default=None)
    closest = min(pairs, key=lambda p: abs(p["agg_a"] - p["agg_b"]), default=None)
    surprises = [p for p in pairs if p["winner"] == p["team_b"] and p["agg_b"] > p["agg_a"]]

    lines: list[str] = [
        f"📋 <b>VFL STUDIO — {stage_label} ШАРҲИ</b>\n",
        f"🏆 {season}-мавсум\n",
        "━━━━━━━━━━━━━━━━━━━━",
        "🏅 <b>ЯКУНИЙ НАТИЖАЛАР</b>\n",
    ]

    for p in pairs:
        icon   = "✅" if p["winner"] else "🤝"
        detail = (f"{p['l1_ga']}–{p['l1_gb']}, "
                  f"{p['l2_ga']}–{p['l2_gb']}")
        lines.append(
            f"{icon} <b>{p['team_a']}</b> {p['agg_a']}–{p['agg_b']} "
            f"<b>{p['team_b']}</b>  <i>({detail})</i>"
        )

    lines.append("\n━━━━━━━━━━━━━━━━━━━━")

    if biggest and abs(biggest["agg_a"] - biggest["agg_b"]) >= 2:
        w = biggest["team_a"] if biggest["agg_a"] > biggest["agg_b"] else biggest["team_b"]
        l = biggest["team_b"] if w == biggest["team_a"] else biggest["team_a"]
        aw = max(biggest["agg_a"], biggest["agg_b"])
        al = min(biggest["agg_a"], biggest["agg_b"])
        lines.append(f"🔥 <b>Энг катта ғалаба:</b> <b>{w}</b> {aw}–{al} ({l})")

    if closest and abs(closest["agg_a"] - closest["agg_b"]) <= 1:
        total = closest["agg_a"] + closest["agg_b"]
        lines.append(
            f"\n⚡ <b>Энг қизғин жанг:</b> "
            f"<b>{closest['team_a']}</b> 🆚 <b>{closest['team_b']}</b>"
            f" — жами {total} гол"
        )

    if surprises:
        s = surprises[0]
        lines.append(f"\n😲 <b>Сенсация:</b> <b>{s['team_b']}</b> кутилмаган ғалаба қозонди!")

    if winners:
        lines += [
            "\n━━━━━━━━━━━━━━━━━━━━",
            "<b>Кейинги босқичга ўтди:</b>",
        ]
        for w in winners:
            lines.append(f"  ✅ {w}")

    text = "\n".join(lines)
    item = {
        "date":      _ts(),
        "match_day": match_day,
        "season":    season,
        "type":      "playoff_review",
        "title":     f"{stage_label} Шарҳи — {season}-мавсум",
        "body":      text,
    }
    return text, item


# ── Stage 4 (qualification drama) ────────────────────────────────────────────

def generate_qualification_drama(stage: str) -> tuple[str, dict, dict]:
    """
    Generate qualified/eliminated announcement after a two-leg stage.
    Returns (broadcast_text, news_item, commentary_item).
    """
    from bot.data.league_stage_db import get_stage_winners

    stage_label = _STAGE_LABEL.get(stage, stage)
    winners     = get_stage_winners(stage) or []
    pairs       = _get_bracket_pairs(stage)
    all_teams   = [p.get("home", p.get("team1","")) for p in pairs] + \
                  [p.get("away", p.get("team2","")) for p in pairs]
    eliminated  = [t for t in all_teams if t and t not in winners]

    lines: list[str] = [
        f"🎭 <b>КВАЛИФИКАЦИЯ НАТИЖАЛАРИ</b>\n",
        f"<b>{stage_label}</b> якунланди\n",
        "━━━━━━━━━━━━━━━━━━━━",
        "✅ <b>КЕЙИНГИ БОСҚИЧГА ЎТДИ</b>\n",
    ]
    for w in winners:
        lines.append(f"  ✅ {w}")

    if eliminated:
        lines += ["\n━━━━━━━━━━━━━━━━━━━━", "❌ <b>ТУРНИРНИ ТАРК ЭТДИ</b>\n"]
        for e in eliminated:
            lines.append(f"  ❌ {e}")

    text = "\n".join(lines)
    now  = _ts()

    news_item = {
        "date":      now,
        "match_day": None,
        "type":      "qualification_drama",
        "icon":      "🎭",
        "headline":  f"{stage_label} — Квалификация якунланди",
        "body":      (f"{len(winners)} жамоа кейинги босқичга ўтди. "
                      f"{len(eliminated)} жамоа турнирни тарк этди."),
    }
    comm_item = {
        "date":      now,
        "match_day": None,
        "type":      "qualification_drama",
        "title":     f"{stage_label} — Квалификация натижалари",
        "body":      text,
    }
    return text, news_item, comm_item


# ── Stage 5 (final countdown) ─────────────────────────────────────────────────

def generate_final_countdown(season: int) -> tuple[str, dict, dict]:
    """Generate Final Countdown content after SF completion."""
    from bot.data.league_stage_db import get_stage_winners, get_stage_bracket

    finalists   = get_stage_winners("sf") or []
    sf_bracket  = get_stage_bracket("sf") or []

    # Fallback: read from final bracket
    if not finalists:
        final_bracket = get_stage_bracket("final") or []
        finalists = (
            [p.get("home", "") for p in final_bracket] +
            [p.get("away", "") for p in final_bracket]
        )
        finalists = [f for f in finalists if f]

    fa = finalists[0] if len(finalists) > 0 else "—"
    fb = finalists[1] if len(finalists) > 1 else "—"

    # Road: who did each finalist beat in SF?
    road_a = road_b = ""
    for pair in sf_bracket:
        h, a = pair.get("home", ""), pair.get("away", "")
        if fa in (h, a):
            road_a = a if fa == h else h
        if fb in (h, a):
            road_b = a if fb == h else h

    p_name, p_team, p_goals = _top_scorer()
    c_name, c_mg,   c_ep    = _golden_predictor()

    lines: list[str] = [
        "🏆 <b>ФИНАЛ COUNTDOWN</b>\n",
        f"👑 {season}-мавсум Финали яқинлашмоқда!\n",
        "━━━━━━━━━━━━━━━━━━━━",
        "🎭 <b>ФИНАЛИСТЛАР</b>\n",
        f"🔵 <b>{fa}</b>",
        f"🔴 <b>{fb}</b>",
    ]

    if road_a or road_b:
        lines += ["\n━━━━━━━━━━━━━━━━━━━━", "🛣 <b>ФИНАЛГА ЙЎЛДА</b>\n"]
        if road_a:
            lines.append(f"<b>{fa}</b> — {road_a}ни мағлуб этиб финалга чиқди")
        if road_b:
            lines.append(f"<b>{fb}</b> — {road_b}ни мағлуб этиб финалга чиқди")

    lines += [
        "\n━━━━━━━━━━━━━━━━━━━━",
        "⚽ <b>ТОП БОМБАРДИР ПОЙГАСИ</b>\n",
        (f"<b>{p_name}</b> ({p_team}) — {p_goals} гол" if p_name and p_goals > 0 else "—"),
        "\n━━━━━━━━━━━━━━━━━━━━",
        "🎯 <b>GOLDEN PREDICTOR ПОЙГАСИ</b>\n",
        (f"<b>{c_name}</b> — {c_mg} гол • {c_ep} аниқ тахмин" if c_name and c_mg > 0 else "—"),
        "\n━━━━━━━━━━━━━━━━━━━━",
        "🔜 <b>Буюк финал яқинда!</b>",
    ]

    text = "\n".join(lines)
    now  = _ts()

    news_item = {
        "date":      now,
        "match_day": None,
        "type":      "final_countdown",
        "icon":      "🏆",
        "headline":  f"ФИНАЛ COUNTDOWN! {fa} 🆚 {fb}",
        "body":      (f"{season}-мавсум финалига {fa} ва {fb} чиқди. "
                      "Буюк жанг яқинлашмоқда!"),
    }
    comm_item = {
        "date":      now,
        "match_day": None,
        "type":      "final_countdown",
        "title":     f"Финал Countdown — {fa} 🆚 {fb}",
        "body":      text,
    }
    return text, news_item, comm_item


# ── Stage 6 (champion ceremony) ───────────────────────────────────────────────

def generate_champion_ceremony(season: int) -> tuple[str, dict, dict]:
    """Generate Champion Ceremony content after Final closure."""
    from bot.data.league_stage_db import get_stage_winners, get_stage_bracket

    final_winners = get_stage_winners("final") or []
    final_bracket = get_stage_bracket("final") or []

    champion  = final_winners[0] if final_winners else None
    all_final = (
        [p.get("home", "") for p in final_bracket] +
        [p.get("away", "") for p in final_bracket]
    )
    runner_up = next((t for t in all_final if t and t != champion), None)

    if not champion:
        return "", {}, {}

    p_name, p_team, p_goals = _top_scorer()
    c_name, c_mg,   c_ep    = _golden_predictor()

    lines: list[str] = [
        "👑 <b>VFL CHAMPIONS LEAGUE</b>\n",
        f"🏆 <b>{season}-мавсум чемпиони аниқланди!</b>\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
        f"🏆 <b>ЧЕМПИОН: {champion}</b> 🎉\n",
    ]

    if runner_up:
        lines.append(f"🥈 <b>Финалист:</b> {runner_up}")

    lines += ["\n━━━━━━━━━━━━━━━━━━━━", "🏅 <b>МАВСУМ СОВРИНЛАРИ</b>\n"]

    if p_name and p_goals > 0:
        lines.append(f"⚽ <b>Олтин бутсе:</b> {p_name} ({p_team}) — {p_goals} гол")
    if c_name and c_mg > 0:
        lines.append(
            f"🎯 <b>Golden Predictor:</b> {c_name} — {c_mg} гол • {c_ep} аниқ тахмин"
        )

    lines += [
        "\n━━━━━━━━━━━━━━━━━━━━",
        "🏛 <b>Hall of Fame маълумотлари янгиланди</b>",
        f"\n🎊 Табриклаймиз, <b>{champion}</b>! 🎊",
        "━━━━━━━━━━━━━━━━━━━━",
    ]

    text = "\n".join(lines)
    now  = _ts()

    news_item = {
        "date":      now,
        "match_day": 17,
        "type":      "champion_ceremony",
        "icon":      "👑",
        "headline":  f"VFL Чемпиони: {champion}! 🏆",
        "body":      (f"{champion} {season}-мавсум VFL Champions League "
                      "чемпиони бўлди. Табриклаймиз!"),
    }
    comm_item = {
        "date":      now,
        "match_day": 17,
        "type":      "champion_ceremony",
        "title":     f"VFL Чемпион Маросими — {champion} 🏆",
        "body":      text,
    }
    return text, news_item, comm_item
