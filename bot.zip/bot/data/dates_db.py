"""
Persistent date storage for the VFL Champions League calendar.

All dates are stored in calendar_dates.json as plain strings (whatever
the admin typed — e.g. "17-19.09.2026").  Stage keys:

  League rounds : "1", "2", …, "8"
  Playoff entry : "playoff"
  Round of 16   : "round16"
  Quarter-final : "quarterfinal"
  Semi-final    : "semifinal"
  Final         : "final"
"""

import json
import os

DATES_FILE = os.path.join(os.path.dirname(__file__), "calendar_dates.json")

# All valid stage keys accepted by /setdate
VALID_STAGES = {
    "1", "2", "3", "4", "5", "6", "7", "8",
    "playoff", "round16", "quarterfinal", "semifinal", "final",
    # Playoff leg-specific keys (MD numbers)
    "9", "10", "11", "12", "13", "14", "15", "16", "17",
}

# Human-readable display labels (used by /dates)
STAGE_LABELS: dict[str, str] = {
    "1": "⚽ 1-Тур",
    "2": "⚽ 2-Тур",
    "3": "⚽ 3-Тур",
    "4": "⚽ 4-Тур",
    "5": "⚽ 5-Тур",
    "6": "⚽ 6-Тур",
    "7": "⚽ 7-Тур",
    "8": "⚽ 8-Тур",
    "playoff":      "🔥 Плей-офф",
    "round16":      "🏆 1/8 финал",
    "quarterfinal": "🏆 1/4 финал",
    "semifinal":    "🏆 1/2 финал",
    "final":        "👑 Финал",
    # Leg-specific (keyed by MD number)
    "9":  "🔥 Плей-офф — 1-ўйин",
    "10": "🔥 Плей-офф — 2-ўйин",
    "11": "🏆 1/8 финал — 1-ўйин",
    "12": "🏆 1/8 финал — 2-ўйин",
    "13": "🏆 1/4 финал — 1-ўйин",
    "14": "🏆 1/4 финал — 2-ўйин",
    "15": "🏆 1/2 финал — 1-ўйин",
    "16": "🏆 1/2 финал — 2-ўйин",
    "17": "👑 Финал",
}

# Display order for /dates output
STAGE_ORDER = [
    "1", "2", "3", "4", "5", "6", "7", "8",
    "playoff", "round16", "quarterfinal", "semifinal", "final",
    "9", "10", "11", "12", "13", "14", "15", "16", "17",
]


# ── Internal helpers ───────────────────────────────────────────────────────────

def _load() -> dict[str, str | None]:
    if not os.path.exists(DATES_FILE):
        return {}
    with open(DATES_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(DATES_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── Public API ────────────────────────────────────────────────────────────────

def get_date(stage: str) -> str | None:
    """Return the stored date string for *stage*, or None if not set."""
    return _load().get(stage)


def set_date(stage: str, value: str) -> None:
    """Persist a date string for *stage*."""
    data = _load()
    data[stage] = value
    _save(data)


def get_all_dates() -> dict[str, str | None]:
    """Return a dict of {stage: date_string | None} for every known stage."""
    stored = _load()
    return {stage: stored.get(stage) for stage in STAGE_ORDER}


def reset_dates() -> None:
    """Delete all stored dates."""
    _save({})
