"""
Shared admin-ID resolution.

Reads ADMIN_ID from the environment.  Supports a single ID or a
comma-separated list (e.g. "123456,789012") so multiple admins can be
added without code changes.
"""

import os

def _load() -> frozenset[int]:
    raw = os.environ.get("ADMIN_ID", "")
    ids: set[int] = set()
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            ids.add(int(part))
    return frozenset(ids)


ADMIN_IDS: frozenset[int] = _load()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS
