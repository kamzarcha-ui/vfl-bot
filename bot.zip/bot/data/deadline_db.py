"""
Deadline storage for Match Day prediction locking.

Dates and times are stored and compared in Moscow Time (MSK = UTC+3).
Rule: current_time <= deadline → ACCEPT  |  current_time > deadline → REJECT
"""

import json
import os
from datetime import datetime, timedelta, timezone

DEADLINE_FILE = os.path.join(os.path.dirname(__file__), "deadline.json")

MSK = timezone(timedelta(hours=3))


# ── Internal helpers ───────────────────────────────────────────────────────────

def _load() -> dict:
    if not os.path.exists(DEADLINE_FILE):
        return {}
    with open(DEADLINE_FILE) as f:
        return json.load(f)


def _save(data: dict) -> None:
    with open(DEADLINE_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ── Public API ────────────────────────────────────────────────────────────────

def set_deadline(date_str: str, time_str: str) -> None:
    """
    Persist deadline.
    date_str: "DD.MM.YYYY"   time_str: "HH:MM"
    """
    dt = datetime.strptime(f"{date_str} {time_str}", "%d.%m.%Y %H:%M")
    _save({
        "date":         date_str,
        "time":         time_str,
        "deadline_iso": dt.strftime("%Y-%m-%dT%H:%M:%S"),
    })


def get_deadline() -> dict | None:
    """Return stored deadline dict or None if not set."""
    data = _load()
    return data if data.get("deadline_iso") else None


def reset_deadline() -> None:
    """Remove the stored deadline."""
    _save({})


def is_deadline_passed() -> bool:
    """
    Return True if the current MSK time is strictly after the deadline.
    Returns False when no deadline is set (predictions always open).
    """
    data = _load()
    iso = data.get("deadline_iso")
    if not iso:
        return False
    deadline_dt = datetime.strptime(iso, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=MSK)
    return datetime.now(MSK) > deadline_dt


def deadline_display() -> tuple[str, str] | None:
    """
    Return (date_str, time_str) for display, or None if not set.
    Example: ("17.09.2026", "20:00")
    """
    data = _load()
    if not data.get("date"):
        return None
    return data["date"], data["time"]
